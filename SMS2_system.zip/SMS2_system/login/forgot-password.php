<?php
/**
 * SMS 2 – Forgot password (email reset link only for registered accounts)
 */
require_once __DIR__ . '/../config/config.php';
require_once ROOT_PATH . '/includes/authentication.php';
require_once ROOT_PATH . '/includes/mail.php';
require_once ROOT_PATH . '/includes/captcha.php';
require_once ROOT_PATH . '/includes/module-controls.php';

if (smsIsSystemInMaintenance()) {
    header('Location: ' . BASE_URL . '/account/maintenance.php');
    exit;
}

if (isAuthenticated()) {
    header('Location: ' . BASE_URL . '/dashboard/index.php');
    exit;
}

$message = '';
$error = '';
$emailValue = '';
$debugResetLink = '';
$mailError = '';
$mailTo = '';

/**
 * Find user by email address only (not username / student ID).
 */
function smsFindUserByEmailExact(string $email): ?array
{
    $email = strtolower(trim($email));
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return null;
    }
    $pdo = db();
    if (!$pdo) {
        return null;
    }
    $stmt = $pdo->prepare(
        'SELECT u.*, r.label AS role_label
         FROM users u
         INNER JOIN roles r ON r.role_key = u.role_key
         WHERE LOWER(u.email) = ?
         LIMIT 1'
    );
    $stmt->execute([$email]);
    $row = $stmt->fetch();
    return $row ?: null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrfVerify()) {
        $error = 'Security check failed. Please refresh and try again.';
    } else {
        $captcha = smsCaptchaVerifyRequest();
        if (empty($captcha['ok'])) {
            $error = $captcha['error'] !== ''
                ? $captcha['error']
                : 'Please complete the CAPTCHA before continuing.';
            $emailValue = trim((string) ($_POST['email'] ?? ''));
        } else {
        $email = trim((string) ($_POST['email'] ?? ''));
        $emailValue = $email;

        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Please enter a valid email address.';
        } else {
            $user = smsFindUserByEmailExact($email);

            if (!$user) {
                // Do not send anything — email is not in the system
                $error = 'This email is not registered in the system. Check the address, or contact your administrator.';
                logActivity(
                    'password_reset_request',
                    'Forgot password denied — email not in system: ' . $email,
                    'System',
                    null,
                    'Unknown',
                    null,
                    false
                );
            } else {
                $status = strtolower(trim((string) ($user['status'] ?? '')));

                if ($status === 'inactive' || $status === 'deactivated') {
                    $error = 'This account is deactivated. Password reset is not available. Contact your administrator.';
                    logActivity(
                        'password_reset_request',
                        'Forgot password denied — account deactivated',
                        'System',
                        (int) $user['id'],
                        (string) $user['full_name'],
                        (string) $user['role_key'],
                        false
                    );
                } elseif ($status === 'suspended' || $status === 'blocked') {
                    $error = 'This account is blocked/suspended. Password reset is not available. Contact your administrator.';
                    logActivity(
                        'password_reset_request',
                        'Forgot password denied — account blocked/suspended',
                        'System',
                        (int) $user['id'],
                        (string) $user['full_name'],
                        (string) $user['role_key'],
                        false
                    );
                } elseif (!in_array($status, ['active', 'locked'], true)) {
                    $error = 'This account cannot use password reset right now (status: ' . $status . '). Contact your administrator.';
                } else {
                    $accountEmail = trim((string) ($user['email'] ?? ''));
                    $sendTo = $accountEmail !== '' ? $accountEmail : $email;

                    $token = smsCreatePasswordResetToken((int) $user['id']);
                    if ($token && $sendTo !== '') {
                        $resetUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http')
                            . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost')
                            . BASE_URL . '/login/reset-password.php?token=' . urlencode($token);

                        $sent = smsSendPasswordResetEmail($user, $resetUrl, $sendTo);
                        $mailTo = (string) ($sent['to'] ?? $sendTo);

                        logActivity(
                            'password_reset_request',
                            !empty($sent['ok'])
                                ? 'Password reset link emailed to ' . $mailTo
                                : 'Password reset email failed for ' . $mailTo . ': ' . ($sent['error'] ?? 'unknown'),
                            'System',
                            (int) $user['id'],
                            (string) $user['full_name'],
                            (string) $user['role_key']
                        );

                        if (!empty($sent['ok'])) {
                            $message = 'A password reset link was sent to <strong>'
                                . e($mailTo)
                                . '</strong>. Open that email and use the link to set a new password.';
                        } else {
                            $mailError = (string) ($sent['error'] ?? 'Unable to send email.');
                            $message = 'Your email is registered, but we could not send mail to <strong>'
                                . e($mailTo) . '</strong> yet.';
                            if (trim(smsSetting('smtp_host', '')) === '') {
                                $message .= ' SMTP is not configured in System Settings.';
                            }
                            if (smsSetting('mail_show_link_on_failure', '1') === '1') {
                                $debugResetLink = $resetUrl;
                            }
                        }
                    } elseif ($sendTo === '') {
                        $error = 'This account has no email on file. Ask an administrator to add one first.';
                    } else {
                        $error = 'Could not create a reset link. Please try again.';
                    }
                }
            }
        }
        } // end captcha ok
    }
}

$pageTitle = 'Forgot Password';
$bodyClass = 'login-page forgot-page';
require_once ROOT_PATH . '/includes/header.php';
?>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/auth-transition.css?v=8">
<style>
body.login-page.forgot-page {
    --login-font: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
    min-height: 100vh !important;
    margin: 0 !important;
    padding: 0 !important;
    background: #071c48 !important;
    display: flex !important;
    flex-direction: column !important;
    align-items: center !important;
    justify-content: center !important;
    overflow-x: hidden;
    color-scheme: light !important;
    position: relative;
    font-family: var(--login-font);
}

.forgot-video-bg {
    position: fixed;
    inset: 0;
    z-index: 0;
    overflow: hidden;
    pointer-events: none;
}

.forgot-video-bg video {
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center;
    transform: scale(1.04);
    filter: saturate(1.05) brightness(0.92);
}

.forgot-video-bg::after {
    content: "";
    position: absolute;
    inset: 0;
    background:
        radial-gradient(ellipse 75% 60% at 50% 42%, rgba(4, 16, 42, 0.12) 0%, rgba(4, 16, 42, 0.42) 75%, rgba(2, 8, 24, 0.62) 100%),
        linear-gradient(180deg, rgba(4, 16, 42, 0.28) 0%, rgba(4, 16, 42, 0.18) 45%, rgba(2, 8, 24, 0.55) 100%);
}

.forgot-stage {
    position: relative;
    z-index: 1;
    width: 100%;
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 2rem 1.25rem;
    box-sizing: border-box;
}

.forgot-glass {
    width: min(360px, 100%);
    padding: 1.45rem 1.3rem 1.25rem;
    border-radius: 16px;
    border: 1px solid rgba(255, 255, 255, 0.38);
    background: rgba(255, 255, 255, 0.72);
    box-shadow:
        0 28px 64px rgba(2, 10, 30, 0.42),
        inset 0 1px 0 rgba(255, 255, 255, 0.45);
    backdrop-filter: blur(22px) saturate(1.35);
    -webkit-backdrop-filter: blur(22px) saturate(1.35);
}

.forgot-glass h1 {
    margin: 0 0 0.4rem;
    color: #0f172a;
    font-size: 1.65rem;
    font-weight: 800;
    line-height: 1.1;
    letter-spacing: -0.02em;
    text-align: center;
}

.forgot-lead {
    margin: 0 0 1rem;
    color: #475569;
    font-size: 0.86rem;
    font-weight: 600;
    line-height: 1.45;
    text-align: center;
}

.forgot-glass .form-label {
    margin-bottom: 0.35rem;
    color: #1e293b;
    font-size: 0.84rem;
    font-weight: 700 !important;
}

.forgot-glass .form-control {
    min-height: 44px;
    border: 1px solid #94a3b8 !important;
    border-radius: 10px !important;
    background: rgba(255, 255, 255, 0.96) !important;
    color: #0f172a !important;
    padding: 0.6rem 0.85rem !important;
    font-size: 0.92rem;
    font-weight: 600;
    box-shadow: none !important;
}

.forgot-glass .form-control:focus {
    border-color: #5350d6 !important;
    box-shadow: 0 0 0 3px rgba(83, 80, 214, 0.18) !important;
}

.forgot-field-error {
    position: absolute;
    width: 1px;
    height: 1px;
    padding: 0;
    margin: -1px;
    overflow: hidden;
    clip: rect(0, 0, 0, 0);
    white-space: nowrap;
    border: 0;
}

.forgot-glass .form-control.is-invalid {
    border-color: #e11d48 !important;
    background: rgba(255, 241, 242, 0.98) !important;
    box-shadow: 0 0 0 3px rgba(225, 29, 72, 0.14) !important;
}

.forgot-glass .form-control.is-invalid:focus {
    border-color: #e11d48 !important;
    background: #fff !important;
    box-shadow: 0 0 0 3px rgba(225, 29, 72, 0.18) !important;
}

.forgot-glass .invalid-feedback,
.forgot-glass .valid-feedback {
    display: none !important;
}

.forgot-glass .btn-auth-primary {
    width: 100%;
    min-height: 44px;
    border: 0 !important;
    border-radius: 999px !important;
    background: #5350d6 !important;
    color: #fff !important;
    padding: 0.65rem 1rem !important;
    font-size: 0.92rem;
    font-weight: 800;
    box-shadow: 0 8px 18px rgba(83, 80, 214, 0.25) !important;
}

.forgot-glass .btn-auth-primary:hover,
.forgot-glass .btn-auth-primary:focus {
    background: #4542c4 !important;
}

.forgot-links {
    margin-top: 1rem;
    text-align: center;
}

.forgot-links a {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 0.35rem;
    min-height: 2.25rem;
    padding: 0.35rem 0.75rem;
    color: #4338ca;
    font-size: 0.95rem;
    font-weight: 700;
    line-height: 1.3;
    text-decoration: none;
    text-shadow: none;
    border-radius: 8px;
}

.forgot-links a:hover,
.forgot-links a:focus-visible {
    color: #312e81;
    text-decoration: underline;
    background: rgba(67, 56, 202, 0.08);
    outline: none;
}

.forgot-glass .alert {
    border-radius: 12px;
    font-size: 0.88rem;
    font-weight: 600;
    backdrop-filter: blur(12px) saturate(1.2);
    -webkit-backdrop-filter: blur(12px) saturate(1.2);
    box-shadow: 0 8px 20px rgba(15, 23, 42, 0.08);
}

.forgot-setup-hint {
    margin-top: 0.75rem;
    padding: 0.85rem 0.95rem;
    border-radius: 12px;
    border: 1px solid #fdba74;
    background: rgba(255, 247, 237, 0.95);
    color: #9a3412;
    font-size: 0.86rem;
    line-height: 1.45;
}

.forgot-setup-hint ol {
    margin: 0.4rem 0 0;
    padding-left: 1.2rem;
}

.forgot-setup-hint code {
    font-size: 0.8rem;
}

.forgot-reset-box {
    margin-top: 0.65rem;
    padding: 0.75rem 0.85rem;
    border-radius: 12px;
    border: 1px solid #93c5fd;
    background: rgba(239, 246, 255, 0.95);
    color: #1e3a8a;
    font-size: 0.84rem;
    font-weight: 600;
    word-break: break-all;
}

.forgot-footer {
    position: relative;
    z-index: 1;
    padding: 0 1rem 1.15rem;
    color: rgba(255, 255, 255, 0.92);
    font-size: 0.85rem;
    font-weight: 600;
    text-align: center;
    text-shadow: 0 2px 12px rgba(0, 0, 0, 0.45);
}

.forgot-glass .sms-captcha-label {
    color: #0f172a !important;
    font-size: 0.98rem !important;
    font-weight: 800 !important;
}

.forgot-glass .sms-cf-widget,
.forgot-glass .sms-captcha-frame {
    border: 1px solid #cbd5e1 !important;
    border-radius: 12px !important;
    background: rgba(248, 250, 252, 0.95) !important;
}

.forgot-glass .sms-captcha-wrap {
    margin-bottom: 1.05rem !important;
}

.forgot-glass .sms-captcha-label {
    color: #0f172a !important;
    font-size: 0.98rem !important;
    font-weight: 800 !important;
    margin-bottom: 0.5rem !important;
}

.forgot-glass .sms-cf-widget,
.forgot-glass .sms-captcha-frame,
html[data-theme="dark"] .forgot-glass .sms-cf-widget,
html[data-theme="dark"] .forgot-glass .sms-captcha-frame {
    min-height: 58px !important;
    border: 1px solid rgba(148, 163, 184, 0.55) !important;
    border-radius: 14px !important;
    background: rgba(255, 255, 255, 0.55) !important;
    color: #0f172a !important;
    box-shadow:
        inset 0 1px 0 rgba(255, 255, 255, 0.75),
        0 8px 20px rgba(15, 23, 42, 0.06) !important;
    backdrop-filter: blur(14px) saturate(1.2) !important;
    -webkit-backdrop-filter: blur(14px) saturate(1.2) !important;
}

.forgot-glass .sms-cf-widget:hover,
.forgot-glass .sms-cf-widget:focus-visible,
.forgot-glass .sms-cf-widget:active,
.forgot-glass .sms-cf-widget.is-loading {
    border-color: rgba(83, 80, 214, 0.55) !important;
    background: rgba(255, 255, 255, 0.72) !important;
    color: #0f172a !important;
}

.forgot-glass .sms-cf-label,
html[data-theme="dark"] .forgot-glass .sms-cf-label {
    color: #0f172a !important;
    font-size: 1.02rem !important;
    font-weight: 700 !important;
}

.forgot-glass .sms-cf-box,
html[data-theme="dark"] .forgot-glass .sms-cf-box {
    background: rgba(255, 255, 255, 0.95) !important;
    border-color: #64748b !important;
}

.forgot-glass .sms-cf-brand,
html[data-theme="dark"] .forgot-glass .sms-cf-brand {
    border: 1px solid rgba(83, 80, 214, 0.25) !important;
    background: rgba(238, 242, 255, 0.9) !important;
    color: #4338ca !important;
}

.forgot-glass .sms-cf-widget.is-verified,
html[data-theme="dark"] .forgot-glass .sms-cf-widget.is-verified {
    border-color: rgba(34, 197, 94, 0.45) !important;
    background: rgba(240, 253, 244, 0.82) !important;
}

@media (prefers-reduced-motion: reduce) {
    .forgot-video-bg video {
        display: none;
    }

    .forgot-video-bg {
        background: #071c48;
    }
}
</style>

<div class="forgot-video-bg" aria-hidden="true">
    <video autoplay muted loop playsinline>
        <source src="<?= BASE_URL ?>/assets/videos/bcp-campus.mp4?v=bcp4" type="video/mp4">
    </video>
</div>

<main class="forgot-stage">
    <section class="forgot-glass" aria-label="Forgot password">
        <h1>Forgot password</h1>
        <p class="forgot-lead">Enter the email linked to your SMS 2 account. A reset link is sent only if that email is registered and the account is active.</p>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= e($error) ?></div>
        <?php endif; ?>
        <?php if ($message): ?>
            <div class="alert alert-<?= $mailError !== '' ? 'warning' : 'success' ?> mb-2"><?= $message ?></div>
            <?php if ($mailError !== ''): ?>
                <div class="forgot-setup-hint">
                    <strong>Why it failed:</strong> <?= e($mailError) ?>
                    <ol>
                        <li>Sign in as Super Admin → <strong>User Management → System Settings → Notifications / Email</strong></li>
                        <li>SMTP Server: <code>smtp.gmail.com</code></li>
                        <li>Port: <code>587</code>, Encryption: <strong>TLS</strong></li>
                        <li>Username: your Gmail &nbsp;|&nbsp; Password: a Gmail <strong>App Password</strong></li>
                        <li>From email: the same Gmail &nbsp;→ Save → click <strong>Test</strong></li>
                    </ol>
                </div>
            <?php endif; ?>
            <?php if ($debugResetLink !== ''): ?>
                <div class="forgot-reset-box">
                    <strong>Temporary link (only while email is not set up):</strong><br>
                    <a href="<?= e($debugResetLink) ?>"><?= e($debugResetLink) ?></a>
                </div>
            <?php endif; ?>
        <?php endif; ?>

        <form method="POST" class="mt-3" novalidate id="forgotForm">
            <?= csrfField() ?>
            <div class="mb-3">
                <label class="form-label" for="email">Email <span class="login-req" style="color:#dc2626;font-weight:700">*</span></label>
                <input type="email" class="form-control" id="email" name="email" required
                       placeholder="you@gmail.com" value="<?= e($emailValue) ?>"
                       autocomplete="email" autofocus
                       aria-describedby="forgotEmailError">
                <div class="forgot-field-error" id="forgotEmailError" role="alert">Email is required.</div>
            </div>
            <?= smsCaptchaMarkup() ?>
            <button type="submit" class="btn btn-auth-primary w-100" id="forgotSubmitBtn" disabled>
                <i class="fas fa-paper-plane me-2"></i>Send reset link
            </button>
            <div class="forgot-links">
                <a href="<?= BASE_URL ?>/login/login.php" data-auth-transition data-auth-direction="right"><i class="fas fa-arrow-left" aria-hidden="true"></i>Back to sign in</a>
            </div>
        </form>
    </section>
</main>

<footer class="forgot-footer">
    <p class="mb-0">&copy; 2026 Bestlink College of the Philippines. All rights reserved.</p>
</footer>
<script src="<?= BASE_URL ?>/assets/js/auth-transition.js?v=8"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    var form = document.getElementById('forgotForm');
    var email = document.getElementById('email');
    var errorEl = document.getElementById('forgotEmailError');
    var submitBtn = document.getElementById('forgotSubmitBtn');
    if (!form || !email || !submitBtn) return;

    function isValidEmail(value) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
    }

    function setEmailError(show, message) {
        if (!errorEl) return;
        if (show) {
            errorEl.textContent = message || 'Email is required.';
            errorEl.classList.add('is-visible');
            email.classList.add('is-invalid');
            email.setAttribute('aria-invalid', 'true');
        } else {
            errorEl.classList.remove('is-visible');
            email.classList.remove('is-invalid');
            email.removeAttribute('aria-invalid');
        }
    }

    function syncSendEnabled() {
        var value = email.value.trim();
        var captchaOk = document.getElementById('smsCaptchaOk');
        var captchaWidget = document.getElementById('smsCaptchaWidget');
        var captchaReady = true;
        if (captchaWidget && captchaOk) {
            captchaReady = captchaOk.value === '1';
        }
        submitBtn.disabled = !(isValidEmail(value) && captchaReady);
    }

    function validateEmail(show) {
        var value = email.value.trim();
        if (value === '') {
            if (show) setEmailError(true, 'Email is required.');
            return false;
        }
        if (!isValidEmail(value)) {
            if (show) setEmailError(true, 'Enter a valid email address.');
            return false;
        }
        setEmailError(false);
        return true;
    }

    email.addEventListener('input', function () {
        if (email.classList.contains('is-invalid') || (errorEl && errorEl.classList.contains('is-visible'))) {
            validateEmail(true);
        }
        syncSendEnabled();
    });
    // Do not show email errors on blur to random page areas — only on submit
    document.addEventListener('sms-captcha-ok', syncSendEnabled);
    var captchaPoll = 0;
    var captchaTimer = setInterval(function () {
        syncSendEnabled();
        captchaPoll += 1;
        if (captchaPoll > 40) clearInterval(captchaTimer);
    }, 500);

    form.addEventListener('submit', function (e) {
        if (!validateEmail(true) || submitBtn.disabled) {
            e.preventDefault();
            syncSendEnabled();
            return;
        }
        submitBtn.disabled = true;
    });

    syncSendEnabled();
});
</script>
<?php require_once ROOT_PATH . '/includes/scripts.php'; ?>
