<?php
/**
 * SMS 2 – Login step 2: Authenticator code or email OTP
 */
require_once __DIR__ . '/../config/config.php';
require_once ROOT_PATH . '/includes/authentication.php';
require_once ROOT_PATH . '/includes/totp.php';
require_once ROOT_PATH . '/includes/mail.php';

if (isAuthenticated()) {
    header('Location: ' . BASE_URL . '/dashboard/index.php');
    exit;
}

$pending = $_SESSION['pending_2fa'] ?? null;
if (!is_array($pending) || empty($pending['user_id']) || empty($pending['at']) || ((int) $pending['at'] + 600) < time()) {
    unset($_SESSION['pending_2fa']);
    $_SESSION['flash_login_error'] = 'Your sign-in session expired. Please sign in again.';
    header('Location: ' . BASE_URL . '/login/login.php');
    exit;
}

$userId = (int) $pending['user_id'];
$error = '';
$info = '';
$otpDev = '';

if (!empty($_SESSION['flash_2fa_error'])) {
    $error = (string) $_SESSION['flash_2fa_error'];
    unset($_SESSION['flash_2fa_error']);
}
if (!empty($_SESSION['flash_2fa_info'])) {
    $info = (string) $_SESSION['flash_2fa_info'];
    unset($_SESSION['flash_2fa_info']);
}
if (!empty($_SESSION['flash_2fa_otp'])) {
    $otpDev = (string) $_SESSION['flash_2fa_otp'];
    unset($_SESSION['flash_2fa_otp']);
}

$user = null;
$pdo = db();
if ($pdo) {
    $stmt = $pdo->prepare(
        'SELECT u.*, r.label AS role_label
         FROM users u INNER JOIN roles r ON r.role_key = u.role_key
         WHERE u.id = ? LIMIT 1'
    );
    $stmt->execute([$userId]);
    $user = $stmt->fetch() ?: null;
}
if (!$user) {
    unset($_SESSION['pending_2fa']);
    header('Location: ' . BASE_URL . '/login/login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrfVerify()) {
        $_SESSION['flash_2fa_error'] = 'Security check failed. Please try again.';
        header('Location: ' . BASE_URL . '/login/verify-2fa.php');
        exit;
    }

    $action = (string) ($_POST['action'] ?? 'verify');

    if ($action === 'send_email_otp') {
        $issued = smsIssueOtpToEmail($userId, 'login_2fa', 'System', 10, 'login verification');
        if (!empty($issued['ok'])) {
            if (!empty($issued['show_local']) && !empty($issued['code'])) {
                $_SESSION['flash_2fa_otp'] = (string) $issued['code'];
            }
            $_SESSION['flash_2fa_info'] = !empty($issued['emailed'])
                ? 'A login code was emailed to ' . $issued['to'] . '.'
                : 'Could not email OTP' . ($issued['error'] !== '' ? ': ' . $issued['error'] : '') . '. Use Authenticator, or the on-screen code if shown.';
        } else {
            $_SESSION['flash_2fa_error'] = 'Could not send email OTP.';
        }
        header('Location: ' . BASE_URL . '/login/verify-2fa.php');
        exit;
    }

    if ($action === 'cancel') {
        unset($_SESSION['pending_2fa']);
        header('Location: ' . BASE_URL . '/login/login.php');
        exit;
    }

    $code = trim((string) ($_POST['code'] ?? ''));
    $ok = false;
    if (smsAuthenticatorVerifyLogin($userId, $code)) {
        $ok = true;
    } elseif (smsVerifyOtp($userId, 'login_2fa', $code)) {
        $ok = true;
    }

    if (!$ok) {
        $_SESSION['flash_2fa_error'] = 'Invalid Authenticator or email OTP code.';
        header('Location: ' . BASE_URL . '/login/verify-2fa.php');
        exit;
    }

    $username = (string) ($pending['username'] ?? '');
    $result = smsCompleteLoginSession($user, $username);
    if (!empty($result['ok'])) {
        require_once ROOT_PATH . '/includes/module-controls.php';
        if (smsIsSystemInMaintenance() && getCurrentUserRoleKey() !== 'admin') {
            logout();
            header('Location: ' . BASE_URL . '/account/maintenance.php');
            exit;
        }
        if (!empty($_SESSION['must_change_password'])) {
            header('Location: ' . BASE_URL . '/login/change-password.php');
            exit;
        }
        if (getCurrentUserRoleKey() === 'student') {
            header('Location: ' . BASE_URL . '/modules/student-portal/pages/my-profile.php');
            exit;
        }
        header('Location: ' . BASE_URL . '/dashboard/index.php');
        exit;
    }

    $_SESSION['flash_2fa_error'] = 'Could not complete sign-in.';
    header('Location: ' . BASE_URL . '/login/verify-2fa.php');
    exit;
}

$pageTitle = 'Verify Sign In';
$bodyClass = 'login-page';
require_once ROOT_PATH . '/includes/header.php';
?>
<link href="<?= BASE_URL ?>/assets/css/auth-pages.css" rel="stylesheet">
<style>
body.login-page { --sms-auth-bg-image: url("<?= BASE_URL ?>/images/school2.png"); }
</style>

<main class="auth-stage">
    <section class="auth-card" aria-label="Two-factor verification">
        <div class="auth-badge">
            <i class="fas fa-shield-alt"></i>
            <span>Authenticator</span>
        </div>
        <h1>Verify it’s you</h1>
        <p class="auth-lead">
            Authenticator is active on this account. Enter the 6-digit code from
            <strong>Google Authenticator</strong>, or request an email OTP.
        </p>

        <?php if ($info): ?>
            <div class="alert alert-info"><?= e($info) ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?= e($error) ?></div>
        <?php endif; ?>
        <?php if ($otpDev !== ''): ?>
            <div class="alert alert-warning"><strong>Local OTP:</strong> <code><?= e($otpDev) ?></code></div>
        <?php endif; ?>

        <form method="POST" class="mt-3" novalidate>
            <?= csrfField() ?>
            <input type="hidden" name="action" value="verify">
            <div class="mb-3">
                <?php
                require_once ROOT_PATH . '/includes/security-ui.php';
                echo smsOtpInput('code', [
                    'id' => 'code',
                    'required' => true,
                    'autofocus' => true,
                    'label' => '6-digit code',
                    'hint' => 'From Google Authenticator, or the email we just sent.',
                ]);
                ?>
            </div>
            <button type="submit" class="btn btn-auth-primary w-100 mb-2">
                <i class="fas fa-check me-2"></i>Verify &amp; sign in
            </button>
        </form>
        <form method="POST" class="mb-2">
            <?= csrfField() ?>
            <input type="hidden" name="action" value="send_email_otp">
            <button type="submit" class="btn btn-outline-secondary w-100">
                <i class="fas fa-envelope me-2"></i>Send code to my email instead
            </button>
        </form>
        <form method="POST">
            <?= csrfField() ?>
            <input type="hidden" name="action" value="cancel">
            <button type="submit" class="btn btn-link w-100">Back to sign in</button>
        </form>
    </section>
</main>

<footer class="auth-footer">
    <p class="mb-0">&copy; 2026 Bestlink College of the Philippines. All rights reserved.</p>
</footer>
<?php require_once ROOT_PATH . '/includes/scripts.php'; ?>
