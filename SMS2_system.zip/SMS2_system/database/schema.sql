-- SMS 2 – Core security schema
-- Bestlink College of the Philippines
-- Charset: utf8mb4

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE DATABASE IF NOT EXISTS `sms2_db`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `sms2_db`;

DROP TABLE IF EXISTS `password_resets`;
DROP TABLE IF EXISTS `activity_logs`;
DROP TABLE IF EXISTS `role_permissions`;
DROP TABLE IF EXISTS `system_settings`;
DROP TABLE IF EXISTS `users`;
DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
  `id`          SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_key`    VARCHAR(40)  NOT NULL,
  `label`       VARCHAR(80)  NOT NULL,
  `description` VARCHAR(255) NULL,
  `is_system`   TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_roles_key` (`role_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `users` (
  `id`                    INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username`              VARCHAR(80)  NOT NULL,
  `email`                 VARCHAR(190) NOT NULL,
  `password_hash`         VARCHAR(255) NOT NULL,
  `full_name`             VARCHAR(150) NOT NULL,
  `role_key`              VARCHAR(40)  NOT NULL,
  `student_id`            VARCHAR(40)  NULL,
  `status`                ENUM('active','inactive','locked','suspended') NOT NULL DEFAULT 'active',
  `must_change_password`  TINYINT(1)   NOT NULL DEFAULT 0,
  `failed_login_attempts` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `locked_until`          DATETIME     NULL,
  `password_changed_at`   DATETIME     NULL,
  `last_login_at`         DATETIME     NULL,
  `last_seen_at`          DATETIME     NULL,
  `last_login_ip`         VARCHAR(45)  NULL,
  `notes`                 TEXT         NULL,
  `created_at`            DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`            DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_username` (`username`),
  UNIQUE KEY `uq_users_email` (`email`),
  KEY `idx_users_role` (`role_key`),
  KEY `idx_users_status` (`status`),
  KEY `idx_users_student_id` (`student_id`),
  CONSTRAINT `fk_users_role`
    FOREIGN KEY (`role_key`) REFERENCES `roles` (`role_key`)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `role_permissions` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_key`    VARCHAR(40)  NOT NULL,
  `module_key`  VARCHAR(60)  NOT NULL,
  `granted`     TINYINT(1)   NOT NULL DEFAULT 1,
  `updated_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_role_module` (`role_key`, `module_key`),
  KEY `idx_perm_module` (`module_key`),
  CONSTRAINT `fk_perm_role`
    FOREIGN KEY (`role_key`) REFERENCES `roles` (`role_key`)
    ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `password_resets` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`    INT UNSIGNED NOT NULL,
  `token_hash` CHAR(64)     NOT NULL,
  `expires_at` DATETIME     NOT NULL,
  `used_at`    DATETIME     NULL,
  `created_ip` VARCHAR(45)  NULL,
  `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_reset_user` (`user_id`),
  KEY `idx_reset_token` (`token_hash`),
  KEY `idx_reset_expires` (`expires_at`),
  CONSTRAINT `fk_reset_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `activity_logs` (
  `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`     INT UNSIGNED NULL,
  `user_name`   VARCHAR(150) NULL,
  `role_key`    VARCHAR(40)  NULL,
  `action`      VARCHAR(40)  NOT NULL,
  `module_key`  VARCHAR(60)  NULL,
  `detail`      VARCHAR(500) NOT NULL,
  `ip_address`  VARCHAR(45)  NULL,
  `user_agent`  VARCHAR(255) NULL,
  `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_logs_user` (`user_id`),
  KEY `idx_logs_action` (`action`),
  KEY `idx_logs_created` (`created_at`),
  CONSTRAINT `fk_logs_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `system_settings` (
  `setting_key`   VARCHAR(80)  NOT NULL,
  `setting_value` TEXT         NOT NULL,
  `updated_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
