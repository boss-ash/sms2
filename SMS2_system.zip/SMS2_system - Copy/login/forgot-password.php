<?php
/**
 * SMS 2 – Forgot password (email reset link only for registered accounts)
 */
require_once __DIR__ . '/../config/config.php';
require_once ROOT_PATH . '/includes/authentication.php';
require_once ROOT_PATH . '/includes/mail.php';
require_once ROOT_PATH . '/includes/captcha.php';

if (isAuthenticated()) {
    header('Location: ' . BASE_URL . '/dashboard/index.php');
    exit;
}

$message = '';
$error = '';
$emailValue = '';
$debugResetLink = '';
$mailError = '';
$mailTo = '';

/**
 * Find user by email address only (not username / student ID).
 */
function smsFindUserByEmailExact(string $email): ?array
{
    $email = strtolower(trim($email));
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return null;
    }
    $pdo = db();
    if (!$pdo) {
        return null;
    }
    $stmt = $pdo->prepare(
        'SELECT u.*, r.label AS role_label
         FROM users u
         INNER JOIN roles r ON r.role_key = u.role_key
         WHERE LOWER(u.email) = ?
         LIMIT 1'
    );
    $stmt->execute([$email]);
    $row = $stmt->fetch();
    return $row ?: null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrfVerify()) {
        $error = 'Security check failed. Please refresh and try again.';
    } else {
        $captcha = smsCaptchaVerifyRequest();
        if (empty($captcha['ok'])) {
            $error = $captcha['error'] !== ''
                ? $captcha['error']
                : 'Please complete the CAPTCHA before continuing.';
            $emailValue = trim((string) ($_POST['email'] ?? ''));
        } else {
        $email = trim((string) ($_POST['email'] ?? ''));
        $emailValue = $email;

        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Please enter a valid email address.';
        } else {
            $user = smsFindUserByEmailExact($email);

            if (!$user) {
                // Do not send anything — email is not in the system
                $error = 'This email is not registered in the system. Check the address, or contact your administrator.';
                logActivity(
                    'password_reset_request',
                    'Forgot password denied — email not in system: ' . $email,
                    'System',
                    null,
                    'Unknown',
                    null,
                    false
                );
            } else {
                $status = strtolower(trim((string) ($user['status'] ?? '')));

                if ($status === 'inactive' || $status === 'deactivated') {
                    $error = 'This account is deactivated. Password reset is not available. Contact your administrator.';
                    logActivity(
                        'password_reset_request',
                        'Forgot password denied — account deactivated',
                        'System',
                        (int) $user['id'],
                        (string) $user['full_name'],
                        (string) $user['role_key'],
                        false
                    );
                } elseif ($status === 'suspended' || $status === 'blocked') {
                    $error = 'This account is blocked/suspended. Password reset is not available. Contact your administrator.';
                    logActivity(
                        'password_reset_request',
                        'Forgot password denied — account blocked/suspended',
                        'System',
                        (int) $user['id'],
                        (string) $user['full_name'],
                        (string) $user['role_key'],
                        false
                    );
                } elseif (!in_array($status, ['active', 'locked'], true)) {
                    $error = 'This account cannot use password reset right now (status: ' . $status . '). Contact your administrator.';
                } else {
                    $accountEmail = trim((string) ($user['email'] ?? ''));
                    $sendTo = $accountEmail !== '' ? $accountEmail : $email;

                    $token = smsCreatePasswordResetToken((int) $user['id']);
                    if ($token && $sendTo !== '') {
                        $resetUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http')
                            . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost')
                            . BASE_URL . '/login/reset-password.php?token=' . urlencode($token);

                        $sent = smsSendPasswordResetEmail($user, $resetUrl, $sendTo);
                        $mailTo = (string) ($sent['to'] ?? $sendTo);

                        logActivity(
                            'password_reset_request',
                            !empty($sent['ok'])
                                ? 'Password reset link emailed to ' . $mailTo
                                : 'Password reset email failed for ' . $mailTo . ': ' . ($sent['error'] ?? 'unknown'),
                            'System',
                            (int) $user['id'],
                            (string) $user['full_name'],
                            (string) $user['role_key']
                        );

                        if (!empty($sent['ok'])) {
                            $message = 'A password reset link was sent to <strong>'
                                . e($mailTo)
                                . '</strong>. Open that email and use the link to set a new password.';
                        } else {
                            $mailError = (string) ($sent['error'] ?? 'Unable to send email.');
                            $message = 'Your email is registered, but we could not send mail to <strong>'
                                . e($mailTo) . '</strong> yet.';
                            if (trim(smsSetting('smtp_host', '')) === '') {
                                $message .= ' SMTP is not configured in System Settings.';
                            }
                            if (smsSetting('mail_show_link_on_failure', '1') === '1') {
                                $debugResetLink = $resetUrl;
                            }
                        }
                    } elseif ($sendTo === '') {
                        $error = 'This account has no email on file. Ask an administrator to add one first.';
                    } else {
                        $error = 'Could not create a reset link. Please try again.';
                    }
                }
            }
        }
        } // end captcha ok
    }
}

$pageTitle = 'Forgot Password';
$bodyClass = 'login-page';
require_once ROOT_PATH . '/includes/header.php';
?>
<link href="<?= BASE_URL ?>/assets/css/auth-pages.css" rel="stylesheet">
<style>
body.login-page {
    --sms-auth-bg-image: url("<?= BASE_URL ?>/images/school2.png");
}
.auth-setup-hint {
    margin-top: 0.75rem;
    padding: 0.85rem 0.95rem;
    border-radius: 12px;
    border: 1px solid #fdba74;
    background: #fff7ed;
    color: #9a3412;
    font-size: 0.86rem;
    line-height: 1.45;
}
.auth-setup-hint ol {
    margin: 0.4rem 0 0;
    padding-left: 1.2rem;
}
.auth-setup-hint code {
    font-size: 0.8rem;
}
</style>

<main class="auth-stage">
    <section class="auth-card" aria-label="Forgot password">
        <div class="auth-badge">
            <i class="fas fa-key"></i>
            <span>Password Recovery</span>
        </div>
        <h1>Forgot password</h1>
        <p class="auth-lead">Enter the email linked to your SMS 2 account. A reset link is sent only if that email is registered and the account is active.</p>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= e($error) ?></div>
        <?php endif; ?>
        <?php if ($message): ?>
            <div class="alert alert-<?= $mailError !== '' ? 'warning' : 'success' ?> mb-2"><?= $message ?></div>
            <?php if ($mailError !== ''): ?>
                <div class="auth-setup-hint">
                    <strong>Why it failed:</strong> <?= e($mailError) ?>
                    <ol>
                        <li>Sign in as Super Admin → <strong>User Management → System Settings → Notifications / Email</strong></li>
                        <li>SMTP Server: <code>smtp.gmail.com</code></li>
                        <li>Port: <code>587</code>, Encryption: <strong>TLS</strong></li>
                        <li>Username: your Gmail &nbsp;|&nbsp; Password: a Gmail <strong>App Password</strong></li>
                        <li>From email: the same Gmail &nbsp;→ Save → click <strong>Test</strong></li>
                    </ol>
                </div>
            <?php endif; ?>
            <?php if ($debugResetLink !== ''): ?>
                <div class="auth-reset-box mt-2">
                    <strong>Temporary link (only while email is not set up):</strong><br>
                    <a href="<?= e($debugResetLink) ?>"><?= e($debugResetLink) ?></a>
                </div>
            <?php endif; ?>
        <?php endif; ?>

        <form method="POST" class="mt-3" novalidate>
            <?= csrfField() ?>
            <div class="mb-3">
                <label class="form-label" for="email">Email</label>
                <input type="email" class="form-control" id="email" name="email" required
                       placeholder="you@gmail.com" value="<?= e($emailValue) ?>"
                       autocomplete="email" autofocus>
            </div>
            <?= smsCaptchaMarkup() ?>
            <button type="submit" class="btn btn-auth-primary w-100" id="forgotSubmitBtn">
                <i class="fas fa-paper-plane me-2"></i>Send reset link
            </button>
            <div class="auth-links">
                <a href="<?= BASE_URL ?>/login/login.php"><i class="fas fa-arrow-left me-1"></i>Back to sign in</a>
            </div>
        </form>
    </section>
</main>

<footer class="auth-footer">
    <p class="mb-0">&copy; 2026 Bestlink College of the Philippines. All rights reserved.</p>
</footer>
<?php require_once ROOT_PATH . '/includes/scripts.php'; ?>
