<?php
/**
 * SMS 2 - Login Page (CSRF + DB auth)
 */
require_once __DIR__ . '/../config/config.php';
require_once ROOT_PATH . '/includes/authentication.php';
require_once ROOT_PATH . '/includes/captcha.php';

// First-time adoption: no users yet → setup Super Admin
if (smsNeedsSetup()) {
    header('Location: ' . BASE_URL . '/setup/index.php');
    exit;
}

// Redirect if already logged in
if (isAuthenticated()) {
    if (!empty($_SESSION['must_change_password'])) {
        header('Location: ' . BASE_URL . '/login/change-password.php');
        exit;
    }
    if (getCurrentUserRoleKey() === 'student') {
        header('Location: ' . BASE_URL . '/modules/student-portal/pages/my-profile.php');
        exit;
    }

    header('Location: ' . BASE_URL . '/dashboard/index.php');
    exit;
}

$error = '';
$info = '';
$alertType = 'danger';
$showResetHint = false;
$usernameValue = '';
$loginLocked = false;
$lockUntilTs = 0;

// Persistent login lock gate (survives refresh; no auto-clear until cooldown ends)
$gate = smsLoginGateStatus();
if ($gate) {
    $loginLocked = true;
    $error = (string) $gate['message'];
    $alertType = (string) ($gate['alert'] ?? 'warning');
    $showResetHint = false;
    $lockUntilTs = (int) ($gate['until'] ?? 0);
}

// Also re-check IP throttle on every page load
$throttleNow = smsGetLoginThrottle('');
if (!$loginLocked && !empty($throttleNow['locked'])) {
    $secs = (int) ($throttleNow['lock_seconds'] ?? smsLockoutSeconds());
    $untilTs = 0;
    if (!empty($throttleNow['locked_until'])) {
        $parsed = strtotime((string) $throttleNow['locked_until']);
        if ($parsed !== false && $parsed > time()) {
            $untilTs = $parsed;
            $secs = max(1, $parsed - time());
        }
    }
    $msg = 'Login is temporarily locked after too many failed attempts. Please wait for the cooldown to finish before trying again.';
    smsLoginGateSet($throttleNow['locked_until'] ?? null, $msg, 'warning');
    $loginLocked = true;
    $error = $msg;
    $alertType = 'warning';
    $gate = smsLoginGateStatus();
    $lockUntilTs = (int) ($gate['until'] ?? ($untilTs > 0 ? $untilTs : (time() + $secs)));
}

// One-time flash messages (non-lock errors only — lock uses persistent gate)
if (!$loginLocked && !empty($_SESSION['flash_login_error'])) {
    $error = (string) $_SESSION['flash_login_error'];
    unset($_SESSION['flash_login_error']);
}
if (!empty($_SESSION['flash_login_info'])) {
    $info = (string) $_SESSION['flash_login_info'];
    unset($_SESSION['flash_login_info']);
}
if (!$loginLocked && !empty($_SESSION['flash_login_alert'])) {
    $alertType = (string) $_SESSION['flash_login_alert'];
    unset($_SESSION['flash_login_alert']);
}
if (!$loginLocked && !empty($_SESSION['flash_login_show_reset'])) {
    $showResetHint = true;
    unset($_SESSION['flash_login_show_reset']);
}
if (isset($_SESSION['flash_login_username'])) {
    $usernameValue = (string) $_SESSION['flash_login_username'];
    unset($_SESSION['flash_login_username']);
}

if ($info === '' && isset($_GET['timeout'])) {
    $info = 'Your session expired due to inactivity. Please sign in again.';
}
if ($info === '' && isset($_GET['reset'])) {
    $info = 'Password updated. You can sign in with your new password.';
}
if ($info === '' && isset($_GET['logged_out'])) {
    $info = 'You have been signed out.';
}

if ($loginLocked && $lockUntilTs <= time()) {
    $lockUntilTs = time() + smsLockoutSeconds();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim((string) ($_POST['username'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');

    // Block submit while locked (even if someone re-enables the form in DevTools)
    $gatePost = smsLoginGateStatus();
    $throttlePost = smsGetLoginThrottle($username);
    if ($gatePost || !empty($throttlePost['locked'])) {
        $secs = smsLockoutSeconds();
        if (!empty($gatePost['until'])) {
            $secs = max(1, (int) $gatePost['until'] - time());
        } elseif (!empty($throttlePost['locked_until'])) {
            $parsed = strtotime((string) $throttlePost['locked_until']);
            if ($parsed !== false && $parsed > time()) {
                $secs = max(1, $parsed - time());
            }
        }
        $msg = 'Login is temporarily locked after too many failed attempts. Please wait '
            . smsFormatDuration($secs)
            . ' before trying again. Sign-in is disabled until the cooldown ends.';
        smsLoginGateSet($throttlePost['locked_until'] ?? null, $msg, 'warning');
        $_SESSION['flash_login_username'] = $username;
        header('Location: ' . BASE_URL . '/login/login.php');
        exit;
    }

    if (!csrfVerify()) {
        $_SESSION['flash_login_error'] = 'Security check failed. Please try again.';
        $_SESSION['flash_login_username'] = $username;
        header('Location: ' . BASE_URL . '/login/login.php');
        exit;
    }

    // CAPTCHA first — bots never reach password check or 2FA
    $captcha = smsCaptchaVerifyRequest();
    if (empty($captcha['ok'])) {
        $_SESSION['flash_login_error'] = $captcha['error'] !== ''
            ? $captcha['error']
            : 'Please complete the CAPTCHA before signing in.';
        $_SESSION['flash_login_username'] = $username;
        header('Location: ' . BASE_URL . '/login/login.php');
        exit;
    }

    $result = smsLoginAttempt($username, $password);
    if (!empty($result['ok'])) {
        unset(
            $_SESSION['flash_login_error'],
            $_SESSION['flash_login_username'],
            $_SESSION['flash_login_info'],
            $_SESSION['flash_login_alert'],
            $_SESSION['flash_login_show_reset']
        );
        smsLoginGateClear();

        if (!empty($_SESSION['must_change_password'])) {
            header('Location: ' . BASE_URL . '/login/change-password.php');
            exit;
        }
        if (getCurrentUserRoleKey() === 'student') {
            header('Location: ' . BASE_URL . '/modules/student-portal/pages/my-profile.php');
            exit;
        }

        header('Location: ' . BASE_URL . '/dashboard/index.php');
        exit;
    }

    if (!empty($result['needs_2fa']) || (($result['code'] ?? '') === 'needs_2fa')) {
        header('Location: ' . BASE_URL . '/login/verify-2fa.php');
        exit;
    }

    $_SESSION['flash_login_username'] = $username;

    if (!empty($result['locked'])) {
        smsLoginGateSet(
            $result['locked_until'] ?? null,
            (string) ($result['message'] ?? 'Login is temporarily locked.'),
            (string) ($result['alert'] ?? 'warning'),
            smsLockoutSeconds()
        );
        unset(
            $_SESSION['flash_login_error'],
            $_SESSION['flash_login_alert'],
            $_SESSION['flash_login_show_reset']
        );
    } else {
        $_SESSION['flash_login_error'] = (string) ($result['message'] ?? 'Sign in failed.');
        $_SESSION['flash_login_alert'] = (string) ($result['alert'] ?? 'danger');
        $_SESSION['flash_login_show_reset'] = !empty($result['show_reset']) ? 1 : 0;
    }

    header('Location: ' . BASE_URL . '/login/login.php');
    exit;
}

$pageTitle = 'Login';
$bodyClass = 'login-page';

require_once ROOT_PATH . '/includes/header.php';
?>

<style>
body.login-page {
    min-height: 100vh;
    background-image:
        linear-gradient(90deg, rgba(5, 22, 55, 0.88) 0%, rgba(8, 42, 97, 0.8) 46%, rgba(15, 80, 153, 0.72) 100%),
        url("<?= BASE_URL ?>/images/school2.png") !important;
    background-size: cover !important;
    background-position: center !important;
    background-repeat: no-repeat !important;
    display: flex !important;
    flex-direction: column;
    align-items: stretch !important;
    justify-content: flex-start !important;
    padding: 0 !important;
    overflow-x: hidden;
}

.login-stage {
    box-sizing: border-box;
    flex: 1;
    min-height: calc(100vh - 70px);
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 2rem;
}

.login-shell {
    width: min(1060px, 100%);
    min-height: 560px;
    display: grid;
    grid-template-columns: 1.15fr 0.85fr;
    overflow: hidden;
    border: 1px solid rgba(255, 255, 255, 0.72);
    border-radius: 22px;
    background: #fff;
    box-shadow: 0 28px 70px rgba(2, 12, 32, 0.32);
}

.login-showcase {
    min-height: 560px;
    display: flex;
    align-items: flex-end;
    padding: 0 36px 32px;
    color: #fff;
    background-image:
        linear-gradient(180deg, rgba(4, 23, 55, 0.08) 0%, rgba(4, 20, 50, 0.78) 100%),
        url("<?= BASE_URL ?>/images/school1.png");
    background-size: cover;
    background-position: center;
}

.login-showcase-content {
    max-width: 560px;
}

.login-showcase h1 {
    margin: 0 0 12px;
    color: #fff;
    font-family: Georgia, "Times New Roman", serif;
    font-size: clamp(2.4rem, 4vw, 3.25rem);
    line-height: 0.98;
    font-weight: 800;
    letter-spacing: 0;
    text-shadow: 0 4px 18px rgba(0, 0, 0, 0.28);
}

.login-showcase p {
    margin: 0;
    color: rgba(255, 255, 255, 0.95);
    font-size: 0.92rem;
    font-weight: 600;
    line-height: 1.3;
    text-shadow: 0 2px 12px rgba(0, 0, 0, 0.28);
}

.login-card {
    width: 100%;
    min-height: 560px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    padding: 48px 30px;
    border: 0 !important;
    border-radius: 0 !important;
    background: #fff !important;
    box-shadow: none !important;
}

.login-badge {
    width: fit-content;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 16px;
    padding: 7px 12px;
    border: 1px solid #d8e5ff;
    border-radius: 999px;
    background: #eef5ff;
    color: #0d4bd6;
    font-size: 0.78rem;
    font-weight: 800;
}

.login-heading {
    margin-bottom: 26px;
}

.login-heading h1 {
    margin: 0 0 8px;
    color: #111827;
    font-family: Georgia, "Times New Roman", serif;
    font-size: clamp(2.55rem, 4vw, 3rem);
    line-height: 1;
    font-weight: 800;
    letter-spacing: 0;
}

.login-heading p {
    margin: 0;
    color: #475569;
    font-size: 0.9rem;
    line-height: 1.4;
}

.login-card .form-label {
    margin-bottom: 8px;
    color: #111827;
    font-size: 0.8rem;
    font-weight: 800 !important;
}

.login-card .input-group {
    position: relative;
    display: flex;
    align-items: center;
}

.login-card .input-group-text {
    display: none !important;
}

.login-card .form-control {
    width: 100%;
    min-height: 56px;
    border: 1px solid #d7e1ef !important;
    border-radius: 12px !important;
    background: #fff !important;
    color: #0f172a;
    padding: 14px 16px !important;
    font-size: 1.05rem;
    font-weight: 600;
    letter-spacing: 0.01em;
    box-shadow: none;
}

.login-card .form-control::placeholder {
    color: #94a3b8;
    font-weight: 500;
    opacity: 1;
}

.login-card .form-control:focus {
    border-color: #93b4ff !important;
    box-shadow: 0 0 0 3px rgba(38, 84, 211, 0.12) !important;
}

.login-card .password-group .form-control {
    padding-right: 52px !important;
}

.password-toggle {
    position: absolute;
    top: 50%;
    right: 14px;
    z-index: 5;
    width: 28px;
    height: 28px;
    padding: 0;
    border: 0;
    background: transparent;
    color: #475569;
    cursor: pointer;
    font-size: 1.15rem;
    transform: translateY(-50%);
}

.login-card .mb-3 {
    margin-bottom: 15px !important;
}

.login-card .mb-4 {
    margin-bottom: 18px !important;
}

.login-card .btn-sms-primary {
    border: 0 !important;
    border-radius: 12px !important;
    background: #294ecb !important;
    color: #fff !important;
    padding: 15px 16px !important;
    font-size: 1rem;
    font-weight: 800;
    box-shadow: 0 11px 20px rgba(41, 78, 203, 0.25);
}

.login-card .btn-sms-primary:hover:not(:disabled):not(.disabled),
.login-card .btn-sms-primary:focus:not(:disabled):not(.disabled) {
    background: #2445b7 !important;
}

.login-card .btn-sms-primary:disabled,
.login-card .btn-sms-primary.disabled {
    background: #94a3b8 !important;
    box-shadow: none !important;
    cursor: not-allowed;
    opacity: 1;
}

.login-footer {
    margin-top: 0;
    padding: 0 1.5rem 1.5rem;
    color: rgba(255, 255, 255, 0.88);
    font-size: 0.95rem;
    font-weight: 600;
    text-align: center;
    text-shadow: 0 2px 14px rgba(0, 0, 0, 0.35);
}

.login-links {
    margin-top: 14px;
    text-align: center;
}

.login-links a {
    color: #294ecb;
    font-size: 0.85rem;
    font-weight: 700;
    text-decoration: none;
}

.login-links a:hover {
    text-decoration: underline;
}

.login-or {
    display: flex;
    align-items: center;
    gap: 12px;
    margin: 18px 0 14px;
    color: #64748b;
    font-size: 0.8rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.04em;
}

.login-or::before,
.login-or::after {
    content: "";
    flex: 1;
    height: 1px;
    background: #d7e1ef;
}

.login-card .login-passkey-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 0.45rem;
    width: 100%;
    min-height: 52px;
    border: 1px solid #d7e1ef !important;
    border-radius: 12px !important;
    background: #f8fbff !important;
    color: #1e3a8a !important;
    font-size: 0.95rem;
    font-weight: 700;
    box-shadow: none;
}

.login-card .login-passkey-btn:hover,
.login-card .login-passkey-btn:focus {
    border-color: #93b4ff !important;
    background: #eef5ff !important;
    color: #0d4bd6 !important;
    box-shadow: 0 0 0 3px rgba(38, 84, 211, 0.1);
}

.login-card .login-passkey-btn i {
    color: #294ecb;
}

.login-alert {
    border-radius: 12px !important;
    border-width: 1px !important;
    font-size: 0.9rem;
    font-weight: 600;
    line-height: 1.45;
    padding: 0.9rem 1rem !important;
    color: #0f172a !important;
}

.login-alert.alert-danger {
    background: #fef2f2 !important;
    border-color: #fca5a5 !important;
    color: #991b1b !important;
}

.login-alert.alert-warning {
    background: #fff7ed !important;
    border-color: #fdba74 !important;
    color: #9a3412 !important;
}

.login-alert.alert-info {
    background: #eff6ff !important;
    border-color: #93c5fd !important;
    color: #1e3a8a !important;
}

.login-alert .alert-link {
    color: #1d4ed8 !important;
    font-weight: 800;
    text-decoration: underline;
}

.login-lock-box {
    margin: 0 0 1rem;
    padding: 0.85rem 0.95rem;
    border-radius: 12px;
    border: 1px solid #fdba74;
    background: #fff7ed;
}

.login-lock-box .lock-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 0.75rem;
    flex-wrap: wrap;
}

.login-lock-box .lock-copy {
    margin: 0;
    color: #9a3412;
    font-size: 0.82rem;
    font-weight: 600;
    line-height: 1.35;
    flex: 1 1 160px;
    min-width: 0;
}

.login-countdown {
    display: inline-flex;
    align-items: center;
    gap: 0.45rem;
    padding: 0.35rem 0.65rem;
    border-radius: 999px;
    background: #111827;
    color: #fff;
    white-space: nowrap;
}

.login-countdown .count-label {
    font-size: 0.65rem;
    font-weight: 700;
    letter-spacing: 0.04em;
    text-transform: uppercase;
    color: #fbbf24;
}

.login-countdown .count-value {
    font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
    font-size: 0.9rem;
    font-weight: 700;
    line-height: 1;
    letter-spacing: 0.02em;
    color: #fff;
}

.login-locked-fields {
    opacity: 0.55;
    margin: 0;
    padding: 0;
    border: 0;
    min-width: 0;
    pointer-events: none;
}

@media (max-width: 991.98px) {
    .login-shell {
        max-width: 560px;
        min-height: 0;
        grid-template-columns: 1fr;
    }

    .login-showcase {
        min-height: 300px;
        padding: 32px 28px;
    }

    .login-card {
        min-height: 0;
        padding: 36px 28px;
    }
}

@media (max-width: 575.98px) {
    .login-stage {
        min-height: auto;
        padding: 1rem;
    }

    .login-shell {
        border-radius: 18px;
    }

    .login-showcase {
        min-height: 250px;
        padding: 28px 24px;
    }

    .login-showcase h1 {
        font-size: 2.1rem;
    }

    .login-card {
        padding: 30px 22px;
    }

    .login-heading h1 {
        font-size: 2.35rem;
    }
}
</style>

<main class="login-stage">
<section class="login-shell" aria-label="Student Management System login">
    <div class="login-showcase">
        <div class="login-showcase-content">
            <h1>Student<br>Management System 2</h1>
            <p>Manage enrollment, student records, financial transactions, and clinic services in one secure platform.</p>
        </div>
    </div>
    <div class="login-card card shadow-lg">
        <div class="login-badge">
            <i class="fas fa-shield-alt"></i>
            <span>Secure Access Portal</span>
        </div>
        <div class="login-heading">
            <h1>Sign In</h1>
            <p>Please enter your account credentials to continue.</p>
        </div>

        <?php if ($info): ?>
            <div class="alert alert-info alert-dismissible fade show login-alert" role="alert">
                <i class="fas fa-info-circle me-2"></i><?= e($info) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if ($error && !$loginLocked): ?>
            <div class="alert alert-<?= $alertType === 'warning' ? 'warning' : 'danger' ?> alert-dismissible fade show login-alert" role="alert">
                <i class="fas fa-<?= $alertType === 'warning' ? 'exclamation-triangle' : 'exclamation-circle' ?> me-2"></i><?= e($error) ?>
                <?php if ($showResetHint): ?>
                    <div class="mt-2">
                        <a href="<?= BASE_URL ?>/login/forgot-password.php" class="alert-link">Forgot password? Reset it here</a>
                    </div>
                <?php endif; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if ($loginLocked): ?>
            <div class="login-lock-box" id="loginLockBox"
                 data-lock-until="<?= (int) $lockUntilTs ?>"
                 data-reload-url="<?= e(BASE_URL . '/login/login.php') ?>">
                <div class="lock-row">
                    <p class="lock-copy"><i class="fas fa-lock me-1"></i>Login locked. Try again when the timer ends.</p>
                    <div class="login-countdown" aria-live="polite">
                        <span class="count-label">Left</span>
                        <span class="count-value" id="loginCountdownValue">--:--</span>
                    </div>
                </div>
            </div>
            <fieldset disabled class="login-locked-fields">
                <div class="mb-3">
                    <label for="username" class="form-label fw-medium">Email</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light border-end-0"><i class="fas fa-user text-muted"></i></span>
                        <input type="text" class="form-control border-start-0" id="username" name="username"
                               placeholder="Enter your email" value="<?= e($usernameValue) ?>" autocomplete="username">
                    </div>
                </div>
                <div class="mb-4">
                    <label for="password" class="form-label fw-medium">Password</label>
                    <div class="input-group password-group">
                        <span class="input-group-text bg-light border-end-0"><i class="fas fa-lock text-muted"></i></span>
                        <input type="password" class="form-control border-start-0" id="password" name="password"
                               placeholder="Enter your password" autocomplete="current-password">
                    </div>
                </div>
                <button type="button" class="btn btn-secondary w-100 py-2 rounded-3" disabled>
                    <i class="fas fa-ban me-2"></i>Sign In unavailable
                </button>
            </fieldset>
            <div class="login-links">
                <a href="<?= BASE_URL ?>/login/forgot-password.php">Forgot password?</a>
            </div>
        <?php else: ?>
        <form method="POST" action="" novalidate id="loginForm">
            <?= csrfField() ?>
            <div class="mb-3">
                <label for="username" class="form-label fw-medium">Email</label>
                <div class="input-group">
                    <span class="input-group-text bg-light border-end-0"><i class="fas fa-user text-muted"></i></span>
                    <input type="text" class="form-control border-start-0" id="username" name="username"
                           placeholder="Enter your email" required autofocus
                           value="<?= e($usernameValue) ?>" autocomplete="username">
                </div>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label fw-medium">Password</label>
                <div class="input-group password-group">
                    <span class="input-group-text bg-light border-end-0"><i class="fas fa-lock text-muted"></i></span>
                    <input type="password" class="form-control border-start-0" id="password" name="password"
                           placeholder="Enter your password" required autocomplete="current-password">
                    <button class="password-toggle" type="button" aria-label="Show password" title="Show password" data-pw-target="password" aria-pressed="false">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
            </div>
            <?= smsCaptchaMarkup() ?>
            <button type="submit" class="btn btn-sms-primary w-100 py-2 rounded-3" id="loginSubmitBtn" disabled>
                <i class="fas fa-sign-in-alt me-2"></i>Sign In
            </button>
            <div class="login-or" aria-hidden="true">or</div>
            <div id="smsPasskeyLoginMsg" class="small mb-2 text-center" hidden></div>
            <button type="button" class="btn login-passkey-btn" id="smsPasskeyLoginBtn"
                    data-passkey-api="<?= e(BASE_URL . '/api/passkey.php') ?>">
                <i class="fas fa-fingerprint" aria-hidden="true"></i>Sign in with Passkey
            </button>
            <div class="login-links">
                <a href="<?= BASE_URL ?>/login/forgot-password.php">Forgot password?</a>
            </div>
        </form>
        <script src="<?= BASE_URL ?>/assets/js/passkey.js?v=5"></script>
        <?php endif; ?>
    </div>
</section>
</main>

<footer class="login-footer">
    <p class="mb-0">&copy; 2026 Bestlink College of the Philippines. All rights reserved.</p>
</footer>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const password = document.getElementById('password');
    const username = document.getElementById('username');
    const submitBtn = document.getElementById('loginSubmitBtn');
    const form = document.getElementById('loginForm');

    function syncSignInEnabled() {
        if (!submitBtn || !username || !password) return;
        const captchaOk = document.getElementById('smsCaptchaOk');
        const captchaWidget = document.getElementById('smsCaptchaWidget');
        const turnstile = document.querySelector('.cf-turnstile');
        let captchaReady = true;
        if (captchaWidget && captchaOk) {
            captchaReady = captchaOk.value === '1';
        } else if (turnstile) {
            // Turnstile injects cf-turnstile-response when solved; allow typing, server enforces
            const ts = document.querySelector('[name="cf-turnstile-response"]');
            captchaReady = !ts || (ts.value && ts.value.length > 0);
            // Before widget loads, don't permanently block — server still verifies
            if (!ts) captchaReady = true;
        }
        const ready = username.value.trim() !== '' && password.value !== '' && captchaReady;
        submitBtn.disabled = !ready;
    }

    if (username) {
        username.addEventListener('input', syncSignInEnabled);
        username.addEventListener('change', syncSignInEnabled);
    }
    if (password) {
        password.addEventListener('input', syncSignInEnabled);
        password.addEventListener('change', syncSignInEnabled);
    }
    document.addEventListener('sms-captcha-ok', syncSignInEnabled);
    // Poll briefly for Turnstile token
    let captchaPoll = 0;
    const captchaTimer = setInterval(function () {
        syncSignInEnabled();
        captchaPoll += 1;
        if (captchaPoll > 40) clearInterval(captchaTimer);
    }, 500);
    syncSignInEnabled();

    if (form && submitBtn) {
        form.addEventListener('submit', function (e) {
            if (submitBtn.disabled || username.value.trim() === '' || password.value === '') {
                e.preventDefault();
                syncSignInEnabled();
                return;
            }
            submitBtn.disabled = true;
        });
    }

    // Show/hide password is handled globally by sms-security-ui.js (do not double-bind here)

    const box = document.getElementById('loginLockBox');
    const valueEl = document.getElementById('loginCountdownValue');
    if (!box || !valueEl) return;

    const until = parseInt(box.getAttribute('data-lock-until') || '0', 10);
    const reloadUrl = box.getAttribute('data-reload-url') || window.location.href;

    function pad(n) {
        return String(n).padStart(2, '0');
    }

    function formatClock(totalSeconds) {
        const s = Math.max(0, totalSeconds);
        const hours = Math.floor(s / 3600);
        const minutes = Math.floor((s % 3600) / 60);
        const seconds = s % 60;
        if (hours > 0) {
            return pad(hours) + ':' + pad(minutes) + ':' + pad(seconds);
        }
        return pad(minutes) + ':' + pad(seconds);
    }

    function tick() {
        const remaining = until - Math.floor(Date.now() / 1000);
        if (remaining <= 0) {
            valueEl.textContent = '00:00';
            window.setTimeout(function () {
                window.location.href = reloadUrl;
            }, 500);
            return;
        }
        valueEl.textContent = formatClock(remaining);
        window.setTimeout(tick, 250);
    }

    tick();
});
</script>

<?php require_once ROOT_PATH . '/includes/scripts.php'; ?>
