<?php
/**
 * SMS 2 – Module Security (Super Admin)
 * Lives only under User Management.
 *
 * Flow:
 *   1) All Modules picker
 *   2) Open a module → that module’s Security Settings
 *   3) Activity Logs / Password Management / Authenticator (in-page)
 *
 * URL:
 *   module-security.php?picker=1
 *   module-security.php?focus=crad
 */
declare(strict_types=1);

require_once __DIR__ . '/../../../config/config.php';
require_once ROOT_PATH . '/includes/module-security-catalog.php';
require_once ROOT_PATH . '/includes/security-workflow.php';
require_once ROOT_PATH . '/includes/authentication.php';
require_once ROOT_PATH . '/includes/totp.php';
require_once ROOT_PATH . '/includes/authenticator-ui.php';
require_once ROOT_PATH . '/includes/passkey.php';
require_once ROOT_PATH . '/includes/security-ui.php';

requireAuth();
requireSuperAdmin();
smsEnsureSecurityTables();

$catalog = smsModuleSecurityCatalog();
$moduleOptions = [];
foreach (array_keys($MODULES) as $key) {
    if (isset($catalog[$key])) {
        $moduleOptions[$key] = $catalog[$key];
    }
}
foreach ($catalog as $key => $info) {
    if (!isset($moduleOptions[$key])) {
        $moduleOptions[$key] = $info;
    }
}

$self = BASE_URL . '/modules/user-management/pages/module-security.php';

$normalizeMod = static function (string $raw) use ($moduleOptions): string {
    $key = strtolower(trim(rawurldecode($raw)));
    $map = [
        'student-portal' => 'student_portal',
        'crud'           => 'crad',
        'crowd'          => 'crad',
    ];
    if (isset($map[$key])) {
        $key = $map[$key];
    }
    return isset($moduleOptions[$key]) ? $key : '';
};

$pickerUrl = static function () use ($self): string {
    return $self . '?picker=1';
};

/** Canonical URL for a focused module (tabs are client-side — no view= in URL). */
$focusUrl = static function (string $mod) use ($self): string {
    return $self . '?focus=' . rawurlencode($mod);
};

$wantPicker = isset($_GET['picker']) || isset($_GET['home']);

/* ── All Modules picker ─────────────────────────────────────── */
if ($wantPicker && $_SERVER['REQUEST_METHOD'] === 'GET') {
    unset($_SESSION['um_sec_focus']);
    if ((string) ($_GET['picker'] ?? '') !== '1' || isset($_GET['focus']) || isset($_GET['module']) || isset($_GET['m'])) {
        header('Location: ' . $pickerUrl());
        exit;
    }
}

/* ── Resolve focused module (never let empty POST override ?focus=) ─ */
$rawMod = trim((string) ($_POST['module_key'] ?? ''));
if ($rawMod === '') {
    $rawMod = trim((string) (
        $_GET['focus']
        ?? $_GET['module']
        ?? $_GET['m']
        ?? $_GET['sec_mod']
        ?? $_GET['mod']
        ?? ''
    ));
}
// Last resort on POST: parse focus from the request URI (form action)
if ($rawMod === '' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $reqUri = (string) ($_SERVER['REQUEST_URI'] ?? '');
    if (preg_match('/[?&]focus=([^&]+)/', $reqUri, $m)) {
        $rawMod = rawurldecode($m[1]);
    }
}
$moduleKey = $normalizeMod($rawMod);

// Keep focus across refresh if query was dropped but session still has it
if ($moduleKey === '' && !$wantPicker && $_SERVER['REQUEST_METHOD'] === 'GET') {
    $sessionFocus = $normalizeMod((string) ($_SESSION['um_sec_focus'] ?? ''));
    if ($sessionFocus !== '') {
        header('Location: ' . $focusUrl($sessionFocus));
        exit;
    }
}

$hasModule = $moduleKey !== '';

if ($hasModule) {
    $_SESSION['um_sec_focus'] = $moduleKey;
    // Canonical: ?focus=crad only (ignore legacy view/t/module params)
    if (
        $_SERVER['REQUEST_METHOD'] === 'GET'
        && (
            (string) ($_GET['focus'] ?? '') !== $moduleKey
            || isset($_GET['view'])
            || isset($_GET['t'])
            || isset($_GET['module'])
            || isset($_GET['m'])
            || isset($_GET['home'])
        )
    ) {
        header('Location: ' . $focusUrl($moduleKey));
        exit;
    }
} elseif (!$wantPicker && $_SERVER['REQUEST_METHOD'] === 'GET') {
    // No module in URL/session on GET — send to All Modules picker
    header('Location: ' . $pickerUrl());
    exit;
}

$adminId = (int) getCurrentUserId();

/* ── POST actions — always return to the SAME focused module ─ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postModule = $moduleKey;
    if ($postModule === '') {
        $postModule = $normalizeMod(trim((string) ($_POST['module_key'] ?? '')));
    }
    if ($postModule === '') {
        $postModule = $normalizeMod((string) ($_SESSION['um_sec_focus'] ?? ''));
    }
    if ($postModule === '') {
        $_SESSION['flash_sec_error'] = 'Open a module first.';
        header('Location: ' . $pickerUrl());
        exit;
    }

    $_SESSION['um_sec_focus'] = $postModule;
    $returnUrl = $focusUrl($postModule);

    if (!csrfVerify()) {
        $_SESSION['flash_sec_error'] = 'Security check failed. Please try again.';
        header('Location: ' . $returnUrl, true, 303);
        exit;
    }

    $action = (string) ($_POST['action'] ?? '');
    $panelForAction = static function (string $act): string {
        if (str_starts_with($act, 'admin_auth_') || $act === 'admin_passkey_clear' || $act === 'admin_passkey_remove') {
            return 'authenticator';
        }
        if (in_array($act, ['approve_request', 'reject_request', 'admin_reset_user'], true)) {
            return 'passwords';
        }
        return 'logs';
    };
    $_SESSION['um_sec_panel'] = $panelForAction($action);
    if ($_SESSION['um_sec_panel'] === 'authenticator') {
        $returnUrl .= '#panel-authenticator';
    } elseif ($_SESSION['um_sec_panel'] === 'passwords') {
        $returnUrl .= '#panel-passwords';
    }

    if ($action === 'approve_request') {
        if ((string) ($_POST['confirm_approve'] ?? '') !== '1') {
            $_SESSION['flash_sec_error'] = 'Approval cancelled — confirmation required.';
        } else {
            $result = smsApprovePasswordRequest((int) ($_POST['request_id'] ?? 0), $adminId);
            if ($result['ok']) {
                $_SESSION['flash_sec_success'] = 'Approved. The user’s chosen password is now active.';
            } else {
                $_SESSION['flash_sec_error'] = $result['error'] ?? 'Approve failed.';
            }
        }
        header('Location: ' . $returnUrl, true, 303);
        exit;
    }

    if ($action === 'reject_request') {
        $note = trim((string) ($_POST['admin_note'] ?? ''));
        if (smsRejectPasswordRequest((int) ($_POST['request_id'] ?? 0), $adminId, $note)) {
            $_SESSION['flash_sec_success'] = $note !== ''
                ? 'Request rejected. Your note was saved for the user.'
                : 'Request rejected.';
        } else {
            $_SESSION['flash_sec_error'] = 'Could not reject request.';
        }
        header('Location: ' . $returnUrl, true, 303);
        exit;
    }

    if ($action === 'admin_reset_user') {
        $targetId = (int) ($_POST['target_user_id'] ?? 0);
        $newPassword = (string) ($_POST['new_password'] ?? '');
        $confirmPassword = (string) ($_POST['new_password_confirm'] ?? '');
        $forceChange = !empty($_POST['force_change']);
        $allowedIds = array_map(static fn($u) => (int) $u['id'], smsUsersForModuleReset($postModule));
        $label = $moduleOptions[$postModule]['label'] ?? $postModule;
        $strength = smsValidatePasswordStrength($newPassword);

        if ($targetId <= 0) {
            $_SESSION['flash_sec_error'] = 'Select a user.';
        } elseif ($targetId === $adminId) {
            $_SESSION['flash_sec_error'] = 'You cannot reset your own password on this screen.';
        } elseif (!in_array($targetId, $allowedIds, true)) {
            $_SESSION['flash_sec_error'] = 'That user is not part of ' . $label . '.';
        } elseif (!$strength['ok']) {
            $_SESSION['flash_sec_error'] = $strength['message'];
        } elseif ($newPassword !== $confirmPassword) {
            $_SESSION['flash_sec_error'] = 'New password and confirmation do not match.';
        } elseif (!smsSetUserPassword($targetId, $newPassword, $forceChange)) {
            $_SESSION['flash_sec_error'] = 'Could not reset password.';
        } else {
            logActivity(
                'password_reset',
                'Reset password for ' . smsUserLogLabel($targetId)
                    . ($forceChange ? ' (must change on next login)' : ''),
                $postModule
            );
            $_SESSION['flash_sec_success'] = $forceChange
                ? 'Password reset. The user must change it on next login.'
                : 'Password reset successfully.';
            $_SESSION['um_sec_panel'] = 'passwords';
        }
        header('Location: ' . $returnUrl, true, 303);
        exit;
    }

    if ($action === 'admin_auth_disable') {
        $targetId = (int) ($_POST['target_user_id'] ?? 0);
        $allowedIds = array_map(static fn($u) => (int) $u['id'], smsUsersForModuleReset($postModule));
        $label = $moduleOptions[$postModule]['label'] ?? $postModule;
        if ($targetId <= 0 || !in_array($targetId, $allowedIds, true)) {
            $_SESSION['flash_sec_error'] = 'Select a valid ' . $label . ' user.';
        } elseif (!smsAuthenticatorIsEnabled($targetId)) {
            $_SESSION['flash_sec_error'] = 'Authenticator is already off for that user.';
        } else {
            smsAuthenticatorDisable($targetId);
            unset($_SESSION['admin_auth_setup_for'], $_SESSION['admin_auth_setup_at']);
            logActivity(
                'update',
                'Turned off Authenticator for ' . smsUserLogLabel($targetId),
                $postModule
            );
            $_SESSION['flash_sec_success'] = 'Authenticator turned off for that user.';
        }
        $_SESSION['um_sec_panel'] = 'authenticator';
        header('Location: ' . $returnUrl, true, 303);
        exit;
    }

    if ($action === 'admin_auth_turn_on') {
        $targetId = (int) ($_POST['target_user_id'] ?? 0);
        $allowedIds = array_map(static fn($u) => (int) $u['id'], smsUsersForModuleReset($postModule));
        $label = $moduleOptions[$postModule]['label'] ?? $postModule;
        if ($targetId <= 0 || !in_array($targetId, $allowedIds, true)) {
            $_SESSION['flash_sec_error'] = 'Select a valid ' . $label . ' user.';
        } elseif (smsAuthenticatorIsEnabled($targetId)) {
            $_SESSION['flash_sec_error'] = 'Authenticator is already on for that user.';
        } else {
            $secret = smsAuthenticatorBeginSetup($targetId);
            if (!$secret) {
                $_SESSION['flash_sec_error'] = 'Could not start Authenticator setup.';
            } else {
                $_SESSION['admin_auth_setup_for'] = $targetId;
                $_SESSION['admin_auth_setup_at'] = time();
                logActivity(
                    'update',
                    'Started Authenticator setup for ' . smsUserLogLabel($targetId),
                    $postModule
                );
                $_SESSION['flash_sec_success'] = 'Scan the QR (or enter the key), then enter the app code to turn Authenticator on.';
            }
        }
        $_SESSION['um_sec_panel'] = 'authenticator';
        header('Location: ' . $returnUrl, true, 303);
        exit;
    }

    if ($action === 'admin_auth_confirm') {
        $targetId = (int) ($_SESSION['admin_auth_setup_for'] ?? 0);
        $code = trim((string) ($_POST['totp_code'] ?? ''));
        $allowedIds = array_map(static fn($u) => (int) $u['id'], smsUsersForModuleReset($postModule));
        if (
            $targetId <= 0
            || !in_array($targetId, $allowedIds, true)
            || empty($_SESSION['admin_auth_setup_at'])
            || ((int) $_SESSION['admin_auth_setup_at'] + 900) < time()
        ) {
            unset($_SESSION['admin_auth_setup_for'], $_SESSION['admin_auth_setup_at']);
            $_SESSION['flash_sec_error'] = 'Authenticator setup expired. Turn On again.';
        } elseif (!smsAuthenticatorConfirmEnable($targetId, $code)) {
            $_SESSION['flash_sec_error'] = 'Invalid Authenticator code. Try again.';
        } else {
            unset($_SESSION['admin_auth_setup_for'], $_SESSION['admin_auth_setup_at']);
            logActivity(
                'update',
                'Turned on Authenticator for ' . smsUserLogLabel($targetId),
                $postModule
            );
            $_SESSION['flash_sec_success'] = 'Authenticator is Active for that user.';
        }
        $_SESSION['um_sec_panel'] = 'authenticator';
        header('Location: ' . $returnUrl, true, 303);
        exit;
    }

    if ($action === 'admin_auth_cancel') {
        $targetId = (int) ($_SESSION['admin_auth_setup_for'] ?? 0);
        if ($targetId > 0) {
            smsAuthenticatorDisable($targetId);
            logActivity(
                'update',
                'Cancelled Authenticator setup for ' . smsUserLogLabel($targetId),
                $postModule
            );
        }
        unset($_SESSION['admin_auth_setup_for'], $_SESSION['admin_auth_setup_at']);
        $_SESSION['flash_sec_success'] = 'Authenticator setup cancelled.';
        $_SESSION['um_sec_panel'] = 'authenticator';
        header('Location: ' . $returnUrl, true, 303);
        exit;
    }

    if ($action === 'admin_passkey_remove') {
        $targetId = (int) ($_POST['target_user_id'] ?? 0);
        $passkeyId = (int) ($_POST['passkey_id'] ?? 0);
        $allowedIds = array_map(static fn($u) => (int) $u['id'], smsUsersForModuleReset($postModule));
        $label = $moduleOptions[$postModule]['label'] ?? $postModule;
        if ($targetId <= 0 || !in_array($targetId, $allowedIds, true)) {
            $_SESSION['flash_sec_error'] = 'Select a valid ' . $label . ' user.';
        } elseif ($passkeyId <= 0) {
            $_SESSION['flash_sec_error'] = 'Select which passkey to remove.';
        } elseif (!smsPasskeyDelete($targetId, $passkeyId)) {
            $_SESSION['flash_sec_error'] = 'Could not remove that passkey (not found for this user).';
        } else {
            logActivity(
                'update',
                'Removed passkey #' . $passkeyId . ' for ' . smsUserLogLabel($targetId),
                $postModule
            );
            $_SESSION['flash_sec_success'] = 'Selected passkey removed.';
        }
        $_SESSION['um_sec_panel'] = 'authenticator';
        header('Location: ' . $returnUrl, true, 303);
        exit;
    }

    // Legacy "clear all" disabled — Super Admin must pick a specific passkey.
    if ($action === 'admin_passkey_clear') {
        $_SESSION['flash_sec_error'] = 'Choose a specific passkey to remove. Clearing all at once is not allowed.';
        $_SESSION['um_sec_panel'] = 'authenticator';
        header('Location: ' . $returnUrl, true, 303);
        exit;
    }

    header('Location: ' . $returnUrl, true, 303);
    exit;
}

/* ── Page data ─────────────────────────────────────────────── */
$allPending = [];
$pendingByModule = [];
$logs = [];
$pendingRequests = [];
$resetUsers = [];
$authUsers = [];
$moduleLabel = '';
$pendingCount = 0;
$adminAuthSetupId = 0;
$adminAuthSetupUser = null;
$adminAuthPendingSecret = null;
$initialPanel = 'logs';

if (!$hasModule) {
    $allPending = smsPendingPasswordRequests();
    foreach ($allPending as $req) {
        $mk = strtolower((string) $req['module_key']);
        $pendingByModule[$mk] = ($pendingByModule[$mk] ?? 0) + 1;
    }
} else {
    $moduleLabel = $moduleOptions[$moduleKey]['label'] ?? smsModuleLabel($moduleKey);
    $viewKey = 'um_sec_view_' . $moduleKey;
    if ($_SERVER['REQUEST_METHOD'] === 'GET' && empty($_SESSION[$viewKey])) {
        logActivity('view', 'Opened ' . $moduleLabel . ' Module Security', $moduleKey);
        $_SESSION[$viewKey] = time();
    }
    $logs = smsModuleActivityLogs($moduleKey, 300);
    $pendingRequests = smsPendingPasswordRequests($moduleKey);
    $resetUsers = smsUsersForModuleReset($moduleKey);
    $pendingCount = count($pendingRequests);
    $authUsers = [];
    foreach ($resetUsers as $u) {
        $uid = (int) $u['id'];
        $auth = smsAuthenticatorGet($uid);
        $u['authenticator_enabled'] = $auth && !empty($auth['enabled']);
        $u['passkey_count'] = smsPasskeyCount($uid);
        $u['passkeys'] = smsPasskeysForUser($uid);
        $authUsers[] = $u;
    }
    $adminAuthSetupId = (int) ($_SESSION['admin_auth_setup_for'] ?? 0);
    if (
        $adminAuthSetupId > 0
        && !empty($_SESSION['admin_auth_setup_at'])
        && ((int) $_SESSION['admin_auth_setup_at'] + 900) >= time()
    ) {
        foreach ($authUsers as $u) {
            if ((int) $u['id'] === $adminAuthSetupId) {
                $adminAuthSetupUser = $u;
                break;
            }
        }
        if ($adminAuthSetupUser) {
            $row = smsAuthenticatorGet($adminAuthSetupId);
            $adminAuthPendingSecret = $row['pending_secret'] ?? ($row['secret'] ?? null);
            if (!$adminAuthPendingSecret) {
                $adminAuthPendingSecret = smsAuthenticatorBeginSetup($adminAuthSetupId);
            }
        } else {
            unset($_SESSION['admin_auth_setup_for'], $_SESSION['admin_auth_setup_at']);
            $adminAuthSetupId = 0;
        }
    } else {
        unset($_SESSION['admin_auth_setup_for'], $_SESSION['admin_auth_setup_at']);
        $adminAuthSetupId = 0;
    }
    if (!empty($_SESSION['um_sec_panel'])) {
        $initialPanel = (string) $_SESSION['um_sec_panel'];
        unset($_SESSION['um_sec_panel']);
    }
}

$success = '';
$error = '';
if (!empty($_SESSION['flash_sec_success'])) {
    $success = (string) $_SESSION['flash_sec_success'];
    unset($_SESSION['flash_sec_success']);
}
if (!empty($_SESSION['flash_sec_error'])) {
    $error = (string) $_SESSION['flash_sec_error'];
    unset($_SESSION['flash_sec_error']);
}

$pageTitle    = $hasModule ? ($moduleLabel . ' Security Settings') : 'Module Security';
$activeModule = 'user-management';
$activePage   = 'module-security';
$breadcrumbs  = [
    ['label' => 'User Management', 'url' => BASE_URL . '/modules/user-management/index.php'],
    [
        'label' => 'Module Security',
        'url'   => $hasModule ? $pickerUrl() : null,
    ],
];
if ($hasModule) {
    $breadcrumbs[] = ['label' => $moduleLabel . ' Security Settings', 'url' => null];
}

require_once ROOT_PATH . '/includes/breadcrumbs.php';
require_once ROOT_PATH . '/includes/layout-start.php';

// Sidebar foreach must not overwrite the focused Module Security key (e.g. crad).
if ($hasModule) {
    $moduleKey = $normalizeMod((string) ($_SESSION['um_sec_focus'] ?? $moduleKey));
    if ($moduleKey === '') {
        $moduleKey = $normalizeMod((string) ($_GET['focus'] ?? ''));
    }
}
?>
<link href="<?= BASE_URL ?>/modules/user-management/assets/css/user-management.css" rel="stylesheet">
<style>
.sms-sec-pick-grid .sms-sec-pick {
    display: block;
    height: 100%;
    text-decoration: none;
    color: inherit;
}
.sms-sec-pick .sms-sec-card {
    height: 100%;
    transition: border-color 0.18s ease, box-shadow 0.18s ease, transform 0.18s ease;
}
.sms-sec-pick:hover .sms-sec-card {
    border-color: rgba(41, 78, 203, 0.35);
    box-shadow: 0 10px 28px rgba(15, 23, 42, 0.08);
    transform: translateY(-1px);
}
.sms-sec-pick .sms-sec-card-head {
    margin-bottom: 0;
    padding-bottom: 0;
    border-bottom: 0;
}
</style>

<?php renderBreadcrumbs($breadcrumbs); ?>

<?php if ($success): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle me-2"></i><?= e($success) ?></div>
<?php endif; ?>
<?php if ($error): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle me-2"></i><?= e($error) ?></div>
<?php endif; ?>

<?php if (!$hasModule): ?>
    <div class="page-header sms-sec-page-header mb-4">
        <h1><i class="fas fa-shield-alt text-sms-primary me-2"></i>Module Security</h1>
        <p>Choose a module to open its Security Settings — activity logs, password requests, and authenticator controls.</p>
    </div>

    <div class="row g-3 sms-sec-pick-grid mb-4">
        <?php foreach ($moduleOptions as $optKey => $info): ?>
            <?php $pending = (int) ($pendingByModule[$optKey] ?? 0); ?>
            <div class="col-md-6">
                <a href="<?= e($focusUrl($optKey)) ?>" class="sms-sec-pick">
                    <section class="card sms-sec-card mb-0">
                        <div class="card-body">
                            <div class="sms-sec-card-head">
                                <div class="sms-sec-card-title">
                                    <span class="sms-sec-icon"><i class="fas <?= e($info['icon']) ?>" aria-hidden="true"></i></span>
                                    <div>
                                        <h2 class="h6 fw-bold mb-0 d-flex align-items-center gap-2 flex-wrap">
                                            <?= e($info['label']) ?>
                                            <?php if ($pending > 0): ?>
                                                <span class="badge bg-danger"><?= $pending ?> pending</span>
                                            <?php endif; ?>
                                        </h2>
                                        <p class="sms-sec-lead mb-0 mt-1">Activity Logs · Passwords · Authenticator</p>
                                    </div>
                                </div>
                                <i class="fas fa-chevron-right text-sms-primary" style="opacity:.55;font-size:.75rem;" aria-hidden="true"></i>
                            </div>
                        </div>
                    </section>
                </a>
            </div>
        <?php endforeach; ?>
    </div>

<?php else: ?>
    <div id="secModuleRoot" class="sms-sec-root" data-focus-module="<?= e($moduleKey) ?>" data-initial-panel="<?= e($initialPanel) ?>" data-url-mode="admin">
        <div class="page-header sms-sec-page-header d-flex justify-content-between align-items-start flex-wrap gap-2 mb-3">
            <div>
                <h1>
                    <i class="fas <?= e($moduleOptions[$moduleKey]['icon'] ?? 'fa-shield-alt') ?> text-sms-primary me-2"></i>
                    <?= e($moduleLabel) ?> Security Settings
                </h1>
                <p class="mb-0">
                    Security tools for <strong><?= e($moduleLabel) ?></strong> only.
                    Switch modules anytime with <strong>All modules</strong>.
                </p>
            </div>
            <a class="btn btn-outline-secondary btn-sm" href="<?= e($pickerUrl()) ?>">
                <i class="fas fa-th-large me-1"></i>All modules
            </a>
        </div>

        <ul class="nav nav-tabs sms-sec-tabs mb-3" role="tablist">
            <li class="nav-item" role="presentation">
                <button type="button" class="nav-link active" data-sec-tab="logs" data-sec-tab-card="logs" role="tab" aria-controls="panel-logs">
                    <i class="fas fa-history me-1"></i>Activity Logs
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button type="button" class="nav-link" data-sec-tab="passwords" data-sec-tab-card="passwords" role="tab" aria-controls="panel-passwords">
                    <i class="fas fa-key me-1"></i>Password Management
                    <?php if ($pendingCount > 0): ?>
                        <span class="badge bg-danger ms-1"><?= (int) $pendingCount ?></span>
                    <?php endif; ?>
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button type="button" class="nav-link" data-sec-tab="authenticator" data-sec-tab-card="authenticator" role="tab" aria-controls="panel-authenticator">
                    <i class="fas fa-fingerprint me-1"></i>Authenticator &amp; Passkey
                </button>
            </li>
        </ul>

        <!-- Activity Logs panel -->
        <div id="panel-logs" class="sec-panel sms-sec-panel" role="tabpanel" data-sec-panel="logs">
            <?php
            $logActions = [];
            foreach ($logs as $log) {
                $a = (string) ($log['action'] ?? '');
                if ($a !== '') {
                    $logActions[$a] = true;
                }
            }
            ksort($logActions);
            ?>
            <section class="card sms-sec-card">
                <div class="card-body">
                    <div class="sms-sec-card-head">
                        <div class="sms-sec-card-title">
                            <span class="sms-sec-icon"><i class="fas fa-history" aria-hidden="true"></i></span>
                            <div>
                                <h2 class="h5 fw-bold mb-0"><?= e($moduleLabel) ?> — Activity Logs</h2>
                                <p class="sms-sec-lead mb-0 mt-1">All <?= e($moduleLabel) ?> security events — including Super Admin actions for this module.</p>
                            </div>
                        </div>
                        <div class="d-flex align-items-center gap-2 flex-wrap">
                            <span class="small text-muted" id="secLogCount"><?= count($logs) ?> shown</span>
                            <button type="button" class="btn btn-sm btn-outline-primary"
                                    data-sms-export-csv="#secLogTable"
                                    data-sms-export-rows="tbody tr.sec-log-row"
                                    data-sms-export-filename="<?= e($moduleKey) ?>-activity-logs.csv">
                                <i class="fas fa-file-export me-1"></i>Export CSV
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-secondary" id="secLogClear">Clear filters</button>
                        </div>
                    </div>
                    <div class="row g-2 g-md-3 mb-3">
                        <div class="col-md-3">
                            <label class="form-label small mb-1" for="secLogUser">User</label>
                            <input type="text" id="secLogUser" class="form-control form-control-sm" placeholder="Name…">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small mb-1" for="secLogAction">Action type</label>
                            <select id="secLogAction" class="form-select form-select-sm">
                                <option value="">All actions</option>
                                <?php foreach (array_keys($logActions) as $actionName): ?>
                                    <option value="<?= e($actionName) ?>"><?= e(ucfirst(str_replace('_', ' ', $actionName))) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-6 col-md-3">
                            <label class="form-label small mb-1" for="secLogDateFrom">Date from</label>
                            <input type="date" id="secLogDateFrom" class="form-control form-control-sm">
                        </div>
                        <div class="col-6 col-md-3">
                            <label class="form-label small mb-1" for="secLogDateTo">Date to</label>
                            <input type="date" id="secLogDateTo" class="form-control form-control-sm">
                        </div>
                    </div>
                    <div class="sec-log-scroll table-responsive border rounded-3">
                        <table class="table table-hover align-middle mb-0" id="secLogTable">
                            <thead class="sec-log-thead">
                                <tr>
                                    <th>Time</th>
                                    <th>User</th>
                                    <th>Action</th>
                                    <th>Detail</th>
                                    <th>IP</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!$logs): ?>
                                    <tr class="sec-log-empty-static">
                                        <td colspan="5" class="text-center text-muted py-4">No activity logs for this module yet.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($logs as $log): ?>
                                        <tr class="sec-log-row"
                                            data-action="<?= e((string) ($log['action'] ?? '')) ?>"
                                            data-user="<?= e(strtolower((string) ($log['user_name'] ?? ''))) ?>"
                                            data-date="<?= e((string) ($log['log_date'] ?? '')) ?>">
                                            <td class="small text-nowrap"><?= e($log['time']) ?></td>
                                            <td>
                                                <div class="fw-semibold"><?= e($log['user_name'] ?? 'System') ?></div>
                                                <div class="small text-muted"><?= e($log['role_key'] ?? '') ?></div>
                                            </td>
                                            <td><span class="badge text-bg-light"><?= e($log['action']) ?></span></td>
                                            <td class="small"><?= e($log['detail']) ?></td>
                                            <td class="small text-muted"><?= e($log['ip_address'] ?? '—') ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                    <tr class="sec-log-empty-filter" hidden>
                                        <td colspan="5" class="text-center text-muted py-4">No logs match the selected filters.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>
        </div>

        <!-- Password Management panel (same module — never navigates away) -->
        <div id="panel-passwords" class="sec-panel sms-sec-panel" role="tabpanel" data-sec-panel="passwords" hidden>
            <section class="card sms-sec-card mb-4">
                <div class="card-body">
                    <div class="sms-sec-card-head">
                        <div class="sms-sec-card-title">
                            <span class="sms-sec-icon"><i class="fas fa-inbox" aria-hidden="true"></i></span>
                            <h2 class="h5 fw-bold mb-0">Password requests</h2>
                        </div>
                        <?php if ($pendingCount > 0): ?>
                            <span class="badge bg-danger"><?= $pendingCount ?> pending</span>
                        <?php endif; ?>
                    </div>
                    <div class="table-responsive border rounded-3">
                        <table class="table align-middle mb-0">
                            <thead>
                                <tr>
                                    <th>User</th>
                                    <th>Reason</th>
                                    <th>Requested</th>
                                    <th class="text-end">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!$pendingRequests): ?>
                                    <tr>
                                        <td colspan="4" class="text-center text-muted py-4">
                                            No pending password requests for <?= e($moduleLabel) ?> right now.
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($pendingRequests as $req): ?>
                                        <tr>
                                            <td>
                                                <div class="fw-semibold"><?= e($req['full_name']) ?></div>
                                                <div class="small text-muted"><?= e($req['email']) ?> · <?= e($req['role_key']) ?></div>
                                            </td>
                                            <td class="small"><?= e($req['reason'] ?: '—') ?></td>
                                            <td class="small text-nowrap"><?= e(date('M j, Y g:i A', strtotime((string) $req['created_at']))) ?></td>
                                            <td class="text-end text-nowrap">
                                                <button type="button" class="btn btn-sm btn-success"
                                                        data-bs-toggle="modal" data-bs-target="#approveModal"
                                                        data-request-id="<?= (int) $req['id'] ?>"
                                                        data-user-name="<?= e($req['full_name']) ?>">Approve</button>
                                                <button type="button" class="btn btn-sm btn-outline-danger"
                                                        data-bs-toggle="modal" data-bs-target="#rejectModal"
                                                        data-request-id="<?= (int) $req['id'] ?>"
                                                        data-user-name="<?= e($req['full_name']) ?>">Reject</button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php if ($pendingRequests): ?>
                        <p class="small text-muted mb-0 mt-3">Approve asks for confirmation. Reject requires a note the user can see.</p>
                    <?php endif; ?>
                </div>
            </section>

            <section class="card sms-sec-card">
                <div class="card-body">
                    <div class="sms-sec-card-head">
                        <div class="sms-sec-card-title">
                            <span class="sms-sec-icon"><i class="fas fa-key" aria-hidden="true"></i></span>
                            <h2 class="h5 fw-bold mb-0"><?= e($moduleLabel) ?> — Reset Password</h2>
                        </div>
                    </div>
                    <p class="sms-sec-lead">Type a new password for the selected user. Use the eye icon to verify what you typed.</p>
                    <form method="POST" action="<?= e($focusUrl($moduleKey)) ?>" class="row g-3" style="max-width:560px;"
                          data-sms-confirm-submit="Are you sure you want to reset this user’s password? They will need the new password to sign in."
                          data-sms-confirm-title="Reset password?"
                          data-sms-confirm-ok="Yes, reset password"
                          id="adminResetPasswordForm">
                        <?= csrfField() ?>
                        <input type="hidden" name="module_key" value="<?= e($moduleKey) ?>">
                        <input type="hidden" name="action" value="admin_reset_user">
                        <div class="col-12">
                            <label class="form-label fw-semibold" for="target_user_id">User</label>
                            <select class="form-select" id="target_user_id" name="target_user_id" required>
                                <option value="">Select user…</option>
                                <?php if (!$resetUsers): ?>
                                    <option value="" disabled>No users found for this module</option>
                                <?php else: ?>
                                    <?php foreach ($resetUsers as $u): ?>
                                        <option value="<?= (int) $u['id'] ?>">
                                            <?= e($u['full_name']) ?> — <?= e($u['email'] ?: $u['username']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-semibold" for="new_password">New password</label>
                            <?= smsPasswordInput([
                                'id' => 'new_password',
                                'name' => 'new_password',
                                'required' => true,
                                'autocomplete' => 'new-password',
                                'minlength' => (int) smsSetting('min_password_length', '8'),
                            ]) ?>
                            <?= smsPasswordStrengthMarkup('new_password') ?>
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-semibold" for="new_password_confirm">Confirm new password</label>
                            <?= smsPasswordInput([
                                'id' => 'new_password_confirm',
                                'name' => 'new_password_confirm',
                                'required' => true,
                                'autocomplete' => 'new-password',
                                'minlength' => (int) smsSetting('min_password_length', '8'),
                            ]) ?>
                        </div>
                        <div class="col-12">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="1" id="force_change" name="force_change" checked>
                                <label class="form-check-label" for="force_change">
                                    Require user to change password on next login
                                </label>
                            </div>
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn btn-sms-primary" <?= !$resetUsers ? 'disabled' : '' ?>>
                                <i class="fas fa-key me-1"></i>Reset password
                            </button>
                        </div>
                    </form>
                </div>
            </section>

            <div class="modal fade" id="approveModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <form method="POST" action="<?= e($focusUrl($moduleKey)) ?>">
                            <?= csrfField() ?>
                            <input type="hidden" name="module_key" value="<?= e($moduleKey) ?>">
                            <input type="hidden" name="action" value="approve_request">
                            <input type="hidden" name="confirm_approve" value="1">
                            <input type="hidden" name="request_id" id="approveRequestId" value="">
                            <div class="modal-header">
                                <h5 class="modal-title"><i class="fas fa-exclamation-triangle text-warning me-2"></i>Confirm approval</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <p class="mb-2">Approve password request for <strong id="approveUserName">this user</strong>?</p>
                                <p class="small text-muted mb-0">Their chosen password will become active immediately.</p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-success">Yes, approve</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="rejectModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <form method="POST" action="<?= e($focusUrl($moduleKey)) ?>">
                            <?= csrfField() ?>
                            <input type="hidden" name="module_key" value="<?= e($moduleKey) ?>">
                            <input type="hidden" name="action" value="reject_request">
                            <input type="hidden" name="request_id" id="rejectRequestId" value="">
                            <div class="modal-header">
                                <h5 class="modal-title"><i class="fas fa-times-circle text-danger me-2"></i>Reject request</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <p class="mb-3">Reject request for <strong id="rejectUserName">this user</strong>.</p>
                                <label class="form-label fw-semibold" for="admin_note">
                                    Note to user <span class="text-muted fw-normal">(optional)</span>
                                </label>
                                <textarea class="form-control" id="admin_note" name="admin_note" rows="3" maxlength="500"
                                          placeholder="Optional message the user will see…"></textarea>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-danger">Reject request</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Authenticator panel -->
        <div id="panel-authenticator" class="sec-panel sms-sec-panel" role="tabpanel" data-sec-panel="authenticator" hidden>
            <?php if ($adminAuthSetupUser && $adminAuthPendingSecret): ?>
                <?php
                $setupLabel = (string) ($adminAuthSetupUser['email'] ?: $adminAuthSetupUser['full_name']);
                $setupUri = smsTotpOtpAuthUri($adminAuthPendingSecret, $setupLabel);
                ?>
                <section class="card sms-sec-card mb-4">
                    <div class="card-body">
                        <div class="sms-sec-card-head">
                            <div class="sms-sec-card-title">
                                <span class="sms-sec-icon"><i class="fas fa-qrcode" aria-hidden="true"></i></span>
                                <h2 class="h5 fw-bold mb-0">Turn On — <?= e($adminAuthSetupUser['full_name']) ?></h2>
                            </div>
                        </div>
                        <p class="sms-sec-lead">Have the user scan with Google Authenticator, then enter the app code to activate.</p>
                        <div class="sms-sec-setup">
                            <div><?= smsTotpQrMarkup($setupUri, 280) ?></div>
                            <div>
                                <p class="small mb-2">Or enter this key manually:</p>
                                <code class="d-inline-block px-2 py-1 bg-light rounded user-select-all"><?= e(trim(chunk_split($adminAuthPendingSecret, 4, ' '))) ?></code>
                            </div>
                        </div>
                        <form method="POST" action="<?= e($focusUrl($moduleKey)) ?>" style="max-width:420px;">
                            <?= csrfField() ?>
                            <input type="hidden" name="module_key" value="<?= e($moduleKey) ?>">
                            <input type="hidden" name="action" value="admin_auth_confirm">
                            <div class="mb-3">
                                <?= smsOtpInput('totp_code', ['id' => 'admin_totp_code', 'required' => true, 'autofocus' => true, 'label' => 'App code']) ?>
                            </div>
                            <button type="submit" class="btn btn-sms-primary">Activate</button>
                            <button type="submit" name="action" value="admin_auth_cancel" class="btn btn-outline-secondary ms-1" formnovalidate>Cancel</button>
                        </form>
                    </div>
                </section>
            <?php endif; ?>

            <section class="card sms-sec-card">
                <div class="card-body p-0">
                    <div class="px-3 pt-3">
                        <div class="sms-sec-card-head border-0 pb-2 mb-0">
                            <div class="sms-sec-card-title">
                                <span class="sms-sec-icon"><i class="fas fa-fingerprint" aria-hidden="true"></i></span>
                                <h2 class="h5 fw-bold mb-0"><?= e($moduleLabel) ?> — Authenticator &amp; Passkey</h2>
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table align-middle mb-0">
                            <thead>
                                <tr>
                                    <th>User</th>
                                    <th>Authenticator</th>
                                    <th>Passkey</th>
                                    <th class="text-end">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!$authUsers): ?>
                                    <tr>
                                        <td colspan="4" class="text-center text-muted py-4">No users found for this module.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($authUsers as $u): ?>
                                        <?php
                                        $on = !empty($u['authenticator_enabled']);
                                        $pkCount = (int) ($u['passkey_count'] ?? 0);
                                        $pkOn = $pkCount > 0;
                                        ?>
                                        <tr>
                                            <td>
                                                <div class="fw-semibold"><?= e($u['full_name']) ?></div>
                                                <div class="small text-muted"><?= e($u['email'] ?: $u['username']) ?></div>
                                            </td>
                                            <td>
                                                <span class="badge <?= $on ? 'text-bg-success' : 'text-bg-secondary' ?>">
                                                    <?= $on ? 'On' : 'Off' ?>
                                                </span>
                                            </td>
                                            <td>
                                                <span class="badge <?= $pkOn ? 'text-bg-success' : 'text-bg-secondary' ?>">
                                                    <?= $pkOn ? ('On · ' . $pkCount) : 'Off' ?>
                                                </span>
                                            </td>
                                            <td class="text-end text-nowrap">
                                                <?php if ($on): ?>
                                                    <form method="POST" action="<?= e($focusUrl($moduleKey)) ?>" class="d-inline-block">
                                                        <?= csrfField() ?>
                                                        <input type="hidden" name="module_key" value="<?= e($moduleKey) ?>">
                                                        <input type="hidden" name="action" value="admin_auth_disable">
                                                        <input type="hidden" name="target_user_id" value="<?= (int) $u['id'] ?>">
                                                        <button type="submit" class="btn btn-sm btn-outline-danger"
                                                                data-sms-confirm="Are you sure you want to turn off Authenticator for <?= e((string) $u['full_name']) ?>? They will no longer need an app code at login."
                                                                data-sms-confirm-title="Turn off Authenticator?"
                                                                data-sms-confirm-ok="Yes, turn off">
                                                            Auth Off
                                                        </button>
                                                    </form>
                                                <?php else: ?>
                                                    <form method="POST" action="<?= e($focusUrl($moduleKey)) ?>" class="d-inline-block">
                                                        <?= csrfField() ?>
                                                        <input type="hidden" name="module_key" value="<?= e($moduleKey) ?>">
                                                        <input type="hidden" name="action" value="admin_auth_turn_on">
                                                        <input type="hidden" name="target_user_id" value="<?= (int) $u['id'] ?>">
                                                        <button type="submit" class="btn btn-sm btn-sms-primary"
                                                            <?= ($adminAuthSetupId > 0 && $adminAuthSetupId !== (int) $u['id']) ? 'disabled' : '' ?>>
                                                            Auth On
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                                <?php if ($pkOn): ?>
                                                    <?php $userKeys = is_array($u['passkeys'] ?? null) ? $u['passkeys'] : []; ?>
                                                    <button type="button"
                                                            class="btn btn-sm btn-outline-danger ms-1"
                                                            data-bs-toggle="modal"
                                                            data-bs-target="#adminPasskeyModal"
                                                            data-user-id="<?= (int) $u['id'] ?>"
                                                            data-user-name="<?= e((string) $u['full_name']) ?>"
                                                            data-passkeys="<?= e(json_encode(array_map(static function ($pk) {
                                                                return [
                                                                    'id' => (int) ($pk['id'] ?? 0),
                                                                    'name' => (string) ($pk['device_name'] ?? 'Passkey'),
                                                                    'added' => !empty($pk['created_at'])
                                                                        ? date('M j, Y', strtotime((string) $pk['created_at']))
                                                                        : '',
                                                                ];
                                                            }, $userKeys), JSON_UNESCAPED_UNICODE)) ?>">
                                                        Remove passkey…
                                                    </button>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>
        </div>
    </div>

    <div class="modal fade" id="adminPasskeyModal" tabindex="-1" aria-labelledby="adminPasskeyModalTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="adminPasskeyModalTitle">Remove passkey</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p class="small text-muted mb-3" id="adminPasskeyModalLead">
                        Choose which passkey to remove. Other passkeys stay active.
                    </p>
                    <div id="adminPasskeyList" class="list-group list-group-flush"></div>
                    <p class="small text-muted mt-3 mb-0" id="adminPasskeyEmpty" hidden>No passkeys found for this user.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <form method="POST" action="<?= e($focusUrl($moduleKey)) ?>" id="adminPasskeyRemoveForm" class="d-none">
        <?= csrfField() ?>
        <input type="hidden" name="module_key" value="<?= e($moduleKey) ?>">
        <input type="hidden" name="action" value="admin_passkey_remove">
        <input type="hidden" name="target_user_id" id="adminPasskeyTargetUser" value="">
        <input type="hidden" name="passkey_id" id="adminPasskeyId" value="">
    </form>

    <link href="<?= BASE_URL ?>/assets/css/password-strength.css" rel="stylesheet">
    <script src="<?= BASE_URL ?>/assets/js/password-strength.js"></script>
    <script src="<?= BASE_URL ?>/modules/user-management/assets/js/module-security.js?v=20260723e"></script>
    <script>
    (function () {
        var modalEl = document.getElementById('adminPasskeyModal');
        if (!modalEl) return;
        var listEl = document.getElementById('adminPasskeyList');
        var emptyEl = document.getElementById('adminPasskeyEmpty');
        var titleEl = document.getElementById('adminPasskeyModalTitle');
        var form = document.getElementById('adminPasskeyRemoveForm');
        var targetInput = document.getElementById('adminPasskeyTargetUser');
        var idInput = document.getElementById('adminPasskeyId');

        modalEl.addEventListener('show.bs.modal', function (ev) {
            var btn = ev.relatedTarget;
            if (!btn || !listEl) return;
            var userId = btn.getAttribute('data-user-id') || '';
            var userName = btn.getAttribute('data-user-name') || 'user';
            var keys = [];
            try { keys = JSON.parse(btn.getAttribute('data-passkeys') || '[]'); } catch (e) { keys = []; }
            if (titleEl) titleEl.textContent = 'Remove passkey — ' + userName;
            if (targetInput) targetInput.value = userId;
            listEl.innerHTML = '';
            if (!keys.length) {
                if (emptyEl) emptyEl.hidden = false;
                return;
            }
            if (emptyEl) emptyEl.hidden = true;
            keys.forEach(function (pk) {
                var row = document.createElement('div');
                row.className = 'list-group-item d-flex justify-content-between align-items-center gap-2 px-0';
                var meta = document.createElement('div');
                meta.innerHTML = '<div class="fw-semibold"></div><div class="small text-muted"></div>';
                meta.querySelector('.fw-semibold').textContent = pk.name || ('Passkey #' + pk.id);
                meta.querySelector('.small').textContent = pk.added ? ('Added ' + pk.added) : '';
                var removeBtn = document.createElement('button');
                removeBtn.type = 'button';
                removeBtn.className = 'btn btn-sm btn-outline-danger flex-shrink-0';
                removeBtn.textContent = 'Remove';
                removeBtn.addEventListener('click', function () {
                    var doRemove = function () {
                        if (idInput) idInput.value = String(pk.id || '');
                        if (form) form.submit();
                    };
                    if (typeof window.smsConfirm === 'function') {
                        window.smsConfirm(
                            'Are you sure you want to remove “' + (pk.name || 'this passkey') + '” for ' + userName + '? Other passkeys will stay.',
                            doRemove,
                            { title: 'Remove passkey?', okText: 'Yes, remove' }
                        );
                    } else if (window.confirm('Are you sure you want to remove this passkey?')) {
                        doRemove();
                    }
                });
                row.appendChild(meta);
                row.appendChild(removeBtn);
                listEl.appendChild(row);
            });
        });
    })();
    </script>
<?php endif; ?>

<?php require_once ROOT_PATH . '/includes/layout-end.php'; ?>
