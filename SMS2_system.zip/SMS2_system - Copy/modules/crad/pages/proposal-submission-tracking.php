<?php
/**
 * SMS 2 - Proposal Submission & Tracking
 * Module: CRAD
 */
require_once __DIR__ . '/../../../config/config.php';

$pageTitle    = 'Proposal Submission & Tracking';
$activeModule = 'crad';
$activePage   = 'proposal-submission-tracking';
$breadcrumbs  = [
    ['label' => 'CRAD', 'url' => BASE_URL . '/modules/crad/index.php'],
    ['label' => 'Proposal Submission & Tracking', 'url' => null],
];

$cradProcess = [
    'description' => 'Manage research proposal submissions, panel reviews, approvals, and tracking for institutional and academic programs.',
    'metrics' => [
        ['label' => 'Total Proposals', 'value' => '5', 'icon' => 'fa-layer-group', 'tone' => 'blue'],
        ['label' => 'Pending Review', 'value' => '2', 'icon' => 'fa-clock', 'tone' => 'amber'],
        ['label' => 'Panel Assigned', 'value' => '1', 'icon' => 'fa-users', 'tone' => 'purple'],
        ['label' => 'Approved', 'value' => '1', 'icon' => 'fa-check-circle', 'tone' => 'green'],
    ],
    'columns' => ['Reference', 'Research Proposal', 'Lead Researcher', 'Status', 'Updated'],
    'fields' => ['reference', 'title', 'owner', 'status', 'updated'],
    'records' => [
        [
            'reference' => 'RES-2026-401',
            'title' => 'Smart Campus Attendance via RFID & AI',
            'owner' => 'Dr. Hank Pym',
            'detail' => 'Computer Science',
            'status' => 'Panel Assigned',
            'status_class' => 'scheduled',
            'updated' => 'Jul 18, 2026 09:30',
        ],
        [
            'reference' => 'RES-2026-402',
            'title' => 'Gamified Curriculum Impact in Primary Schools',
            'owner' => 'Prof. Jean Grey',
            'detail' => 'Education',
            'status' => 'Pending',
            'status_class' => 'pending',
            'updated' => 'Jul 17, 2026 14:15',
        ],
        [
            'reference' => 'RES-2026-403',
            'title' => 'Micro-Enterprise Marketing Adaptability Study',
            'owner' => 'Prof. Clara T. Reyes',
            'detail' => 'Business Administration',
            'status' => 'Approved',
            'status_class' => 'approved',
            'updated' => 'Jul 16, 2026 10:00',
        ],
        [
            'reference' => 'RES-2026-404',
            'title' => 'Community Mental Health Literacy Program',
            'owner' => 'Dr. Ana L. Mendoza',
            'detail' => 'Education',
            'status' => 'In Progress',
            'status_class' => 'progress',
            'updated' => 'Jul 15, 2026 11:45',
        ],
        [
            'reference' => 'RES-2026-405',
            'title' => 'Solid Waste Segregation Awareness Research',
            'owner' => 'Prof. Joel R. Cruz',
            'detail' => 'Criminology',
            'status' => 'Cancelled',
            'status_class' => 'cancelled',
            'updated' => 'Jul 14, 2026 08:20',
        ],
    ],
    'actions' => [
        ['label' => 'New Proposal', 'process' => 'new', 'icon' => 'fa-plus', 'class' => 'primary'],
        ['label' => 'Assign Panel', 'process' => 'validate', 'icon' => 'fa-users', 'class' => 'ghost'],
        ['label' => 'Approve Proposal', 'process' => 'approve', 'icon' => 'fa-check', 'class' => 'ghost'],
        ['label' => 'Proposal Report', 'process' => 'report', 'icon' => 'fa-file-export', 'class' => 'ghost'],
    ],
];

require_once __DIR__ . '/../../../includes/breadcrumbs.php';
require_once __DIR__ . '/../../../includes/layout-start.php';
?>

<?php renderBreadcrumbs($breadcrumbs); ?>
<?php require_once ROOT_PATH . '/includes/crad-module-process.php'; ?>
<?php require_once __DIR__ . '/../../../includes/layout-end.php'; ?>
