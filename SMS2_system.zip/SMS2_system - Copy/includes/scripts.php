<?php
/**
 * SMS 2 - Scripts
 */
?>
<!-- Bootstrap JS (local) -->
<script src="<?= BASE_URL ?>/assets/vendor/bootstrap/bootstrap.bundle.min.js"></script>
<!-- SMS 2 App -->
<script src="<?= BASE_URL ?>/assets/js/theme.js"></script>
<script src="<?= BASE_URL ?>/assets/js/ph-clock.js"></script>
<script src="<?= BASE_URL ?>/assets/js/sidebar.js"></script>
<script src="<?= BASE_URL ?>/assets/js/app.js"></script>
<script src="<?= BASE_URL ?>/assets/js/sms-security-ui.js?v=4"></script>
<!-- Global Search -->
<script src="<?= BASE_URL ?>/assets/js/search.js"></script>
</body>
</html>
