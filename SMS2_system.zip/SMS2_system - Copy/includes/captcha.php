<?php
/**
 * SMS 2 – Login CAPTCHA (one-click)
 *
 * 1) Cloudflare Turnstile when keys are set (real API / one click)
 * 2) Local one-click checkbox (Discord / Cloudflare-style) for XAMPP / no keys
 *
 * Checked BEFORE password auth / 2FA.
 */
declare(strict_types=1);

function smsCaptchaEnabled(): bool
{
    return smsSetting('login_captcha_enabled', '1') === '1';
}

function smsCaptchaProvider(): string
{
    $site = trim(smsSetting('turnstile_site_key', ''));
    $secret = trim(smsSetting('turnstile_secret_key', ''));
    if ($site !== '' && $secret !== '') {
        return 'turnstile';
    }
    return 'local';
}

function smsCaptchaSiteKey(): string
{
    return trim(smsSetting('turnstile_site_key', ''));
}

/**
 * Issue a one-click challenge token into the session.
 * @return array{token:string}
 */
function smsCaptchaLocalIssue(): array
{
    $token = bin2hex(random_bytes(16));
    $_SESSION['sms_captcha_local'] = [
        'token' => $token,
        'at' => time(),
        'verified' => 0,
    ];
    return ['token' => $token];
}

/**
 * Mark local captcha as clicked (called from tiny JSON endpoint or same-request).
 */
function smsCaptchaLocalMarkVerified(string $token): bool
{
    $stored = $_SESSION['sms_captcha_local'] ?? null;
    if (!is_array($stored) || empty($stored['token'])) {
        return false;
    }
    if (!hash_equals((string) $stored['token'], $token)) {
        return false;
    }
    if (((int) ($stored['at'] ?? 0) + 600) < time()) {
        return false;
    }
    // Require a short human pause (blocks instant scripted submits)
    if ((time() - (int) $stored['at']) < 1) {
        return false;
    }
    $_SESSION['sms_captcha_local']['verified'] = 1;
    $_SESSION['sms_captcha_local']['verified_at'] = time();
    return true;
}

/**
 * @return array{ok:bool,error:string}
 */
function smsCaptchaVerifyRequest(): array
{
    if (!smsCaptchaEnabled()) {
        return ['ok' => true, 'error' => ''];
    }

    // Honeypot — real users never fill this
    $hp = trim((string) ($_POST['captcha_hp'] ?? ''));
    if ($hp !== '') {
        return ['ok' => false, 'error' => 'CAPTCHA check failed. Please try again.'];
    }

    $provider = smsCaptchaProvider();

    if ($provider === 'turnstile') {
        $token = trim((string) ($_POST['cf-turnstile-response'] ?? ''));
        if ($token === '') {
            return ['ok' => false, 'error' => 'Please complete the CAPTCHA (one click) before signing in.'];
        }
        return smsCaptchaVerifyTurnstile($token);
    }

    // Local one-click checkbox
    $token = trim((string) ($_POST['captcha_token'] ?? ''));
    $clicked = trim((string) ($_POST['captcha_ok'] ?? ''));
    $stored = $_SESSION['sms_captcha_local'] ?? null;
    unset($_SESSION['sms_captcha_local']);

    if (!is_array($stored) || empty($stored['token'])) {
        return ['ok' => false, 'error' => 'CAPTCHA expired. Please refresh and try again.'];
    }
    if (((int) ($stored['at'] ?? 0) + 600) < time()) {
        return ['ok' => false, 'error' => 'CAPTCHA expired. Please refresh and try again.'];
    }
    if (!hash_equals((string) $stored['token'], $token)) {
        return ['ok' => false, 'error' => 'CAPTCHA check failed. Please try again.'];
    }
    if ($clicked !== '1' && empty($stored['verified'])) {
        return ['ok' => false, 'error' => 'Please click “Verify you are human” before signing in.'];
    }
    // Prefer session verified flag from click handler; also accept same-request click + delay
    if (!empty($stored['verified'])) {
        return ['ok' => true, 'error' => ''];
    }
    if ($clicked === '1' && (time() - (int) $stored['at']) >= 1) {
        return ['ok' => true, 'error' => ''];
    }

    return ['ok' => false, 'error' => 'Please click “Verify you are human” before signing in.'];
}

/**
 * Verify Turnstile token via Cloudflare siteverify API.
 * @return array{ok:bool,error:string}
 */
function smsCaptchaVerifyTurnstile(string $token): array
{
    $secret = trim(smsSetting('turnstile_secret_key', ''));
    if ($secret === '') {
        return ['ok' => false, 'error' => 'CAPTCHA is not configured.'];
    }

    $payload = http_build_query([
        'secret' => $secret,
        'response' => $token,
        'remoteip' => smsClientIp(),
    ]);

    $raw = '';
    if (function_exists('curl_init')) {
        $ch = curl_init('https://challenges.cloudflare.com/turnstile/v0/siteverify');
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 8,
            CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded'],
        ]);
        $raw = (string) curl_exec($ch);
        $err = curl_error($ch);
        curl_close($ch);
        if ($raw === '' && $err !== '') {
            return ['ok' => false, 'error' => 'Could not reach CAPTCHA service. Try again.'];
        }
    } else {
        $ctx = stream_context_create([
            'http' => [
                'method' => 'POST',
                'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
                'content' => $payload,
                'timeout' => 8,
            ],
        ]);
        $raw = (string) @file_get_contents('https://challenges.cloudflare.com/turnstile/v0/siteverify', false, $ctx);
        if ($raw === '') {
            return ['ok' => false, 'error' => 'Could not reach CAPTCHA service. Try again.'];
        }
    }

    $data = json_decode($raw, true);
    if (!is_array($data) || empty($data['success'])) {
        return ['ok' => false, 'error' => 'CAPTCHA verification failed. Please try again.'];
    }

    return ['ok' => true, 'error' => ''];
}

/**
 * Render one-click CAPTCHA widget HTML for login form.
 */
function smsCaptchaMarkup(): string
{
    if (!smsCaptchaEnabled()) {
        return '';
    }

    // Shared honeypot (bots often fill every field)
    $honeypot = '<label class="sms-captcha-hp" aria-hidden="true">'
        . '<span>Leave blank</span>'
        . '<input type="text" name="captcha_hp" value="" tabindex="-1" autocomplete="off">'
        . '</label>';

    if (smsCaptchaProvider() === 'turnstile') {
        $siteKey = e(smsCaptchaSiteKey());
        return '<div class="mb-3 sms-captcha-wrap">'
            . $honeypot
            . '<label class="form-label fw-medium sms-captcha-label">Security check</label>'
            . '<div class="sms-captcha-frame">'
            . '<div class="cf-turnstile" data-sitekey="' . $siteKey
            . '" data-theme="light" data-size="flexible" data-appearance="always"></div>'
            . '</div>'
            . '</div>'
            . '<script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>';
    }

    $local = smsCaptchaLocalIssue();
    $token = e($local['token']);
    $api = e(BASE_URL . '/api/captcha.php');

    return '<div class="mb-3 sms-captcha-wrap">'
        . $honeypot
        . '<label class="form-label fw-medium sms-captcha-label" for="smsCaptchaWidget">Security check</label>'
        . '<input type="hidden" name="captcha_token" id="smsCaptchaToken" value="' . $token . '">'
        . '<input type="hidden" name="captcha_ok" id="smsCaptchaOk" value="0">'
        . '<button type="button" class="sms-cf-widget" id="smsCaptchaWidget" '
        . 'data-captcha-api="' . $api . '" aria-pressed="false" aria-label="Verify you are human">'
        . '<span class="sms-cf-box" id="smsCaptchaBox" aria-hidden="true">'
        . '<span class="sms-cf-spinner" hidden></span>'
        . '<span class="sms-cf-check" hidden><i class="fas fa-check"></i></span>'
        . '</span>'
        . '<span class="sms-cf-label">Verify you are human</span>'
        . '<span class="sms-cf-brand"><i class="fas fa-shield-alt" aria-hidden="true"></i>SMS 2</span>'
        . '</button>'
        . '</div>'
        . '<script src="' . e(BASE_URL . '/assets/js/sms-captcha.js?v=3') . '"></script>';
}
