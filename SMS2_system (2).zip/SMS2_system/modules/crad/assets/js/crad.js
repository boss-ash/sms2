(function () {
    document.querySelectorAll('[data-crad-dismiss]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var alert = btn.closest('.crad-alert');
            if (alert) {
                alert.classList.add('is-hiding');
                window.setTimeout(function () { alert.remove(); }, 220);
            }
        });
    });

    var editDialog = document.getElementById('cradEditDialog');
    var editForm = document.getElementById('cradEditForm');
    var editableFields = [
        'id', 'title', 'principal', 'field', 'abstract', 'budget', 'documents', 'collaborators'
    ];

    document.querySelectorAll('[data-crad-edit]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            if (!editDialog || !editForm) return;

            editableFields.forEach(function (name) {
                var value = btn.getAttribute('data-field-' + name);
                var input = editForm.querySelector('[name="' + name + '"]');
                if (input) input.value = value || '';
            });

            editDialog.showModal();
            editDialog.classList.add('is-open');
            var titleInput = editForm.querySelector('[name="title"]');
            if (titleInput) {
                window.setTimeout(function () {
                    titleInput.focus();
                    titleInput.select();
                }, 40);
            }
        });
    });

    function closeEditDialog() {
        if (!editDialog) return;
        editDialog.classList.remove('is-open');
        editDialog.close();
    }

    document.querySelectorAll('[data-crad-edit-close]').forEach(function (btn) {
        btn.addEventListener('click', closeEditDialog);
    });

    if (editDialog) {
        editDialog.addEventListener('click', function (event) {
            if (event.target === editDialog) closeEditDialog();
        });
    }

    document.querySelectorAll('[data-crad-confirm]').forEach(function (form) {
        form.addEventListener('submit', function (event) {
            var message = form.getAttribute('data-crad-confirm');
            if (message && !window.confirm(message)) {
                event.preventDefault();
            }
        });
    });

    // Smooth scroll for pipeline steps on small screens toward active step
    var activeStep = document.querySelector('.crad-pipeline__step.is-active');
    var track = document.querySelector('.crad-pipeline__track');
    if (activeStep && track && track.scrollWidth > track.clientWidth) {
        activeStep.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
    }

    var printBtn = document.getElementById('cradPrintBtn');
    var printDialog = document.getElementById('cradPrintDialog');
    var printClose = document.getElementById('cradPrintClose');
    var printCancel = document.getElementById('cradPrintCancel');
    var printConfirm = document.getElementById('cradPrintConfirm');
    var downloadBtn = document.getElementById('cradDownloadDocBtn');
    var printFrame = document.getElementById('cradPrintFrame');

    if (printBtn) {
        printBtn.addEventListener('click', function () {
            if (printDialog) printDialog.showModal();
        });
    }

    function closePrintPreview() {
        if (printDialog) printDialog.close();
    }

    if (printClose) printClose.addEventListener('click', closePrintPreview);
    if (printCancel) printCancel.addEventListener('click', closePrintPreview);
    if (printConfirm) {
        printConfirm.addEventListener('click', function () {
            window.print();
        });
    }
    if (printDialog) {
        printDialog.addEventListener('click', function (event) {
            if (event.target === printDialog) closePrintPreview();
        });
    }

    if (downloadBtn && printFrame) {
        downloadBtn.addEventListener('click', function () {
            var sheet = printFrame.querySelector('.crad-print-sheet');
            if (!sheet) return;

            var titleEl = sheet.querySelector('h1');
            var fileName = ((titleEl && titleEl.textContent) || 'CRAD-Document')
                .replace(/[^\w\-]+/g, '_')
                .replace(/_+/g, '_')
                .replace(/^_|_$/g, '');

            var html = '<!DOCTYPE html><html><head><meta charset="utf-8"><title>'
                + (titleEl ? titleEl.textContent : 'CRAD Document')
                + '</title><style>'
                + 'body{font-family:Arial,sans-serif;color:#0f172a;padding:24px;}'
                + 'h1{font-size:22px;margin:0 0 8px;} h3{margin:0 0 8px;}'
                + 'table{width:100%;border-collapse:collapse;} th,td{border:1px solid #dbe3ef;padding:8px;text-align:left;}'
                + '.crad-letterhead{display:grid;grid-template-columns:72px 1fr 72px;align-items:center;gap:12px;border-bottom:2px solid #1e40af;padding-bottom:12px;}'
                + '.crad-letterhead__logo img{width:58px;max-height:64px;object-fit:contain;}'
                + '.crad-letterhead__center{text-align:center}.crad-letterhead__center p{margin:0;line-height:1.25;}'
                + '.crad-letterhead__school{font-weight:800;font-size:16px}.crad-letterhead__address,.crad-letterhead__program{font-size:10px}.crad-letterhead__college{font-weight:700;margin-top:5px!important;}'
                + '.crad-print-sheet__title{text-align:center;padding:14px 0 7px}.crad-print-sheet__title p{font-size:11px;color:#64748b;}'
                + '.crad-print-sheet__date{font-size:12px;color:#334155;}'
                + '.crad-print-sheet__info{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:16px 0;}'
                + '.crad-print-sheet__foot{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:28px;padding-top:16px;border-top:1px solid #e2e8f0;}'
                + 'span{display:block;color:#64748b;font-size:11px;text-transform:uppercase;}'
                + '</style></head><body>'
                + sheet.outerHTML
                + '</body></html>';

            var blob = new Blob([html], { type: 'text/html;charset=utf-8' });
            var url = URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url;
            a.download = fileName + '.html';
            document.body.appendChild(a);
            a.click();
            a.remove();
            URL.revokeObjectURL(url);
        });
    }
})();
