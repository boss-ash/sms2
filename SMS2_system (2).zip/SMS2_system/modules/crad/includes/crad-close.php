<?php
/**
 * Close CRAD layout and load module scripts.
 */
$cradRedirect = htmlspecialchars($_SERVER['REQUEST_URI'] ?? BASE_URL . '/modules/crad/index.php');
?>
<dialog class="crad-edit-dialog" id="cradEditDialog" aria-labelledby="cradEditTitle">
    <form method="post" class="crad-edit-dialog__form" id="cradEditForm">
        <input type="hidden" name="crad_action" value="save">
        <input type="hidden" name="id" value="">
        <input type="hidden" name="redirect" value="<?= $cradRedirect ?>">

        <header class="crad-edit-dialog__head">
            <div>
                <h2 id="cradEditTitle">Edit record</h2>
            </div>
            <button type="button" class="crad-dialog-close" data-crad-edit-close aria-label="Close">
                <i class="fas fa-times"></i>
            </button>
        </header>

        <div class="crad-edit-dialog__body">
            <div class="crad-form-row">
                <div class="crad-field">
                    <label for="cradEditResearchTitle">Title</label>
                    <input id="cradEditResearchTitle" name="title" required>
                </div>
                <div class="crad-field">
                    <label for="cradEditPrincipal">Principal investigator</label>
                    <input id="cradEditPrincipal" name="principal" required>
                </div>
            </div>
            <div class="crad-form-row">
                <div class="crad-field">
                    <label for="cradEditField">Field</label>
                    <select id="cradEditField" name="field">
                        <?php foreach (['Education', 'ICT', 'Data Science', 'Health', 'Public Health', 'Biology', 'Business', 'Social Science', 'Engineering', 'Policy'] as $field): ?>
                            <option value="<?= htmlspecialchars($field) ?>"><?= htmlspecialchars($field) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="crad-field">
                    <label for="cradEditBudget">Budget (₱)</label>
                    <input id="cradEditBudget" type="number" min="0" step="1000" name="budget">
                </div>
            </div>
            <div class="crad-field">
                <label for="cradEditAbstract">Abstract</label>
                <textarea id="cradEditAbstract" name="abstract" rows="4"></textarea>
            </div>
            <div class="crad-form-row">
                <div class="crad-field">
                    <label for="cradEditDocuments">Documents</label>
                    <input id="cradEditDocuments" name="documents" placeholder="Comma-separated">
                </div>
                <div class="crad-field">
                    <label for="cradEditCollaborators">Collaborators</label>
                    <input id="cradEditCollaborators" name="collaborators" placeholder="Comma-separated">
                </div>
            </div>
        </div>

        <footer class="crad-edit-dialog__foot">
            <button type="button" class="crad-btn crad-btn--ghost" data-crad-edit-close>Cancel</button>
            <button type="submit" class="crad-btn crad-btn--primary">
                <i class="fas fa-check"></i>Update
            </button>
        </footer>
    </form>
</dialog>
<script src="<?= htmlspecialchars(BASE_URL . '/modules/crad/assets/js/crad.js') ?>"></script>
<?php require_once ROOT_PATH . '/includes/layout-end.php'; ?>
