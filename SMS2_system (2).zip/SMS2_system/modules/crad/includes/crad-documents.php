<?php
/**
 * CRAD printable document templates.
 */

function cradDocumentTypes(): array
{
    return [
        'proposal' => 'Research Proposal',
        'ethics' => 'Ethics Clearance Form',
        'budget' => 'Budget Summary',
        'assessment' => 'Assessment Report',
        'grant' => 'Grant Award Sheet',
        'collaboration' => 'Collaboration Agreement',
        'final_report' => 'Final Research Report',
    ];
}

function cradDocumentTypeLabel(string $type): string
{
    $types = cradDocumentTypes();
    return $types[$type] ?? 'Research Document';
}

function cradDocumentLogoDataUri(string $filename): string
{
    $path = dirname(__DIR__) . '/assets/img/' . basename($filename);
    if (!is_file($path)) {
        return '';
    }
    $data = file_get_contents($path);
    return $data === false ? '' : 'data:image/png;base64,' . base64_encode($data);
}

function cradBuildDocumentHtml(array $record, string $type): string
{
    $title = cradDocumentTypeLabel($type);
    $ref = htmlspecialchars((string) ($record['id'] ?? ''));
    $researchTitle = htmlspecialchars((string) ($record['title'] ?? ''));
    $principal = htmlspecialchars((string) ($record['principal'] ?? ''));
    $field = htmlspecialchars((string) ($record['field'] ?? ''));
    $abstract = htmlspecialchars((string) ($record['abstract'] ?? ''));
    $budget = cradMoney((float) ($record['budget'] ?? 0));
    $advisor = htmlspecialchars((string) (($record['advisor_name'] ?? '') !== '' ? $record['advisor_name'] : 'To be assigned'));
    $score = $record['assessment_score'] === null ? 'Pending' : htmlspecialchars((string) $record['assessment_score']);
    $grant = htmlspecialchars((string) (($record['grant_status'] ?? '') !== '' ? ucfirst((string) $record['grant_status']) : 'Pending'));
    $funding = htmlspecialchars((string) (($record['funding_match'] ?? '') !== '' ? $record['funding_match'] : 'Not matched'));
    $amount = cradMoney((float) ($record['funding_amount'] ?? 0));
    $collabs = htmlspecialchars(implode(', ', (array) ($record['collaborators'] ?? [])) ?: 'None listed');
    $docs = htmlspecialchars(implode(', ', (array) ($record['documents'] ?? [])) ?: 'None saved yet');
    $date = date('F j, Y');
    $institution = defined('INSTITUTION') ? htmlspecialchars(INSTITUTION) : 'Bestlink College of the Philippines';
    $bcpLogo = cradDocumentLogoDataUri('bcp-logo.png');
    $ccsLogo = cradDocumentLogoDataUri('ccs-logo.png');
    $bcpLogoHtml = $bcpLogo !== '' ? '<img src="' . $bcpLogo . '" alt="BCP logo">' : '';
    $ccsLogoHtml = $ccsLogo !== '' ? '<img src="' . $ccsLogo . '" alt="College logo">' : '';

    $body = '';
    switch ($type) {
        case 'ethics':
            $body = '
                <h3>Ethics Clearance</h3>
                <p>This form certifies ethics review readiness for the research titled <strong>' . $researchTitle . '</strong>.</p>
                <ul>
                    <li>Informed consent procedures prepared</li>
                    <li>Data privacy and confidentiality controls stated</li>
                    <li>Risk mitigation and participant protection reviewed</li>
                </ul>
                <p><strong>Advisor:</strong> ' . $advisor . '</p>
                <p><strong>Clearance status:</strong> For review / issuance</p>';
            break;
        case 'budget':
            $body = '
                <h3>Budget Summary</h3>
                <table class="crad-print-table">
                    <tr><th>Item</th><th>Amount</th></tr>
                    <tr><td>Proposed research budget</td><td>' . $budget . '</td></tr>
                    <tr><td>Matched funding amount</td><td>' . $amount . '</td></tr>
                    <tr><td>Funding source</td><td>' . $funding . '</td></tr>
                </table>';
            break;
        case 'assessment':
            $body = '
                <h3>Assessment Report</h3>
                <p><strong>Assessment score:</strong> ' . $score . '</p>
                <p><strong>Notes:</strong> ' . htmlspecialchars((string) (($record['assessment_notes'] ?? '') !== '' ? $record['assessment_notes'] : 'No notes recorded')) . '</p>
                <p><strong>Advisor:</strong> ' . $advisor . '</p>
                <p>This report summarizes technical and ethics readiness for continued processing.</p>';
            break;
        case 'grant':
            $body = '
                <h3>Grant Award Sheet</h3>
                <p><strong>Grant status:</strong> ' . $grant . '</p>
                <p><strong>Funding match:</strong> ' . $funding . '</p>
                <p><strong>Award amount:</strong> ' . $amount . '</p>
                <p>Prepared for CRAD grant processing and release documentation.</p>';
            break;
        case 'collaboration':
            $body = '
                <h3>Collaboration Agreement</h3>
                <p>Partners / collaborators: <strong>' . $collabs . '</strong></p>
                <p>This agreement covers shared research roles, data handling, and publication credit for <strong>' . $researchTitle . '</strong>.</p>';
            break;
        case 'final_report':
            $body = '
                <h3>Final Research Report</h3>
                <p>' . ($abstract !== '' ? $abstract : 'No abstract provided.') . '</p>
                <p><strong>Saved documents:</strong> ' . $docs . '</p>
                <p><strong>Repository DOI:</strong> ' . htmlspecialchars((string) (($record['repository_doi'] ?? '') !== '' ? $record['repository_doi'] : 'Pending')) . '</p>';
            break;
        case 'proposal':
        default:
            $body = '
                <h3>Research Proposal</h3>
                <p>' . ($abstract !== '' ? $abstract : 'No abstract provided.') . '</p>
                <p><strong>Proposed budget:</strong> ' . $budget . '</p>
                <p><strong>Assigned advisor:</strong> ' . $advisor . '</p>';
            break;
    }

    return '
        <div class="crad-print-sheet" id="cradPrintSheet">
            <header class="crad-letterhead">
                <div class="crad-letterhead__logo">' . $bcpLogoHtml . '</div>
                <div class="crad-letterhead__center">
                    <p class="crad-letterhead__school">' . $institution . '</p>
                    <p class="crad-letterhead__address">1071 Brgy. Kaligayahan, Quirino Highway, Novaliches, Quezon City</p>
                    <p class="crad-letterhead__college">College of Computing Studies</p>
                    <p class="crad-letterhead__program">Center for Research and Development</p>
                </div>
                <div class="crad-letterhead__logo">' . $ccsLogoHtml . '</div>
            </header>
            <div class="crad-print-sheet__title">
                <h1>' . htmlspecialchars($title) . '</h1>
                <p>' . $ref . '</p>
            </div>
            <div class="crad-print-sheet__date"><strong>Date:</strong> ' . $date . '</div>
            <section class="crad-print-sheet__info">
                <div><span>Title</span><strong>' . $researchTitle . '</strong></div>
                <div><span>Principal</span><strong>' . $principal . '</strong></div>
                <div><span>Field</span><strong>' . $field . '</strong></div>
                <div><span>Stage</span><strong>' . htmlspecialchars(ucfirst((string) ($record['stage'] ?? 'proposal'))) . '</strong></div>
            </section>
            <section class="crad-print-sheet__body">' . $body . '</section>
            <footer class="crad-print-sheet__foot">
                <div>
                    <p>Prepared by</p>
                    <strong>________________________</strong>
                </div>
                <div>
                    <p>Approved by</p>
                    <strong>________________________</strong>
                </div>
            </footer>
        </div>';
}
