<?php
/**
 * Bootstrap for CRAD pages — config, core, and shared UI helpers.
 */
require_once __DIR__ . '/../../../config/config.php';
require_once __DIR__ . '/crad-core.php';
require_once __DIR__ . '/crad-ui.php';

function cradRenderFlash(): void
{
    $flash = cradFlash();
    if (!$flash) {
        return;
    }
    $type = $flash['type'] ?? 'success';
    echo '<div class="crad-alert crad-alert--' . htmlspecialchars($type) . '" role="alert">';
    echo '<i class="fas fa-info-circle"></i><span>' . htmlspecialchars($flash['message']) . '</span>';
    echo '<button type="button" class="crad-alert__close" data-crad-dismiss>&times;</button>';
    echo '</div>';
}

function cradPipelineNav(string $currentStage = ''): void
{
    $stages = cradStages();
    $stats = cradStats();
    $keys = array_keys($stages);
    $currentIdx = $currentStage !== '' ? array_search($currentStage, $keys, true) : false;

    echo '<nav class="crad-pipeline" aria-label="CRAD stations">';
    echo '<div class="crad-pipeline__track">';
    $i = 0;
    foreach ($stages as $key => $stage) {
        $i++;
        $classes = 'crad-pipeline__step';
        if ($currentStage === $key) {
            $classes .= ' is-active';
        } elseif ($currentIdx !== false && ($i - 1) < $currentIdx) {
            $classes .= ' is-done';
        }
        $count = (int) ($stats['by_stage'][$key] ?? 0);
        $href = BASE_URL . '/modules/crad/pages/' . $stage['slug'] . '.php';
        echo '<a class="' . $classes . '" href="' . htmlspecialchars($href) . '">';
        echo '<span class="crad-pipeline__index">' . $i . '</span>';
        echo '<span class="crad-pipeline__label">' . htmlspecialchars($stage['label']) . '</span>';
        echo '<span class="crad-pipeline__count">' . $count . '</span>';
        echo '</a>';
    }
    echo '</div></nav>';
}

function cradCrumbs(string $pageLabel): array
{
    return [
        ['label' => 'CRAD', 'url' => BASE_URL . '/modules/crad/index.php'],
        ['label' => $pageLabel, 'url' => null],
    ];
}
