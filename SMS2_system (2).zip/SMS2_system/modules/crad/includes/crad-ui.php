<?php
/**
 * Shared CRAD UI partials for stage pages.
 */

function cradRenderStats(): void
{
    $stats = cradStats();
    $cards = [
        ['Records', (string) $stats['total'], ''],
        ['Active', (string) $stats['active'], ''],
        ['Completed', (string) $stats['completed'], ''],
        ['Archived', (string) ($stats['archived'] ?? 0), ''],
    ];
    echo '<div class="crad-stats">';
    foreach ($cards as $card) {
        echo '<article class="crad-stat">';
        echo '<div class="crad-stat__label">' . htmlspecialchars($card[0]) . '</div>';
        echo '<div class="crad-stat__value">' . htmlspecialchars($card[1]) . '</div>';
        echo '</article>';
    }
    echo '</div>';
}

function cradRecordRows(array $records, string $stage, array $extraCols = []): void
{
    if ($records === []) {
        echo '<div class="crad-empty"><i class="fas fa-inbox fa-lg d-block"></i><strong>No records</strong></div>';
        return;
    }

    echo '<div class="crad-table-wrap"><table class="crad-table"><thead><tr>';
    echo '<th>Reference</th><th>Title / Principal</th><th>Stage</th><th>Status</th>';
    foreach ($extraCols as $col) {
        echo '<th>' . htmlspecialchars($col['label']) . '</th>';
    }
    echo '<th>Actions</th></tr></thead><tbody>';

    foreach ($records as $record) {
        echo '<tr>';
        echo '<td data-label="Reference"><strong>' . htmlspecialchars($record['id']) . '</strong><br><small>' . htmlspecialchars(cradFormatDate($record['updated_at'] ?? null)) . '</small></td>';
        echo '<td data-label="Title / Principal"><strong>' . htmlspecialchars($record['title']) . '</strong><br><small>' . htmlspecialchars($record['principal']) . ' · ' . htmlspecialchars($record['field']) . '</small></td>';
        echo '<td data-label="Stage">' . cradStageBadge($record['stage'] ?? 'proposal') . '</td>';
        echo '<td data-label="Status">' . cradStatusBadge($record['status'] ?? 'draft') . '</td>';
        foreach ($extraCols as $col) {
            $key = $col['key'];
            $value = $record[$key] ?? '—';
            if (is_array($value)) {
                $value = implode(', ', $value);
            }
            if (($col['format'] ?? '') === 'money') {
                $value = cradMoney((float) $value);
            }
            echo '<td data-label="' . htmlspecialchars($col['label']) . '">' . htmlspecialchars((string) ($value === '' || $value === null ? '—' : $value)) . '</td>';
        }
        echo '<td data-label="Actions"><div class="crad-actions">';
        cradStageActions($record, $stage);
        echo '</div></td>';
        echo '</tr>';
    }
    echo '</tbody></table></div>';
}

function cradStageActions(array $record, string $stage): void
{
    $id = htmlspecialchars((string) ($record['id'] ?? ''));
    $self = htmlspecialchars($_SERVER['REQUEST_URI'] ?? '');

    if (cradIsArchived($record)) {
        $days = cradArchiveDaysLeft($record);
        if ($days > 0) {
            echo '<form method="post" class="crad-action-form">';
            echo '<input type="hidden" name="crad_action" value="restore">';
            echo '<input type="hidden" name="id" value="' . $id . '">';
            echo '<input type="hidden" name="redirect" value="' . $self . '">';
            echo '<button class="crad-btn crad-btn--primary crad-btn--small" type="submit"><i class="fas fa-undo"></i><span>Restore</span></button>';
            echo '</form>';
            echo '<span class="crad-days-left">' . $days . ' day' . ($days === 1 ? '' : 's') . ' left</span>';
        } else {
            echo '<span class="crad-days-left crad-days-left--expired">Restore expired</span>';
        }

        echo '<form method="post" class="crad-action-form" data-crad-confirm="Permanently delete this archived record? This cannot be undone.">';
        echo '<input type="hidden" name="crad_action" value="delete">';
        echo '<input type="hidden" name="id" value="' . $id . '">';
        echo '<input type="hidden" name="redirect" value="' . $self . '">';
        echo '<button class="crad-btn crad-btn--danger crad-btn--small" type="submit"><i class="fas fa-trash"></i><span>Delete</span></button>';
        echo '</form>';
        return;
    }

    echo '<button type="button" class="crad-btn crad-btn--primary crad-btn--small" data-crad-edit';
    $fields = ['id', 'title', 'principal', 'field', 'abstract', 'budget'];
    foreach ($fields as $field) {
        $val = $record[$field] ?? '';
        if (is_array($val)) {
            $val = implode(', ', $val);
        }
        echo ' data-field-' . $field . '="' . htmlspecialchars((string) $val, ENT_QUOTES) . '"';
    }
    echo ' data-field-documents="' . htmlspecialchars(implode(', ', (array) ($record['documents'] ?? [])), ENT_QUOTES) . '"';
    echo ' data-field-collaborators="' . htmlspecialchars(implode(', ', (array) ($record['collaborators'] ?? [])), ENT_QUOTES) . '"';
    echo ' aria-label="Edit ' . htmlspecialchars($record['title'], ENT_QUOTES) . '">';
    echo '<i class="fas fa-pen"></i><span>Edit</span></button>';

    echo '<form method="post" class="crad-action-form" data-crad-confirm="Archive this record? You can restore it within 30 days.">';
    echo '<input type="hidden" name="crad_action" value="archive">';
    echo '<input type="hidden" name="id" value="' . $id . '">';
    echo '<input type="hidden" name="redirect" value="' . $self . '">';
    echo '<button class="crad-btn crad-btn--ghost crad-btn--small" type="submit"><i class="fas fa-box-archive"></i><span>Archive</span></button>';
    echo '</form>';
}

function cradArchivedBin(): void
{
    $archived = cradArchivedRecords();
    echo '<section class="crad-panel crad-panel--archive">';
    echo '<div class="crad-panel__head"><div>';
    echo '<h2>Archived</h2>';
    echo '<p>Restore within 30 days, or delete permanently.</p>';
    echo '</div></div>';
    echo '<div class="crad-panel__body">';
    if ($archived === []) {
        echo '<div class="crad-empty"><strong>No archived records</strong></div>';
    } else {
        cradRecordRows($archived, 'archive');
    }
    echo '</div></section>';
}

function cradProposalForm(): void
{
    $self = htmlspecialchars($_SERVER['REQUEST_URI'] ?? '');
    echo '<form method="post" class="crad-form" id="cradMainForm">';
    echo '<input type="hidden" name="crad_action" value="save">';
    echo '<input type="hidden" name="id" value="">';
    echo '<input type="hidden" name="redirect" value="' . $self . '">';
    echo '<div class="crad-form-row">';
    echo '<div class="crad-field"><label>Title</label><input name="title" required></div>';
    echo '<div class="crad-field"><label>Principal investigator</label><input name="principal" required></div>';
    echo '</div><div class="crad-form-row">';
    echo '<div class="crad-field"><label>Field</label><select name="field">';
    foreach (['Education', 'ICT', 'Data Science', 'Health', 'Public Health', 'Biology', 'Business', 'Social Science', 'Engineering', 'Policy'] as $field) {
        echo '<option value="' . htmlspecialchars($field) . '">' . htmlspecialchars($field) . '</option>';
    }
    echo '</select></div>';
    echo '<div class="crad-field"><label>Budget (₱)</label><input type="number" min="0" step="1000" name="budget" value="150000"></div>';
    echo '</div>';
    echo '<div class="crad-field"><label>Abstract</label><textarea name="abstract" rows="3"></textarea></div>';
    echo '<div class="crad-form-row">';
    echo '<div class="crad-field"><label>Documents</label><input name="documents" placeholder="Comma-separated"></div>';
    echo '<div class="crad-field"><label>Collaborators</label><input name="collaborators" placeholder="Comma-separated"></div>';
    echo '</div>';
    echo '<div class="crad-actions crad-actions--form">';
    echo '<button class="crad-btn crad-btn--ghost" type="submit">Save draft</button>';
    echo '<button class="crad-btn crad-btn--primary" type="submit" name="submit_pipeline" value="1"><i class="fas fa-plus"></i>Create</button>';
    echo '</div></form>';
}

function cradRecentTimeline(int $limit = 8): void
{
    $events = [];
    foreach (cradGetStore()['records'] as $record) {
        foreach ((array) ($record['timeline'] ?? []) as $item) {
            $events[] = [
                'at' => $item['at'] ?? '',
                'event' => ($record['id'] ?? '') . ' — ' . ($item['event'] ?? ''),
            ];
        }
    }
    usort($events, static fn($a, $b) => strcmp($b['at'], $a['at']));
    $events = array_slice($events, 0, $limit);

    echo '<ul class="crad-timeline">';
    if ($events === []) {
        echo '<li><strong>No activity yet</strong><time>Submit a proposal to see progress updates here</time></li>';
    }
    foreach ($events as $event) {
        echo '<li><strong>' . htmlspecialchars($event['event']) . '</strong><time>' . htmlspecialchars(cradFormatDate($event['at'])) . '</time></li>';
    }
    echo '</ul>';
}
