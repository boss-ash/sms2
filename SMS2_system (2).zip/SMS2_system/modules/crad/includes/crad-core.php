<?php
/**
 * CRAD core — data store, automatic research pipeline, CRUD helpers.
 * Automatic flow inspired by international RIMS (proposal → review → fund → publish → archive).
 */

if (!defined('CRAD_LOADED')) {
    define('CRAD_LOADED', true);
}

define('CRAD_DATA_DIR', dirname(__DIR__) . '/data');
define('CRAD_DATA_FILE', CRAD_DATA_DIR . '/research-store.json');

/** Ordered automatic pipeline stages */
function cradStages(): array
{
    return [
        'proposal' => [
            'label' => 'Research Proposal',
            'slug' => 'research-proposal',
            'icon' => 'fa-file-signature',
            'desc' => 'Capture and submit research proposals',
        ],
        'advisor' => [
            'label' => 'Advisor',
            'slug' => 'advisor',
            'icon' => 'fa-user-tie',
            'desc' => 'Automatic adviser matching by expertise and load',
        ],
        'assessment' => [
            'label' => 'Assessment',
            'slug' => 'assessment',
            'icon' => 'fa-clipboard-check',
            'desc' => 'Ethics and technical review queue',
        ],
        'system' => [
            'label' => 'System',
            'slug' => 'system',
            'icon' => 'fa-cogs',
            'desc' => 'Compliance checks and auto-routing rules',
        ],
        'grant' => [
            'label' => 'Research Grant',
            'slug' => 'research-grant',
            'icon' => 'fa-hand-holding-usd',
            'desc' => 'Grant eligibility and award tracking',
        ],
        'funding' => [
            'label' => 'Funding Assistant',
            'slug' => 'funding-assistant',
            'icon' => 'fa-coins',
            'desc' => 'Automatic funding source matching',
        ],
        'document' => [
            'label' => 'Document',
            'slug' => 'document',
            'icon' => 'fa-print',
            'desc' => 'Print and save research documents',
        ],
        'publication' => [
            'label' => 'Public Management',
            'slug' => 'public-management',
            'icon' => 'fa-bullhorn',
            'desc' => 'Publication and public release',
        ],
        'collaboration' => [
            'label' => 'Research Collaboration Portal',
            'slug' => 'research-collaboration-portal',
            'icon' => 'fa-handshake',
            'desc' => 'Partner and co-investigator links',
        ],
        'repository' => [
            'label' => 'Research Repository',
            'slug' => 'research-repository',
            'icon' => 'fa-archive',
            'desc' => 'Final archival and open access deposit',
        ],
    ];
}

function cradStageKeys(): array
{
    return array_keys(cradStages());
}

function cradNextStage(?string $stage): ?string
{
    $keys = cradStageKeys();
    $idx = array_search($stage, $keys, true);
    if ($idx === false || $idx >= count($keys) - 1) {
        return null;
    }
    return $keys[$idx + 1];
}

function cradStageIndex(string $stage): int
{
    $idx = array_search($stage, cradStageKeys(), true);
    return $idx === false ? 0 : (int) $idx;
}

function cradDefaultSettings(): array
{
    return [
        'auto_flow' => true,
        'auto_assign_advisor' => true,
        'auto_queue_assessment' => true,
        'auto_system_check' => true,
        'auto_match_funding' => true,
        'auto_archive_repository' => true,
        'max_advisor_load' => 5,
        'assessment_sla_days' => 7,
        'updated_at' => date('c'),
    ];
}

function cradSeedAdvisors(): array
{
    return [
        [
            'id' => 'adv-001',
            'name' => 'Dr. Elena Marquez',
            'expertise' => ['Education', 'Social Science', 'Policy'],
            'department' => 'College of Education',
            'load' => 2,
            'status' => 'available',
            'email' => 'elena.marquez@bestlink.edu.ph',
        ],
        [
            'id' => 'adv-002',
            'name' => 'Prof. James Okonkwo',
            'expertise' => ['ICT', 'Data Science', 'Engineering'],
            'department' => 'College of Computer Studies',
            'load' => 3,
            'status' => 'available',
            'email' => 'james.okonkwo@bestlink.edu.ph',
        ],
        [
            'id' => 'adv-003',
            'name' => 'Dr. Aisha Rahman',
            'expertise' => ['Health', 'Biology', 'Public Health'],
            'department' => 'College of Allied Health',
            'load' => 1,
            'status' => 'available',
            'email' => 'aisha.rahman@bestlink.edu.ph',
        ],
        [
            'id' => 'adv-004',
            'name' => 'Prof. Hiro Tanaka',
            'expertise' => ['Business', 'Economics', 'Management'],
            'department' => 'College of Business',
            'load' => 4,
            'status' => 'available',
            'email' => 'hiro.tanaka@bestlink.edu.ph',
        ],
    ];
}

function cradSeedFundingSources(): array
{
    return [
        ['id' => 'fund-ched', 'name' => 'CHED Research Grant', 'type' => 'National', 'max_amount' => 500000, 'fields' => ['Education', 'Social Science', 'Policy']],
        ['id' => 'fund-dost', 'name' => 'DOST Grants-in-Aid', 'type' => 'National', 'max_amount' => 1000000, 'fields' => ['ICT', 'Engineering', 'Data Science', 'Health']],
        ['id' => 'fund-horizon', 'name' => 'Horizon Partner Match', 'type' => 'International', 'max_amount' => 2500000, 'fields' => ['Health', 'Climate', 'ICT', 'Education']],
        ['id' => 'fund-nrf', 'name' => 'NRF Collaborative Seed', 'type' => 'International', 'max_amount' => 750000, 'fields' => ['Biology', 'Public Health', 'Business']],
        ['id' => 'fund-inst', 'name' => 'Institutional Research Seed Fund', 'type' => 'Institutional', 'max_amount' => 150000, 'fields' => ['Education', 'Business', 'ICT', 'Health', 'Social Science']],
    ];
}

function cradSeedRecords(): array
{
    $now = time();
    return [
        cradMakeRecord([
            'title' => 'Adaptive Learning Outcomes in Blended Senior High Programs',
            'principal' => 'Sofia Reyes',
            'field' => 'Education',
            'abstract' => 'Evaluates adaptive learning tools across blended SHS cohorts using automated outcome tracking.',
            'budget' => 280000,
            'stage' => 'assessment',
            'status' => 'active',
            'created_at' => date('c', $now - 86400 * 12),
            'advisor_id' => 'adv-001',
            'advisor_name' => 'Dr. Elena Marquez',
            'assessment_score' => null,
            'grant_status' => 'pending',
            'funding_match' => 'CHED Research Grant',
            'documents' => ['Proposal PDF', 'Ethics Form'],
            'publication' => '',
            'collaborators' => ['DepEd Partner School'],
            'repository_doi' => '',
        ]),
        cradMakeRecord([
            'title' => 'Community Health Telemetry for Urban Barangays',
            'principal' => 'Mark Villanueva',
            'field' => 'Public Health',
            'abstract' => 'Deploys low-cost telemetry sensors and an automatic alert pipeline for barangay health units.',
            'budget' => 620000,
            'stage' => 'funding',
            'status' => 'active',
            'created_at' => date('c', $now - 86400 * 28),
            'advisor_id' => 'adv-003',
            'advisor_name' => 'Dr. Aisha Rahman',
            'assessment_score' => 88,
            'grant_status' => 'eligible',
            'funding_match' => 'DOST Grants-in-Aid',
            'documents' => ['Proposal PDF', 'Budget Sheet', 'Ethics Clearance'],
            'publication' => '',
            'collaborators' => ['City Health Office', 'NRF Lab'],
            'repository_doi' => '',
        ]),
        cradMakeRecord([
            'title' => 'Open Research Data Hub for Campus Innovation',
            'principal' => 'Angela Cruz',
            'field' => 'ICT',
            'abstract' => 'Builds an institutional open-data repository aligned with international FAIR deposit practices.',
            'budget' => 410000,
            'stage' => 'repository',
            'status' => 'completed',
            'created_at' => date('c', $now - 86400 * 60),
            'advisor_id' => 'adv-002',
            'advisor_name' => 'Prof. James Okonkwo',
            'assessment_score' => 92,
            'grant_status' => 'awarded',
            'funding_match' => 'Horizon Partner Match',
            'documents' => ['Final Report', 'Dataset Manifest', 'License'],
            'publication' => 'Campus Innovation Proceedings 2026',
            'collaborators' => ['CCS Research Cell', 'International Open Data Alliance'],
            'repository_doi' => '10.5281/bcp.crad.2026.014',
        ]),
    ];
}

function cradMakeRecord(array $input): array
{
    $id = $input['id'] ?? ('CRD-' . date('Y') . '-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 6)));
    $created = $input['created_at'] ?? date('c');
    return [
        'id' => $id,
        'title' => trim((string) ($input['title'] ?? 'Untitled Research')),
        'principal' => trim((string) ($input['principal'] ?? '')),
        'field' => trim((string) ($input['field'] ?? 'General')),
        'abstract' => trim((string) ($input['abstract'] ?? '')),
        'budget' => (float) ($input['budget'] ?? 0),
        'stage' => $input['stage'] ?? 'proposal',
        'status' => $input['status'] ?? 'draft',
        'advisor_id' => $input['advisor_id'] ?? '',
        'advisor_name' => $input['advisor_name'] ?? '',
        'assessment_score' => $input['assessment_score'] ?? null,
        'assessment_notes' => $input['assessment_notes'] ?? '',
        'grant_status' => $input['grant_status'] ?? 'pending',
        'funding_match' => $input['funding_match'] ?? '',
        'funding_amount' => (float) ($input['funding_amount'] ?? 0),
        'documents' => array_values((array) ($input['documents'] ?? [])),
        'publication' => $input['publication'] ?? '',
        'public_status' => $input['public_status'] ?? 'private',
        'collaborators' => array_values((array) ($input['collaborators'] ?? [])),
        'repository_doi' => $input['repository_doi'] ?? '',
        'archived_at' => $input['archived_at'] ?? null,
        'archive_expires_at' => $input['archive_expires_at'] ?? null,
        'status_before_archive' => $input['status_before_archive'] ?? null,
        'timeline' => $input['timeline'] ?? [
            ['at' => $created, 'event' => 'Record created', 'stage' => $input['stage'] ?? 'proposal'],
        ],
        'created_at' => $created,
        'updated_at' => $input['updated_at'] ?? date('c'),
    ];
}

function cradIsArchived(array $record): bool
{
    return !empty($record['archived_at']) || ($record['status'] ?? '') === 'archived';
}

function cradArchiveDaysLeft(array $record): int
{
    if (empty($record['archive_expires_at'])) {
        return 0;
    }
    $expires = strtotime((string) $record['archive_expires_at']);
    if (!$expires) {
        return 0;
    }
    return max(0, (int) ceil(($expires - time()) / 86400));
}

function cradActiveRecords(?array $records = null): array
{
    $records = $records ?? cradGetStore()['records'];
    return array_values(array_filter($records, static fn($r) => !cradIsArchived($r)));
}

function cradArchivedRecords(?array $records = null): array
{
    $records = $records ?? cradGetStore()['records'];
    return array_values(array_filter($records, static fn($r) => cradIsArchived($r)));
}

function cradSoftArchiveRecord(string $id): bool
{
    $store = cradGetStore();
    foreach ($store['records'] as $i => $row) {
        if (($row['id'] ?? '') !== $id) {
            continue;
        }
        if (cradIsArchived($row)) {
            return false;
        }
        $store['records'][$i]['status_before_archive'] = $row['status'] ?? 'active';
        $store['records'][$i]['status'] = 'archived';
        $store['records'][$i]['archived_at'] = date('c');
        $store['records'][$i]['archive_expires_at'] = date('c', strtotime('+30 days'));
        cradAddTimeline($store['records'][$i], 'Archived — restorable for 30 days');
        cradSaveStore($store);
        return true;
    }
    return false;
}

function cradRestoreRecord(string $id): bool
{
    $store = cradGetStore();
    foreach ($store['records'] as $i => $row) {
        if (($row['id'] ?? '') !== $id || !cradIsArchived($row)) {
            continue;
        }
        $daysLeft = cradArchiveDaysLeft($row);
        if ($daysLeft <= 0) {
            return false;
        }
        $store['records'][$i]['status'] = $row['status_before_archive'] ?: 'active';
        $store['records'][$i]['archived_at'] = null;
        $store['records'][$i]['archive_expires_at'] = null;
        $store['records'][$i]['status_before_archive'] = null;
        cradAddTimeline($store['records'][$i], 'Restored from archive');
        cradSaveStore($store);
        return true;
    }
    return false;
}

function cradEnsureStore(): array
{
    if (!is_dir(CRAD_DATA_DIR)) {
        mkdir(CRAD_DATA_DIR, 0775, true);
    }

    if (!is_file(CRAD_DATA_FILE)) {
        $store = [
            'settings' => cradDefaultSettings(),
            'advisors' => cradSeedAdvisors(),
            'funding_sources' => cradSeedFundingSources(),
            'records' => cradSeedRecords(),
        ];
        cradWriteStore($store);
        return $store;
    }

    $raw = file_get_contents(CRAD_DATA_FILE);
    $data = json_decode($raw ?: '{}', true);
    if (!is_array($data)) {
        $data = [];
    }

    $data['settings'] = array_merge(cradDefaultSettings(), (array) ($data['settings'] ?? []));
    $data['advisors'] = $data['advisors'] ?? cradSeedAdvisors();
    $data['funding_sources'] = $data['funding_sources'] ?? cradSeedFundingSources();
    $data['records'] = $data['records'] ?? cradSeedRecords();

    return $data;
}

function cradWriteStore(array $store): bool
{
    if (!is_dir(CRAD_DATA_DIR)) {
        mkdir(CRAD_DATA_DIR, 0775, true);
    }
    $json = json_encode($store, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    return file_put_contents(CRAD_DATA_FILE, $json, LOCK_EX) !== false;
}

function &cradStoreCacheRef()
{
    static $cache = null;
    if ($cache === null) {
        $cache = cradEnsureStore();
    }
    return $cache;
}

function cradGetStore(): array
{
    $ref = &cradStoreCacheRef();
    return $ref;
}

function cradSaveStore(array $store): void
{
    cradWriteStore($store);
    $ref = &cradStoreCacheRef();
    $ref = $store;
}

function cradReloadStore(): array
{
    clearstatcache(true, CRAD_DATA_FILE);
    $fresh = null;
    if (is_file(CRAD_DATA_FILE)) {
        // Force re-seed path by temporarily renaming if reset deleted file
    }
    $loaded = cradEnsureStore();
    // If file was deleted, ensureStore recreates it
    $ref = &cradStoreCacheRef();
    $ref = $loaded;
    return $ref;
}

function cradFindRecord(string $id): ?array
{
    foreach (cradGetStore()['records'] as $record) {
        if (($record['id'] ?? '') === $id) {
            return $record;
        }
    }
    return null;
}

function cradAddTimeline(array &$record, string $event, ?string $stage = null): void
{
    $record['timeline'][] = [
        'at' => date('c'),
        'event' => $event,
        'stage' => $stage ?? ($record['stage'] ?? 'proposal'),
    ];
    $record['updated_at'] = date('c');
}

function cradMatchAdvisor(array $record, array $advisors, int $maxLoad): ?array
{
    $field = strtolower((string) ($record['field'] ?? ''));
    $candidates = [];
    foreach ($advisors as $advisor) {
        if (($advisor['status'] ?? '') !== 'available') {
            continue;
        }
        if ((int) ($advisor['load'] ?? 0) >= $maxLoad) {
            continue;
        }
        $score = 0;
        foreach ((array) ($advisor['expertise'] ?? []) as $exp) {
            if (str_contains($field, strtolower($exp)) || str_contains(strtolower($exp), $field)) {
                $score += 10;
            }
        }
        $score += max(0, $maxLoad - (int) ($advisor['load'] ?? 0));
        $candidates[] = ['advisor' => $advisor, 'score' => $score];
    }
    if ($candidates === []) {
        return $advisors[0] ?? null;
    }
    usort($candidates, static fn($a, $b) => $b['score'] <=> $a['score']);
    return $candidates[0]['advisor'];
}

function cradMatchFunding(array $record, array $sources): ?array
{
    $field = strtolower((string) ($record['field'] ?? ''));
    $budget = (float) ($record['budget'] ?? 0);
    $best = null;
    $bestScore = -1;
    foreach ($sources as $source) {
        $score = 0;
        foreach ((array) ($source['fields'] ?? []) as $f) {
            if (str_contains($field, strtolower($f)) || str_contains(strtolower($f), $field)) {
                $score += 8;
            }
        }
        if ($budget > 0 && $budget <= (float) ($source['max_amount'] ?? 0)) {
            $score += 5;
        }
        if (($source['type'] ?? '') === 'International') {
            $score += 1; // prefer international-style matches when eligible
        }
        if ($score > $bestScore) {
            $bestScore = $score;
            $best = $source;
        }
    }
    return $best;
}

/**
 * Advance a record through the automatic pipeline.
 * $forceStage jumps to a stage; otherwise advances one step with auto side-effects.
 */
function cradAdvanceRecord(array &$record, array &$store, ?string $forceStage = null): void
{
    $settings = $store['settings'] ?? cradDefaultSettings();
    $auto = !empty($settings['auto_flow']);
    $keys = cradStageKeys();

    if ($forceStage !== null && in_array($forceStage, $keys, true)) {
        $record['stage'] = $forceStage;
    } elseif ($auto) {
        $next = cradNextStage($record['stage'] ?? 'proposal');
        if ($next !== null) {
            $record['stage'] = $next;
        }
    }

    $stage = $record['stage'] ?? 'proposal';

    if ($stage === 'advisor' || ($auto && empty($record['advisor_id']) && !empty($settings['auto_assign_advisor']))) {
        if (empty($record['advisor_id'])) {
            $advisor = cradMatchAdvisor($record, $store['advisors'], (int) ($settings['max_advisor_load'] ?? 5));
            if ($advisor) {
                $record['advisor_id'] = $advisor['id'];
                $record['advisor_name'] = $advisor['name'];
                foreach ($store['advisors'] as &$adv) {
                    if ($adv['id'] === $advisor['id']) {
                        $adv['load'] = (int) ($adv['load'] ?? 0) + 1;
                        break;
                    }
                }
                unset($adv);
                cradAddTimeline($record, 'Advisor auto-assigned: ' . $advisor['name'], 'advisor');
            }
        }
        if ($auto && $stage === 'advisor' && !empty($settings['auto_queue_assessment'])) {
            $record['stage'] = 'assessment';
            cradAddTimeline($record, 'Queued for assessment automatically', 'assessment');
            $stage = 'assessment';
        }
    }

    if ($stage === 'assessment' && $record['assessment_score'] === null && $auto) {
        // keep in assessment until scored; do not skip
    }

    if ($stage === 'system' && $auto && !empty($settings['auto_system_check'])) {
        cradAddTimeline($record, 'System compliance check passed (auto)', 'system');
        if ($auto) {
            $record['stage'] = 'grant';
            $stage = 'grant';
            cradAddTimeline($record, 'Moved to Research Grant automatically', 'grant');
        }
    }

    if (in_array($stage, ['grant', 'funding'], true) && $auto && !empty($settings['auto_match_funding'])) {
        if ($record['grant_status'] === 'pending' || $record['grant_status'] === '') {
            $record['grant_status'] = 'eligible';
        }
        if ($record['funding_match'] === '') {
            $fund = cradMatchFunding($record, $store['funding_sources']);
            if ($fund) {
                $record['funding_match'] = $fund['name'];
                $record['funding_amount'] = min((float) $record['budget'], (float) $fund['max_amount']);
                cradAddTimeline($record, 'Funding matched automatically: ' . $fund['name'], 'funding');
            }
        }
        if ($stage === 'grant' && $auto) {
            $record['stage'] = 'funding';
            cradAddTimeline($record, 'Moved to Funding Assistant automatically', 'funding');
        }
    }

    if ($stage === 'repository' && $auto && !empty($settings['auto_archive_repository'])) {
        if ($record['repository_doi'] === '') {
            $record['repository_doi'] = '10.5281/bcp.crad.' . date('Y') . '.' . substr(preg_replace('/\W+/', '', $record['id']), -6);
        }
        $record['status'] = 'completed';
        $record['public_status'] = $record['public_status'] === 'private' ? 'open' : $record['public_status'];
        cradAddTimeline($record, 'Archived to Research Repository automatically', 'repository');
    }

    if ($record['status'] === 'draft' && $stage !== 'proposal') {
        $record['status'] = 'active';
    }

    $record['updated_at'] = date('c');
}

function cradUpsertRecord(array $payload, bool $submit = false): array
{
    $store = cradGetStore();
    $id = trim((string) ($payload['id'] ?? ''));
    $existing = $id !== '' ? cradFindRecord($id) : null;

    $docs = $payload['documents'] ?? ($existing['documents'] ?? []);
    if (is_string($docs)) {
        $docs = array_values(array_filter(array_map('trim', explode(',', $docs))));
    }
    $collabs = $payload['collaborators'] ?? ($existing['collaborators'] ?? []);
    if (is_string($collabs)) {
        $collabs = array_values(array_filter(array_map('trim', explode(',', $collabs))));
    }

    $record = cradMakeRecord(array_merge($existing ?? [], [
        'id' => $existing['id'] ?? ($id !== '' ? $id : null),
        'title' => $payload['title'] ?? ($existing['title'] ?? ''),
        'principal' => $payload['principal'] ?? ($existing['principal'] ?? ''),
        'field' => $payload['field'] ?? ($existing['field'] ?? 'General'),
        'abstract' => $payload['abstract'] ?? ($existing['abstract'] ?? ''),
        'budget' => $payload['budget'] ?? ($existing['budget'] ?? 0),
        'stage' => $existing['stage'] ?? 'proposal',
        'status' => $existing['status'] ?? 'draft',
        'advisor_id' => $payload['advisor_id'] ?? ($existing['advisor_id'] ?? ''),
        'advisor_name' => $payload['advisor_name'] ?? ($existing['advisor_name'] ?? ''),
        'assessment_score' => array_key_exists('assessment_score', $payload)
            ? ($payload['assessment_score'] === '' ? null : (float) $payload['assessment_score'])
            : ($existing['assessment_score'] ?? null),
        'assessment_notes' => $payload['assessment_notes'] ?? ($existing['assessment_notes'] ?? ''),
        'grant_status' => $payload['grant_status'] ?? ($existing['grant_status'] ?? 'pending'),
        'funding_match' => $payload['funding_match'] ?? ($existing['funding_match'] ?? ''),
        'funding_amount' => $payload['funding_amount'] ?? ($existing['funding_amount'] ?? 0),
        'documents' => $docs,
        'publication' => $payload['publication'] ?? ($existing['publication'] ?? ''),
        'public_status' => $payload['public_status'] ?? ($existing['public_status'] ?? 'private'),
        'collaborators' => $collabs,
        'repository_doi' => $payload['repository_doi'] ?? ($existing['repository_doi'] ?? ''),
        'archived_at' => $existing['archived_at'] ?? null,
        'archive_expires_at' => $existing['archive_expires_at'] ?? null,
        'status_before_archive' => $existing['status_before_archive'] ?? null,
        'timeline' => $existing['timeline'] ?? null,
        'created_at' => $existing['created_at'] ?? null,
    ]));

    if ($existing && cradIsArchived($existing)) {
        return $existing;
    }

    if ($existing) {
        cradAddTimeline($record, 'Record updated');
    } else {
        cradAddTimeline($record, 'Proposal drafted', 'proposal');
    }

    if ($submit) {
        $record['status'] = 'active';
        $record['stage'] = 'proposal';
        cradAddTimeline($record, 'Proposal submitted — automatic pipeline started', 'proposal');
        // Run through auto side-effects: advisor assign + queue assessment
        cradAdvanceRecord($record, $store, 'advisor');
    }

    $found = false;
    foreach ($store['records'] as $i => $row) {
        if ($row['id'] === $record['id']) {
            $store['records'][$i] = $record;
            $found = true;
            break;
        }
    }
    if (!$found) {
        $store['records'][] = $record;
    }

    cradSaveStore($store);
    return $record;
}

function cradDeleteRecord(string $id): bool
{
    $store = cradGetStore();
    $before = count($store['records']);
    $store['records'] = array_values(array_filter(
        $store['records'],
        static fn($r) => ($r['id'] ?? '') !== $id
    ));
    if (count($store['records']) === $before) {
        return false;
    }
    cradSaveStore($store);
    return true;
}

function cradUpdateSettings(array $input): array
{
    $store = cradGetStore();
    $settings = array_merge(cradDefaultSettings(), $store['settings'] ?? []);
    foreach (['auto_flow', 'auto_assign_advisor', 'auto_queue_assessment', 'auto_system_check', 'auto_match_funding', 'auto_archive_repository'] as $flag) {
        if (array_key_exists($flag, $input)) {
            $settings[$flag] = !empty($input[$flag]) && $input[$flag] !== '0';
        }
    }
    if (isset($input['max_advisor_load'])) {
        $settings['max_advisor_load'] = max(1, (int) $input['max_advisor_load']);
    }
    if (isset($input['assessment_sla_days'])) {
        $settings['assessment_sla_days'] = max(1, (int) $input['assessment_sla_days']);
    }
    $settings['updated_at'] = date('c');
    $store['settings'] = $settings;
    cradSaveStore($store);
    return $settings;
}

function cradRecordsForStage(string $stage): array
{
    $active = cradActiveRecords();

    // proposal page: all active records
    if ($stage === 'proposal') {
        return $active;
    }

    // repository: completed / repository stage
    if ($stage === 'repository') {
        return array_values(array_filter(
            $active,
            static fn($r) => ($r['stage'] ?? '') === 'repository' || ($r['status'] ?? '') === 'completed' || ($r['repository_doi'] ?? '') !== ''
        ));
    }

    return array_values(array_filter(
        $active,
        static fn($r) => ($r['stage'] ?? '') === $stage
    ));
}

function cradStats(): array
{
    $records = cradActiveRecords();
    $archived = cradArchivedRecords();
    $byStage = array_fill_keys(cradStageKeys(), 0);
    $active = 0;
    $completed = 0;
    $budget = 0.0;
    foreach ($records as $r) {
        $stage = $r['stage'] ?? 'proposal';
        if (isset($byStage[$stage])) {
            $byStage[$stage]++;
        }
        if (($r['status'] ?? '') === 'active') {
            $active++;
        }
        if (($r['status'] ?? '') === 'completed' || $stage === 'repository') {
            $completed++;
        }
        $budget += (float) ($r['funding_amount'] ?? 0);
    }
    return [
        'total' => count($records),
        'active' => $active,
        'completed' => $completed,
        'archived' => count($archived),
        'budget_matched' => $budget,
        'by_stage' => $byStage,
    ];
}

function cradFlash(?string $message = null, ?string $type = null): ?array
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        @session_start();
    }
    if ($message !== null) {
        $_SESSION['crad_flash'] = ['message' => $message, 'type' => $type ?? 'success'];
        return null;
    }
    if (!empty($_SESSION['crad_flash'])) {
        $flash = $_SESSION['crad_flash'];
        unset($_SESSION['crad_flash']);
        return $flash;
    }
    return null;
}

function cradHandleActions(string $contextStage): void
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        return;
    }

    $action = $_POST['crad_action'] ?? '';
    $redirect = $_POST['redirect'] ?? ($_SERVER['REQUEST_URI'] ?? '');

    try {
        switch ($action) {
            case 'save':
                $submit = !empty($_POST['submit_pipeline']);
                $record = cradUpsertRecord($_POST, $submit);
                cradFlash($submit
                    ? 'Record created.'
                    : 'Record updated.');
                break;

            case 'delete':
                $id = (string) ($_POST['id'] ?? '');
                $record = cradFindRecord($id);
                if (!$record || !cradIsArchived($record)) {
                    cradFlash('Archive the record first before deleting.', 'warning');
                    break;
                }
                cradDeleteRecord($id);
                cradFlash('Record deleted.');
                break;

            case 'archive':
                $id = (string) ($_POST['id'] ?? '');
                if (cradSoftArchiveRecord($id)) {
                    cradFlash('Record archived.');
                } else {
                    cradFlash('Archive failed.', 'warning');
                }
                break;

            case 'restore':
                $id = (string) ($_POST['id'] ?? '');
                if (cradRestoreRecord($id)) {
                    cradFlash('Record restored.');
                } else {
                    cradFlash('Restore failed. The 30-day window may have expired.', 'warning');
                }
                break;

            case 'advance':
                $store = cradGetStore();
                $id = (string) ($_POST['id'] ?? '');
                foreach ($store['records'] as $i => $row) {
                    if ($row['id'] === $id) {
                        cradAddTimeline($store['records'][$i], 'Advanced from ' . ($row['stage'] ?? 'proposal'));
                        cradAdvanceRecord($store['records'][$i], $store);
                        cradSaveStore($store);
                        cradFlash('Record advanced in the automatic pipeline.');
                        break;
                    }
                }
                break;

            case 'assign_advisor':
                $store = cradGetStore();
                $id = (string) ($_POST['id'] ?? '');
                $advisorId = (string) ($_POST['advisor_id'] ?? '');
                foreach ($store['records'] as $i => $row) {
                    if ($row['id'] !== $id) {
                        continue;
                    }
                    foreach ($store['advisors'] as $adv) {
                        if ($adv['id'] === $advisorId) {
                            $store['records'][$i]['advisor_id'] = $adv['id'];
                            $store['records'][$i]['advisor_name'] = $adv['name'];
                            cradAddTimeline($store['records'][$i], 'Advisor set: ' . $adv['name'], 'advisor');
                            if (!empty($store['settings']['auto_flow'])) {
                                $store['records'][$i]['stage'] = 'assessment';
                                cradAddTimeline($store['records'][$i], 'Auto-queued for assessment', 'assessment');
                            }
                            break;
                        }
                    }
                    cradSaveStore($store);
                    cradFlash('Advisor assignment saved.');
                    break;
                }
                break;

            case 'assess':
                $store = cradGetStore();
                $id = (string) ($_POST['id'] ?? '');
                foreach ($store['records'] as $i => $row) {
                    if ($row['id'] !== $id) {
                        continue;
                    }
                    $score = (float) ($_POST['assessment_score'] ?? 0);
                    $store['records'][$i]['assessment_score'] = $score;
                    $store['records'][$i]['assessment_notes'] = trim((string) ($_POST['assessment_notes'] ?? ''));
                    cradAddTimeline($store['records'][$i], 'Assessment scored: ' . $score, 'assessment');
                    if ($score >= 70 && !empty($store['settings']['auto_flow'])) {
                        $store['records'][$i]['stage'] = 'system';
                        cradAdvanceRecord($store['records'][$i], $store, 'system');
                        cradFlash('Assessment passed. System checks and grant matching ran automatically.');
                    } else {
                        $store['records'][$i]['status'] = $score < 70 ? 'returned' : $store['records'][$i]['status'];
                        cradFlash($score < 70 ? 'Assessment below threshold — returned for revision.' : 'Assessment saved.', $score < 70 ? 'warning' : 'success');
                    }
                    cradSaveStore($store);
                    break;
                }
                break;

            case 'save_settings':
                cradUpdateSettings([
                    'auto_flow' => isset($_POST['auto_flow']),
                    'auto_assign_advisor' => isset($_POST['auto_assign_advisor']),
                    'auto_queue_assessment' => isset($_POST['auto_queue_assessment']),
                    'auto_system_check' => isset($_POST['auto_system_check']),
                    'auto_match_funding' => isset($_POST['auto_match_funding']),
                    'auto_archive_repository' => isset($_POST['auto_archive_repository']),
                    'max_advisor_load' => $_POST['max_advisor_load'] ?? 5,
                    'assessment_sla_days' => $_POST['assessment_sla_days'] ?? 7,
                ]);
                cradFlash('CRAD system settings updated. Automatic flow preferences applied.');
                break;

            case 'update_grant':
                $store = cradGetStore();
                $id = (string) ($_POST['id'] ?? '');
                foreach ($store['records'] as $i => $row) {
                    if ($row['id'] !== $id) {
                        continue;
                    }
                    $store['records'][$i]['grant_status'] = $_POST['grant_status'] ?? 'pending';
                    $store['records'][$i]['funding_amount'] = (float) ($_POST['funding_amount'] ?? 0);
                    cradAddTimeline($store['records'][$i], 'Grant status: ' . $store['records'][$i]['grant_status'], 'grant');
                    if ($store['records'][$i]['grant_status'] === 'awarded' && !empty($store['settings']['auto_flow'])) {
                        $store['records'][$i]['stage'] = 'document';
                        cradAddTimeline($store['records'][$i], 'Auto-moved to Document packaging', 'document');
                    }
                    cradSaveStore($store);
                    cradFlash('Grant record updated.');
                    break;
                }
                break;

            case 'match_funding':
                $store = cradGetStore();
                $id = (string) ($_POST['id'] ?? '');
                foreach ($store['records'] as $i => $row) {
                    if ($row['id'] !== $id) {
                        continue;
                    }
                    $fund = cradMatchFunding($row, $store['funding_sources']);
                    if ($fund) {
                        $store['records'][$i]['funding_match'] = $fund['name'];
                        $store['records'][$i]['funding_amount'] = min((float) $row['budget'], (float) $fund['max_amount']);
                        $store['records'][$i]['stage'] = 'funding';
                        cradAddTimeline($store['records'][$i], 'Funding assistant matched: ' . $fund['name'], 'funding');
                        cradSaveStore($store);
                        cradFlash('Funding source matched automatically.');
                    }
                    break;
                }
                break;

            case 'update_documents':
                $store = cradGetStore();
                $id = (string) ($_POST['id'] ?? '');
                foreach ($store['records'] as $i => $row) {
                    if ($row['id'] !== $id) {
                        continue;
                    }
                    $docs = array_values(array_filter(array_map('trim', explode(',', (string) ($_POST['documents'] ?? '')))));
                    $store['records'][$i]['documents'] = $docs;
                    cradAddTimeline($store['records'][$i], 'Documents updated (' . count($docs) . ')', 'document');
                    if (count($docs) >= 2 && !empty($store['settings']['auto_flow'])) {
                        $store['records'][$i]['stage'] = 'publication';
                        cradAddTimeline($store['records'][$i], 'Auto-moved to Public Management', 'publication');
                    }
                    cradSaveStore($store);
                    cradFlash('Documents saved.');
                    break;
                }
                break;

            case 'save_document':
                require_once __DIR__ . '/crad-documents.php';
                $store = cradGetStore();
                $id = (string) ($_POST['id'] ?? '');
                $docType = (string) ($_POST['document_type'] ?? 'proposal');
                $types = cradDocumentTypes();
                if (!isset($types[$docType])) {
                    cradFlash('Invalid document type.', 'warning');
                    break;
                }
                $label = $types[$docType];
                foreach ($store['records'] as $i => $row) {
                    if ($row['id'] !== $id || cradIsArchived($row)) {
                        continue;
                    }
                    $docs = array_values((array) ($store['records'][$i]['documents'] ?? []));
                    if (!in_array($label, $docs, true)) {
                        $docs[] = $label;
                    }
                    $store['records'][$i]['documents'] = $docs;
                    $store['records'][$i]['stage'] = 'document';
                    cradAddTimeline($store['records'][$i], 'Saved document: ' . $label, 'document');
                    if (count($docs) >= 2 && !empty($store['settings']['auto_flow'])) {
                        $store['records'][$i]['stage'] = 'publication';
                        cradAddTimeline($store['records'][$i], 'Auto-moved to Public Management', 'publication');
                    }
                    cradSaveStore($store);
                    cradFlash('Document saved: ' . $label . '.');
                    break;
                }
                break;

            case 'publish':
                $store = cradGetStore();
                $id = (string) ($_POST['id'] ?? '');
                foreach ($store['records'] as $i => $row) {
                    if ($row['id'] !== $id) {
                        continue;
                    }
                    $store['records'][$i]['publication'] = trim((string) ($_POST['publication'] ?? ''));
                    $store['records'][$i]['public_status'] = $_POST['public_status'] ?? 'embargo';
                    cradAddTimeline($store['records'][$i], 'Publication updated', 'publication');
                    if ($store['records'][$i]['publication'] !== '' && !empty($store['settings']['auto_flow'])) {
                        $store['records'][$i]['stage'] = 'collaboration';
                        cradAddTimeline($store['records'][$i], 'Auto-opened Collaboration Portal stage', 'collaboration');
                    }
                    cradSaveStore($store);
                    cradFlash('Public management record updated.');
                    break;
                }
                break;

            case 'update_collaboration':
                $store = cradGetStore();
                $id = (string) ($_POST['id'] ?? '');
                foreach ($store['records'] as $i => $row) {
                    if ($row['id'] !== $id) {
                        continue;
                    }
                    $collabs = array_values(array_filter(array_map('trim', explode(',', (string) ($_POST['collaborators'] ?? '')))));
                    $store['records'][$i]['collaborators'] = $collabs;
                    cradAddTimeline($store['records'][$i], 'Collaborators updated', 'collaboration');
                    if ($collabs !== [] && !empty($store['settings']['auto_flow'])) {
                        cradAdvanceRecord($store['records'][$i], $store, 'repository');
                    }
                    cradSaveStore($store);
                    cradFlash('Collaboration portal updated.');
                    break;
                }
                break;

            case 'deposit_repository':
                $store = cradGetStore();
                $id = (string) ($_POST['id'] ?? '');
                foreach ($store['records'] as $i => $row) {
                    if ($row['id'] !== $id || cradIsArchived($row)) {
                        continue;
                    }
                    cradAdvanceRecord($store['records'][$i], $store, 'repository');
                    cradSaveStore($store);
                    cradFlash('Record deposited in the Research Repository.');
                    break;
                }
                break;

            case 'reset_demo':
                @unlink(CRAD_DATA_FILE);
                cradReloadStore();
                cradFlash('CRAD demo data restored.');
                break;
        }
    } catch (Throwable $e) {
        cradFlash('Action failed: ' . $e->getMessage(), 'danger');
    }

    if ($redirect) {
        header('Location: ' . $redirect);
        exit;
    }
}

function cradMoney(float $amount): string
{
    return '₱' . number_format($amount, 0);
}

function cradFormatDate(?string $iso): string
{
    if (!$iso) {
        return '—';
    }
    $ts = strtotime($iso);
    return $ts ? date('M j, Y', $ts) : $iso;
}

function cradStatusBadge(string $status): string
{
    $map = [
        'draft' => 'secondary',
        'active' => 'primary',
        'returned' => 'warning',
        'completed' => 'success',
        'archived' => 'warning',
    ];
    $tone = $map[$status] ?? 'secondary';
    return '<span class="crad-badge crad-badge--' . htmlspecialchars($tone) . '">' . htmlspecialchars(ucfirst($status)) . '</span>';
}

function cradStageBadge(string $stage): string
{
    $stages = cradStages();
    $label = $stages[$stage]['label'] ?? ucfirst($stage);
    return '<span class="crad-badge crad-badge--stage">' . htmlspecialchars($label) . '</span>';
}
