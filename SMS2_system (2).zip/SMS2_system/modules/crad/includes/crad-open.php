<?php
/**
 * Open CRAD authenticated layout.
 * Expects: $pageTitle, $activeModule, $activePage, $breadcrumbs
 */
require_once __DIR__ . '/crad-bootstrap.php';
require_once ROOT_PATH . '/includes/breadcrumbs.php';
require_once ROOT_PATH . '/includes/layout-start.php';
?>
<link rel="stylesheet" href="<?= htmlspecialchars(BASE_URL . '/modules/crad/assets/css/crad.css') ?>">
