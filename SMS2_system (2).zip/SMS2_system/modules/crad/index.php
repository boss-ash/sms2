<?php
/**
 * SMS 2 - CRAD Overview
 */
require_once __DIR__ . '/includes/crad-bootstrap.php';

cradHandleActions('overview');

$pageTitle    = 'CRAD Overview';
$activeModule = 'crad';
$activePage   = '';
$breadcrumbs  = [
    ['label' => 'CRAD', 'url' => null],
];

require __DIR__ . '/includes/crad-open.php';

$stages = cradStages();
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<div class="crad-shell">
    <?php cradRenderFlash(); ?>
    <?php cradRenderStats(); ?>
    <?php cradPipelineNav(''); ?>

    <section class="crad-panel">
        <div class="crad-panel__head">
            <div>
                <h2>Stations</h2>
            </div>
            <a class="crad-btn crad-btn--primary crad-btn--small" href="<?= htmlspecialchars(BASE_URL . '/modules/crad/pages/research-proposal.php') ?>">
                <i class="fas fa-plus"></i>New record
            </a>
        </div>
        <div class="crad-panel__body">
            <div class="crad-module-grid">
                <?php foreach ($stages as $stage): ?>
                    <a class="crad-module-card" href="<?= htmlspecialchars(BASE_URL . '/modules/crad/pages/' . $stage['slug'] . '.php') ?>">
                        <i class="fas <?= htmlspecialchars($stage['icon']) ?>" aria-hidden="true"></i>
                        <strong><?= htmlspecialchars($stage['label']) ?></strong>
                        <span><?= htmlspecialchars($stage['desc']) ?></span>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <section class="crad-panel">
        <div class="crad-panel__head">
            <div>
                <h2>Records</h2>
            </div>
        </div>
        <div class="crad-panel__body">
            <?php cradRecordRows(cradActiveRecords(), 'proposal', [
                ['label' => 'Advisor', 'key' => 'advisor_name'],
                ['label' => 'Funding', 'key' => 'funding_match'],
            ]); ?>
        </div>
    </section>

    <?php cradArchivedBin(); ?>
</div>

<?php require __DIR__ . '/includes/crad-close.php'; ?>
