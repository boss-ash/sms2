<?php
/**
 * CRAD — Assessment station
 */
require_once __DIR__ . '/../includes/crad-bootstrap.php';

cradHandleActions('assessment');

$pageTitle    = 'Assessment';
$activeModule = 'crad';
$activePage   = 'assessment';
$breadcrumbs  = cradCrumbs('Assessment');
$self         = htmlspecialchars($_SERVER['REQUEST_URI'] ?? '');
$queue        = array_values(array_filter(
    cradActiveRecords(),
    static fn($r) => ($r['stage'] ?? '') === 'assessment' || (($r['assessment_score'] ?? null) !== null)
));

require __DIR__ . '/../includes/crad-open.php';
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<div class="crad-shell">
    <?php cradRenderFlash(); ?>
    <?php cradPipelineNav('assessment'); ?>

    <div class="crad-grid">
        <section class="crad-panel">
            <div class="crad-panel__head">
                <div>
                    <h2>Assessment queue</h2>
                    <p>Score a proposal to continue the automatic pipeline.</p>
                </div>
            </div>
            <div class="crad-panel__body">
                <?php if ($queue === []): ?>
                    <div class="crad-empty">No proposals in assessment.</div>
                <?php else: ?>
                    <div class="crad-table-wrap">
                        <table class="crad-table">
                            <thead>
                                <tr>
                                    <th>Proposal</th>
                                    <th>Advisor</th>
                                    <th>Score</th>
                                    <th>Assess</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($queue as $record): ?>
                                <tr>
                                    <td>
                                        <strong><?= htmlspecialchars($record['title']) ?></strong><br>
                                        <small><?= htmlspecialchars($record['id']) ?> · <?= htmlspecialchars($record['field']) ?></small>
                                    </td>
                                    <td><?= htmlspecialchars($record['advisor_name'] !== '' ? $record['advisor_name'] : '—') ?></td>
                                    <td><?= $record['assessment_score'] === null ? 'Pending' : htmlspecialchars((string) $record['assessment_score']) ?></td>
                                    <td>
                                        <form method="post" class="crad-inline-form">
                                            <input type="hidden" name="crad_action" value="assess">
                                            <input type="hidden" name="id" value="<?= htmlspecialchars($record['id']) ?>">
                                            <input type="hidden" name="redirect" value="<?= $self ?>">
                                            <input type="number" name="assessment_score" min="0" max="100" value="<?= htmlspecialchars((string) ($record['assessment_score'] ?? 80)) ?>" required>
                                            <input type="text" name="assessment_notes" placeholder="Notes" value="<?= htmlspecialchars($record['assessment_notes'] ?? '') ?>">
                                            <button class="crad-btn crad-btn--primary crad-btn--small" type="submit">Save score</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </section>
        <section class="crad-panel">
            <div class="crad-panel__head">
                <div>
                    <h2>Scoring guide</h2>
                    <p>Aligned with common international review thresholds.</p>
                </div>
            </div>
            <div class="crad-panel__body">
                <ul class="crad-timeline">
                    <li><strong>90–100 · Excellent</strong><time>Continues automatically to system review and grant matching</time></li>
                    <li><strong>70–89 · Acceptable</strong><time>Continues automatically with standard funding matching</time></li>
                    <li><strong>Below 70 · Returned</strong><time>Sent back for revision (pipeline pauses)</time></li>
                </ul>
            </div>
        </section>
    </div>
</div>

<?php require __DIR__ . '/../includes/crad-close.php'; ?>
