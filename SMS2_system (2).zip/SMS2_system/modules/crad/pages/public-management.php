<?php
/**
 * CRAD — Public Management (publication / public release)
 */
require_once __DIR__ . '/../includes/crad-bootstrap.php';

cradHandleActions('publication');

$pageTitle    = 'Public Management';
$activeModule = 'crad';
$activePage   = 'public-management';
$breadcrumbs  = cradCrumbs('Public Management');
$self         = htmlspecialchars($_SERVER['REQUEST_URI'] ?? '');
$records      = cradActiveRecords();

require __DIR__ . '/../includes/crad-open.php';
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<div class="crad-shell">
    <?php cradRenderFlash(); ?>
    <?php cradPipelineNav('publication'); ?>

    <section class="crad-panel">
        <div class="crad-panel__head">
            <div>
                <h2>Publication & public release</h2>
                <p>Control embargo, open access, and venue metadata.</p>
            </div>
        </div>
        <div class="crad-panel__body">
            <div class="crad-table-wrap">
                <table class="crad-table">
                    <thead>
                        <tr>
                            <th>Research</th>
                            <th>Publication</th>
                            <th>Visibility</th>
                            <th>Update</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($records as $record): ?>
                        <tr>
                            <td>
                                <strong><?= htmlspecialchars($record['title']) ?></strong><br>
                                <small><?= htmlspecialchars($record['id']) ?></small>
                            </td>
                            <td><?= htmlspecialchars($record['publication'] !== '' ? $record['publication'] : '—') ?></td>
                            <td><?= htmlspecialchars(ucfirst((string) ($record['public_status'] ?? 'private'))) ?></td>
                            <td>
                                <form method="post" class="crad-inline-form" style="min-width:220px">
                                    <input type="hidden" name="crad_action" value="publish">
                                    <input type="hidden" name="id" value="<?= htmlspecialchars($record['id']) ?>">
                                    <input type="hidden" name="redirect" value="<?= $self ?>">
                                    <input name="publication" value="<?= htmlspecialchars($record['publication'] ?? '') ?>" placeholder="Journal / proceedings">
                                    <select name="public_status">
                                        <?php foreach (['private', 'embargo', 'open'] as $st): ?>
                                            <option value="<?= $st ?>" <?= ($record['public_status'] ?? '') === $st ? 'selected' : '' ?>><?= ucfirst($st) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <button class="crad-btn crad-btn--primary crad-btn--small" type="submit">Save public record</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
</div>

<?php require __DIR__ . '/../includes/crad-close.php'; ?>
