<?php
/**
 * CRAD — System (automatic flow controls)
 */
require_once __DIR__ . '/../includes/crad-bootstrap.php';

cradHandleActions('system');

$pageTitle    = 'System';
$activeModule = 'crad';
$activePage   = 'system';
$breadcrumbs  = cradCrumbs('System');
$settings     = cradGetStore()['settings'] ?? cradDefaultSettings();
$self         = htmlspecialchars($_SERVER['REQUEST_URI'] ?? '');

require __DIR__ . '/../includes/crad-open.php';
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<div class="crad-shell">
    <?php cradRenderFlash(); ?>
    <?php cradPipelineNav('system'); ?>

    <div class="crad-grid">
        <section class="crad-panel">
            <div class="crad-panel__head">
                <div>
                    <h2>Automatic flow settings</h2>
                    <p>These rules drive advisor match, assessment queueing, funding, and repository deposit.</p>
                </div>
            </div>
            <div class="crad-panel__body">
                <form method="post" class="crad-form">
                    <input type="hidden" name="crad_action" value="save_settings">
                    <input type="hidden" name="redirect" value="<?= $self ?>">
                    <div class="crad-switch-grid">
                        <?php
                        $switches = [
                            'auto_flow' => ['Enable automatic pipeline', 'Records advance through stations without manual stage selection.'],
                            'auto_assign_advisor' => ['Auto-assign advisor', 'Match by expertise and current load on submit.'],
                            'auto_queue_assessment' => ['Auto-queue assessment', 'Send assigned proposals straight to review.'],
                            'auto_system_check' => ['Auto system compliance', 'Pass scored proposals through compliance then grants.'],
                            'auto_match_funding' => ['Auto funding assistant', 'Match national/international sources to field and budget.'],
                            'auto_archive_repository' => ['Auto repository archive', 'Mint DOI-style deposit when collaboration completes.'],
                        ];
                        foreach ($switches as $key => $meta):
                        ?>
                            <label class="crad-switch">
                                <input type="checkbox" name="<?= htmlspecialchars($key) ?>" value="1" <?= !empty($settings[$key]) ? 'checked' : '' ?>>
                                <span>
                                    <strong><?= htmlspecialchars($meta[0]) ?></strong>
                                    <span><?= htmlspecialchars($meta[1]) ?></span>
                                </span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                    <div class="crad-form-row">
                        <div class="crad-field">
                            <label>Max advisor load</label>
                            <input type="number" min="1" max="20" name="max_advisor_load" value="<?= (int) ($settings['max_advisor_load'] ?? 5) ?>">
                        </div>
                        <div class="crad-field">
                            <label>Assessment SLA (days)</label>
                            <input type="number" min="1" max="60" name="assessment_sla_days" value="<?= (int) ($settings['assessment_sla_days'] ?? 7) ?>">
                        </div>
                    </div>
                    <div class="crad-actions">
                        <button class="crad-btn crad-btn--primary" type="submit"><i class="fas fa-save"></i>Save system settings</button>
                    </div>
                </form>
            </div>
        </section>
        <section class="crad-panel">
            <div class="crad-panel__head">
                <div>
                    <h2>Pipeline health</h2>
                    <p>Station counts and maintenance.</p>
                </div>
            </div>
            <div class="crad-panel__body">
                <?php cradRenderStats(); ?>
                <div style="height:1rem"></div>
                <?php cradRecentTimeline(6); ?>
                <form method="post" style="margin-top:1rem" data-crad-confirm="Restore seeded CRAD demo data? Current records will be replaced.">
                    <input type="hidden" name="crad_action" value="reset_demo">
                    <input type="hidden" name="redirect" value="<?= $self ?>">
                    <button class="crad-btn crad-btn--ghost" type="submit"><i class="fas fa-rotate"></i>Restore demo data</button>
                </form>
            </div>
        </section>
    </div>
</div>

<?php require __DIR__ . '/../includes/crad-close.php'; ?>
