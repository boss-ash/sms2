<?php
/**
 * CRAD — Research Proposal
 */
require_once __DIR__ . '/../includes/crad-bootstrap.php';

cradHandleActions('proposal');

$pageTitle    = 'Research Proposal';
$activeModule = 'crad';
$activePage   = 'research-proposal';
$breadcrumbs  = cradCrumbs('Research Proposal');

require __DIR__ . '/../includes/crad-open.php';
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<div class="crad-shell">
    <?php cradRenderFlash(); ?>
    <?php cradPipelineNav('proposal'); ?>

    <div class="crad-grid">
        <section class="crad-panel">
            <div class="crad-panel__head">
                <div>
                    <h2>Records</h2>
                </div>
            </div>
            <div class="crad-panel__body">
                <?php cradRecordRows(cradRecordsForStage('proposal'), 'proposal', [
                    ['label' => 'Budget', 'key' => 'budget', 'format' => 'money'],
                ]); ?>
            </div>
        </section>
        <section class="crad-panel">
            <div class="crad-panel__head">
                <div>
                    <h2>Create</h2>
                </div>
            </div>
            <div class="crad-panel__body">
                <?php cradProposalForm(); ?>
            </div>
        </section>
    </div>

    <?php cradArchivedBin(); ?>
</div>

<?php require __DIR__ . '/../includes/crad-close.php'; ?>
