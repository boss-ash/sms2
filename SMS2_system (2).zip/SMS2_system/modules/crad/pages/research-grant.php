<?php
/**
 * CRAD — Research Grant
 */
require_once __DIR__ . '/../includes/crad-bootstrap.php';

cradHandleActions('grant');

$pageTitle    = 'Research Grant';
$activeModule = 'crad';
$activePage   = 'research-grant';
$breadcrumbs  = cradCrumbs('Research Grant');
$self         = htmlspecialchars($_SERVER['REQUEST_URI'] ?? '');
$records      = array_values(array_filter(
    cradActiveRecords(),
    static fn($r) => in_array($r['stage'] ?? '', ['grant', 'funding', 'document', 'publication', 'collaboration', 'repository', 'system'], true)
        || in_array($r['grant_status'] ?? '', ['eligible', 'awarded', 'pending'], true)
));

require __DIR__ . '/../includes/crad-open.php';
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<div class="crad-shell">
    <?php cradRenderFlash(); ?>
    <?php cradPipelineNav('grant'); ?>

    <section class="crad-panel">
        <div class="crad-panel__head">
            <div>
                <h2>Grant records</h2>
                <p>Update eligibility and award amounts. Auto-flow continues on award.</p>
            </div>
        </div>
        <div class="crad-panel__body">
            <?php if ($records === []): ?>
                <div class="crad-empty">No grant records yet. Submit and assess proposals first.</div>
            <?php else: ?>
                <div class="crad-table-wrap">
                    <table class="crad-table">
                        <thead>
                            <tr>
                                <th>Research</th>
                                <th>Match</th>
                                <th>Status</th>
                                <th>Update grant</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($records as $record): ?>
                            <tr>
                                <td>
                                    <strong><?= htmlspecialchars($record['title']) ?></strong><br>
                                    <small><?= htmlspecialchars($record['id']) ?> · Budget <?= cradMoney((float) $record['budget']) ?></small>
                                </td>
                                <td><?= htmlspecialchars($record['funding_match'] !== '' ? $record['funding_match'] : 'Pending match') ?></td>
                                <td><?= htmlspecialchars(ucfirst((string) $record['grant_status'])) ?></td>
                                <td>
                                    <form method="post" class="crad-inline-form">
                                        <input type="hidden" name="crad_action" value="update_grant">
                                        <input type="hidden" name="id" value="<?= htmlspecialchars($record['id']) ?>">
                                        <input type="hidden" name="redirect" value="<?= $self ?>">
                                        <select name="grant_status">
                                            <?php foreach (['pending', 'eligible', 'awarded', 'declined'] as $st): ?>
                                                <option value="<?= $st ?>" <?= ($record['grant_status'] ?? '') === $st ? 'selected' : '' ?>><?= ucfirst($st) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                        <input type="number" name="funding_amount" min="0" step="1000" value="<?= htmlspecialchars((string) ($record['funding_amount'] ?: $record['budget'])) ?>">
                                        <button class="crad-btn crad-btn--primary crad-btn--small" type="submit">Save grant</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </section>
</div>

<?php require __DIR__ . '/../includes/crad-close.php'; ?>
