<?php
/**
 * CRAD — Advisor station
 */
require_once __DIR__ . '/../includes/crad-bootstrap.php';

cradHandleActions('advisor');

$pageTitle    = 'Advisor';
$activeModule = 'crad';
$activePage   = 'advisor';
$breadcrumbs  = cradCrumbs('Advisor');
$store        = cradGetStore();
$self         = htmlspecialchars($_SERVER['REQUEST_URI'] ?? '');

require __DIR__ . '/../includes/crad-open.php';
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<div class="crad-shell">
    <?php cradRenderFlash(); ?>
    <?php cradPipelineNav('advisor'); ?>

    <div class="crad-grid">
        <section class="crad-panel">
            <div class="crad-panel__head">
                <div>
                    <h2>Assignments</h2>
                    <p>Records waiting for or carrying advisor assignment.</p>
                </div>
            </div>
            <div class="crad-panel__body">
                <?php
                $rows = array_values(array_filter(
                    cradActiveRecords($store['records']),
                    static fn($r) => in_array($r['stage'] ?? '', ['advisor', 'assessment', 'proposal'], true) || ($r['advisor_id'] ?? '') !== ''
                ));
                if ($rows === []) {
                    echo '<div class="crad-empty">No advisor assignments yet.</div>';
                } else {
                    echo '<div class="crad-table-wrap"><table class="crad-table"><thead><tr><th>Record</th><th>Field</th><th>Advisor</th><th>Assign / override</th></tr></thead><tbody>';
                    foreach ($rows as $record) {
                        echo '<tr>';
                        echo '<td><strong>' . htmlspecialchars($record['title']) . '</strong><br><small>' . htmlspecialchars($record['id']) . '</small></td>';
                        echo '<td>' . htmlspecialchars($record['field']) . '</td>';
                        echo '<td>' . htmlspecialchars($record['advisor_name'] !== '' ? $record['advisor_name'] : 'Auto-pending') . '</td>';
                        echo '<td><form method="post" class="crad-inline-form">';
                        echo '<input type="hidden" name="crad_action" value="assign_advisor">';
                        echo '<input type="hidden" name="id" value="' . htmlspecialchars($record['id']) . '">';
                        echo '<input type="hidden" name="redirect" value="' . $self . '">';
                        echo '<select name="advisor_id">';
                        foreach ($store['advisors'] as $adv) {
                            $sel = ($record['advisor_id'] ?? '') === $adv['id'] ? ' selected' : '';
                            echo '<option value="' . htmlspecialchars($adv['id']) . '"' . $sel . '>' . htmlspecialchars($adv['name']) . ' (load ' . (int) $adv['load'] . ')</option>';
                        }
                        echo '</select>';
                        echo '<button class="crad-btn crad-btn--primary crad-btn--small" type="submit">Save advisor</button>';
                        echo '</form></td></tr>';
                    }
                    echo '</tbody></table></div>';
                }
                ?>
            </div>
        </section>
        <section class="crad-panel">
            <div class="crad-panel__head">
                <div>
                    <h2>Advisor pool</h2>
                    <p>Expertise used by the automatic matcher.</p>
                </div>
            </div>
            <div class="crad-panel__body">
                <div class="crad-table-wrap">
                    <table class="crad-table">
                        <thead><tr><th>Advisor</th><th>Department</th><th>Expertise</th><th>Load</th></tr></thead>
                        <tbody>
                        <?php foreach ($store['advisors'] as $adv): ?>
                            <tr>
                                <td><strong><?= htmlspecialchars($adv['name']) ?></strong><br><small><?= htmlspecialchars($adv['email']) ?></small></td>
                                <td><?= htmlspecialchars($adv['department']) ?></td>
                                <td><?= htmlspecialchars(implode(', ', (array) $adv['expertise'])) ?></td>
                                <td><?= (int) $adv['load'] ?> / <?= (int) ($store['settings']['max_advisor_load'] ?? 5) ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
    </div>
</div>

<?php require __DIR__ . '/../includes/crad-close.php'; ?>
