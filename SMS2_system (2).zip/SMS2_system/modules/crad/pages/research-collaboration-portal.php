<?php
/**
 * CRAD — Research Collaboration Portal
 */
require_once __DIR__ . '/../includes/crad-bootstrap.php';

cradHandleActions('collaboration');

$pageTitle    = 'Research Collaboration Portal';
$activeModule = 'crad';
$activePage   = 'research-collaboration-portal';
$breadcrumbs  = cradCrumbs('Research Collaboration Portal');
$self         = htmlspecialchars($_SERVER['REQUEST_URI'] ?? '');
$records      = cradActiveRecords();

require __DIR__ . '/../includes/crad-open.php';
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<div class="crad-shell">
    <?php cradRenderFlash(); ?>
    <?php cradPipelineNav('collaboration'); ?>

    <section class="crad-panel">
        <div class="crad-panel__head">
            <div>
                <h2>Collaboration network</h2>
                <p>Maintain partner lists for each research record.</p>
            </div>
        </div>
        <div class="crad-panel__body">
            <div class="crad-table-wrap">
                <table class="crad-table">
                    <thead>
                        <tr>
                            <th>Research</th>
                            <th>Collaborators</th>
                            <th>Update portal</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($records as $record): ?>
                        <tr>
                            <td>
                                <strong><?= htmlspecialchars($record['title']) ?></strong><br>
                                <small><?= htmlspecialchars($record['principal']) ?> · <?= htmlspecialchars($record['id']) ?></small>
                            </td>
                            <td><?= htmlspecialchars(implode(', ', (array) ($record['collaborators'] ?? [])) ?: '—') ?></td>
                            <td>
                                <form method="post" class="crad-inline-form" style="min-width:220px">
                                    <input type="hidden" name="crad_action" value="update_collaboration">
                                    <input type="hidden" name="id" value="<?= htmlspecialchars($record['id']) ?>">
                                    <input type="hidden" name="redirect" value="<?= $self ?>">
                                    <input name="collaborators" value="<?= htmlspecialchars(implode(', ', (array) ($record['collaborators'] ?? []))) ?>" placeholder="Partner A, Partner B">
                                    <button class="crad-btn crad-btn--primary crad-btn--small" type="submit">Save collaborators</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
</div>

<?php require __DIR__ . '/../includes/crad-close.php'; ?>
