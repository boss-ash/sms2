<?php
/**
 * CRAD — Research Repository
 */
require_once __DIR__ . '/../includes/crad-bootstrap.php';

cradHandleActions('repository');

$pageTitle    = 'Research Repository';
$activeModule = 'crad';
$activePage   = 'research-repository';
$breadcrumbs  = cradCrumbs('Research Repository');
$archived     = cradRecordsForStage('repository');

require __DIR__ . '/../includes/crad-open.php';
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<div class="crad-shell">
    <?php cradRenderFlash(); ?>
    <?php cradPipelineNav('repository'); ?>

    <section class="crad-panel">
        <div class="crad-panel__head">
            <div>
                <h2>Published research</h2>
                <p>Completed studies and repository records.</p>
            </div>
        </div>
        <div class="crad-panel__body">
            <?php cradRecordRows($archived, 'repository', [
                ['label' => 'DOI', 'key' => 'repository_doi'],
                ['label' => 'Publication', 'key' => 'publication'],
            ]); ?>
        </div>
    </section>
</div>

<?php require __DIR__ . '/../includes/crad-close.php'; ?>
