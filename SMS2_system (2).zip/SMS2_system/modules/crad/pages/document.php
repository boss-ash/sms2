<?php
/**
 * CRAD — Document (print & save)
 */
require_once __DIR__ . '/../includes/crad-bootstrap.php';
require_once __DIR__ . '/../includes/crad-documents.php';

cradHandleActions('document');

$pageTitle    = 'Document';
$activeModule = 'crad';
$activePage   = 'document';
$breadcrumbs  = cradCrumbs('Document');
$self         = htmlspecialchars($_SERVER['REQUEST_URI'] ?? '');
$records      = cradActiveRecords();
$docTypes     = cradDocumentTypes();

$selectedId   = (string) ($_GET['id'] ?? ($records[0]['id'] ?? ''));
$selectedType = (string) ($_GET['doc'] ?? 'proposal');
if (!isset($docTypes[$selectedType])) {
    $selectedType = 'proposal';
}

$selected = null;
foreach ($records as $record) {
    if (($record['id'] ?? '') === $selectedId) {
        $selected = $record;
        break;
    }
}
if ($selected === null && $records !== []) {
    $selected = $records[0];
    $selectedId = (string) $selected['id'];
}

$printHtml = $selected ? cradBuildDocumentHtml($selected, $selectedType) : '';

require __DIR__ . '/../includes/crad-open.php';
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<div class="crad-shell crad-shell--docs">
    <?php cradRenderFlash(); ?>
    <?php cradPipelineNav('document'); ?>

    <div class="crad-doc-layout crad-doc-layout--controls">
        <section class="crad-panel crad-doc-controls">
            <div class="crad-panel__head">
                <div>
                    <h2>Print &amp; Save</h2>
                </div>
            </div>
            <div class="crad-panel__body">
                <?php if ($records === []): ?>
                    <div class="crad-empty"><strong>No research records</strong></div>
                <?php else: ?>
                    <form method="get" class="crad-form" id="cradDocSelectForm">
                        <div class="crad-field">
                            <label for="cradDocRecord">Research record</label>
                            <select id="cradDocRecord" name="id" onchange="this.form.submit()">
                                <?php foreach ($records as $record): ?>
                                    <option value="<?= htmlspecialchars($record['id']) ?>" <?= $selectedId === $record['id'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($record['id'] . ' — ' . $record['title']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="crad-field">
                            <label for="cradDocType">Document to print / save</label>
                            <select id="cradDocType" name="doc" onchange="this.form.submit()">
                                <?php foreach ($docTypes as $key => $label): ?>
                                    <option value="<?= htmlspecialchars($key) ?>" <?= $selectedType === $key ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($label) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </form>

                    <div class="crad-doc-actions">
                        <button type="button" class="crad-btn crad-btn--primary" id="cradPrintBtn">
                            <i class="fas fa-print"></i>Preview &amp; Print
                        </button>
                        <form method="post" class="crad-action-form">
                            <input type="hidden" name="crad_action" value="save_document">
                            <input type="hidden" name="id" value="<?= htmlspecialchars($selectedId) ?>">
                            <input type="hidden" name="document_type" value="<?= htmlspecialchars($selectedType) ?>">
                            <input type="hidden" name="redirect" value="<?= htmlspecialchars(BASE_URL . '/modules/crad/pages/document.php?id=' . urlencode($selectedId) . '&doc=' . urlencode($selectedType)) ?>">
                            <button type="submit" class="crad-btn crad-btn--ghost" id="cradSaveDocBtn">
                                <i class="fas fa-save"></i>Save
                            </button>
                        </form>
                        <button type="button" class="crad-btn crad-btn--ghost" id="cradDownloadDocBtn">
                            <i class="fas fa-download"></i>Download
                        </button>
                    </div>

                    <?php if ($selected): ?>
                        <div class="crad-doc-saved">
                            <strong>Saved documents</strong>
                            <?php
                            $saved = (array) ($selected['documents'] ?? []);
                            if ($saved === []) {
                                echo '<p>None yet</p>';
                            } else {
                                echo '<ul>';
                                foreach ($saved as $docName) {
                                    $isCurrent = $docName === cradDocumentTypeLabel($selectedType);
                                    echo '<li' . ($isCurrent ? ' class="is-current"' : '') . '>' . htmlspecialchars($docName) . '</li>';
                                }
                                echo '</ul>';
                            }
                            ?>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </section>

        <section class="crad-panel crad-doc-list">
            <div class="crad-panel__head">
                <div><h2>Documents</h2></div>
            </div>
            <div class="crad-panel__body">
                <div class="crad-doc-type-grid">
                    <?php foreach ($docTypes as $key => $label): ?>
                        <a href="?id=<?= urlencode($selectedId) ?>&doc=<?= urlencode($key) ?>"
                           class="crad-doc-type<?= $selectedType === $key ? ' is-selected' : '' ?>">
                            <i class="fas fa-file-alt"></i>
                            <span><?= htmlspecialchars($label) ?></span>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
    </div>
</div>

<?php if ($printHtml !== ''): ?>
<dialog class="crad-print-dialog" id="cradPrintDialog" aria-labelledby="cradPrintDialogTitle">
    <div class="crad-print-dialog__shell">
        <header class="crad-print-dialog__head">
            <div>
                <h2 id="cradPrintDialogTitle">Print Preview</h2>
                <p><?= htmlspecialchars(cradDocumentTypeLabel($selectedType)) ?></p>
            </div>
            <button type="button" class="crad-dialog-close" id="cradPrintClose" aria-label="Close preview">
                <i class="fas fa-times"></i>
            </button>
        </header>
        <div class="crad-print-dialog__body">
            <div class="crad-print-frame" id="cradPrintFrame">
                <?= $printHtml ?>
            </div>
        </div>
        <footer class="crad-print-dialog__foot">
            <button type="button" class="crad-btn crad-btn--ghost" id="cradPrintCancel">Cancel</button>
            <button type="button" class="crad-btn crad-btn--primary" id="cradPrintConfirm">
                <i class="fas fa-print"></i>Print now
            </button>
        </footer>
    </div>
</dialog>
<?php endif; ?>

<?php require __DIR__ . '/../includes/crad-close.php'; ?>
