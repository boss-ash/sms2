<?php
/**
 * CRAD — Funding Assistant
 */
require_once __DIR__ . '/../includes/crad-bootstrap.php';

cradHandleActions('funding');

$pageTitle    = 'Funding Assistant';
$activeModule = 'crad';
$activePage   = 'funding-assistant';
$breadcrumbs  = cradCrumbs('Funding Assistant');
$store        = cradGetStore();
$self         = htmlspecialchars($_SERVER['REQUEST_URI'] ?? '');

require __DIR__ . '/../includes/crad-open.php';
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<div class="crad-shell">
    <?php cradRenderFlash(); ?>
    <?php cradPipelineNav('funding'); ?>

    <div class="crad-grid">
        <section class="crad-panel">
            <div class="crad-panel__head">
                <div>
                    <h2>Funding matches</h2>
                    <p>Run or refresh automatic source matching.</p>
                </div>
            </div>
            <div class="crad-panel__body">
                <?php
                $activeRecords = cradActiveRecords($store['records']);
                cradRecordRows($activeRecords, 'funding', [
                    ['label' => 'Matched source', 'key' => 'funding_match'],
                    ['label' => 'Amount', 'key' => 'funding_amount', 'format' => 'money'],
                ]);
                ?>
                <div class="crad-actions" style="margin-top:1rem;flex-direction:column;align-items:stretch">
                    <?php foreach ($activeRecords as $record): ?>
                        <form method="post" style="display:flex;justify-content:space-between;gap:.5rem;align-items:center;border:1px solid var(--sms-border,#e2e8f0);border-radius:.8rem;padding:.55rem .7rem">
                            <span><strong><?= htmlspecialchars($record['id']) ?></strong> — <?= htmlspecialchars($record['title']) ?></span>
                            <input type="hidden" name="crad_action" value="match_funding">
                            <input type="hidden" name="id" value="<?= htmlspecialchars($record['id']) ?>">
                            <input type="hidden" name="redirect" value="<?= $self ?>">
                            <button class="crad-btn crad-btn--primary crad-btn--small" type="submit"><i class="fas fa-magic"></i>Auto-match</button>
                        </form>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
        <section class="crad-panel">
            <div class="crad-panel__head">
                <div>
                    <h2>Funding catalogue</h2>
                    <p>Institutional, national, and international sources.</p>
                </div>
            </div>
            <div class="crad-panel__body">
                <div class="crad-table-wrap">
                    <table class="crad-table">
                        <thead><tr><th>Source</th><th>Type</th><th>Ceiling</th><th>Fields</th></tr></thead>
                        <tbody>
                        <?php foreach ($store['funding_sources'] as $fund): ?>
                            <tr>
                                <td><strong><?= htmlspecialchars($fund['name']) ?></strong></td>
                                <td><?= htmlspecialchars($fund['type']) ?></td>
                                <td><?= cradMoney((float) $fund['max_amount']) ?></td>
                                <td><?= htmlspecialchars(implode(', ', (array) $fund['fields'])) ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
    </div>
</div>

<?php require __DIR__ . '/../includes/crad-close.php'; ?>
