<?php
require_once __DIR__ . '/../../../config/config.php';
header('Location: ' . BASE_URL . '/modules/crad/pages/research-grant.php');
exit;
