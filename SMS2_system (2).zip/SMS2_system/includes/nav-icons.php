<?php
/**
 * Shared navigation / module page icons
 */
if (!function_exists('smsNavPageIcon')) {
    function smsNavPageIcon(string $slug): string
    {
        static $map = [
            'online-pre-registration' => 'fa-globe',
            'document-upload-portal' => 'fa-cloud-upload-alt',
            'enrollment-validation' => 'fa-check-double',
            'id-number-generation' => 'fa-hashtag',
            'grade-level-assignment' => 'fa-layer-group',
            'waiting-list-queue' => 'fa-stream',
            'cross-enrollment-checker' => 'fa-exchange-alt',
            'auto-section-assignment' => 'fa-magic',
            'parent-notification' => 'fa-bell',
            'enrollment-dashboard' => 'fa-chart-pie',
            'student-information-system' => 'fa-id-badge',
            'persona-file-database' => 'fa-database',
            'guardian-emergency-contact' => 'fa-phone-alt',
            'academic-history' => 'fa-history',
            'health-record-log' => 'fa-heartbeat',
            'rfid-qr-code-integration' => 'fa-qrcode',
            'student-id-generation' => 'fa-id-card',
            'document-requests' => 'fa-file-signature',
            'student-status-tracker' => 'fa-user-check',
            'digital-file-storage' => 'fa-folder',
            'transcript-management' => 'fa-scroll',
            'research-proposal' => 'fa-file-signature',
            'advisor' => 'fa-user-tie',
            'assessment' => 'fa-clipboard-check',
            'system' => 'fa-cogs',
            'research-grant' => 'fa-hand-holding-usd',
            'funding-assistant' => 'fa-coins',
            'document' => 'fa-print',
            'public-management' => 'fa-bullhorn',
            'research-collaboration-portal' => 'fa-handshake',
            'research-repository' => 'fa-archive',
            'research-proposal-submission' => 'fa-file-signature',
            'adviser-assignment-system' => 'fa-user-tie',
            'research-grants-funding-assistance' => 'fa-hand-holding-usd',
            'documentation-publication-management' => 'fa-folder-open',
        ];

        if (isset($map[$slug])) {
            return $map[$slug];
        }

        if (str_contains($slug, 'payment') || str_contains($slug, 'billing') || str_contains($slug, 'fee') || str_contains($slug, 'peso') || str_contains($slug, 'receivable') || str_contains($slug, 'penalty') || str_contains($slug, 'discount') || str_contains($slug, 'scholarship') || str_contains($slug, 'collection') || str_contains($slug, 'ledger')) {
            return 'fa-peso-sign';
        }
        if (str_contains($slug, 'report') || str_contains($slug, 'analytics') || str_contains($slug, 'dashboard')) {
            return 'fa-chart-bar';
        }
        if (str_contains($slug, 'schedule') || str_contains($slug, 'calendar') || str_contains($slug, 'timetable') || str_contains($slug, 'time-block')) {
            return 'fa-calendar';
        }
        if (str_contains($slug, 'upload') || str_contains($slug, 'document') || str_contains($slug, 'file') || str_contains($slug, 'repository')) {
            return 'fa-file-alt';
        }
        if (str_contains($slug, 'faculty') || str_contains($slug, 'teacher') || str_contains($slug, 'teaching') || str_contains($slug, 'evaluation')) {
            return 'fa-chalkboard-teacher';
        }
        if (str_contains($slug, 'quiz') || str_contains($slug, 'lms') || str_contains($slug, 'lesson') || str_contains($slug, 'classroom') || str_contains($slug, 'assignment') || str_contains($slug, 'module')) {
            return 'fa-laptop';
        }
        if (str_contains($slug, 'research') || str_contains($slug, 'grant') || str_contains($slug, 'proposal') || str_contains($slug, 'publication')) {
            return 'fa-flask';
        }
        if (str_contains($slug, 'club') || str_contains($slug, 'event') || str_contains($slug, 'volunteer') || str_contains($slug, 'co-curricular') || str_contains($slug, 'cocurricular')) {
            return 'fa-users';
        }
        if (str_contains($slug, 'curriculum') || str_contains($slug, 'subject') || str_contains($slug, 'elective') || str_contains($slug, 'prerequisite') || str_contains($slug, 'strand')) {
            return 'fa-book';
        }
        if (str_contains($slug, 'accreditation') || str_contains($slug, 'compliance') || str_contains($slug, 'audit') || str_contains($slug, 'quality')) {
            return 'fa-award';
        }
        if (str_contains($slug, 'leave') || str_contains($slug, 'attendance') || str_contains($slug, 'clearance') || str_contains($slug, 'payroll') || str_contains($slug, 'salary')) {
            return 'fa-user-clock';
        }
        if (str_contains($slug, 'room') || str_contains($slug, 'conflict') || str_contains($slug, 'section') || str_contains($slug, 'exam') || str_contains($slug, 'substitute') || str_contains($slug, 'cloning')) {
            return 'fa-calendar-check';
        }

        return 'fa-circle';
    }
}
