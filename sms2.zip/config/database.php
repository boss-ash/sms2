<?php
/**
 * SMS 2 - Database Configuration (Stub)
 * Database connection will be implemented in a later phase.
 */

define('DB_HOST', 'localhost');
define('DB_NAME', 'sms2_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

/**
 * Returns a PDO instance when database integration is enabled.
 * Phase 1: returns null — no database connection.
 */
function getDatabaseConnection(): ?PDO
{
    // TODO: Implement PDO connection in Phase 2
    // try {
    //     $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
    //     return new PDO($dsn, DB_USER, DB_PASS, [
    //         PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    //         PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    //     ]);
    // } catch (PDOException $e) {
    //     error_log('Database connection failed: ' . $e->getMessage());
    //     return null;
    // }

    return null;
}
