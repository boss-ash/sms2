<?php
/**
 * SMS 2 - Session Management
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
