<?php
/**
 * SMS 2 - Scripts
 */
?>
<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- SMS 2 App -->
<script src="<?= BASE_URL ?>/assets/js/theme.js"></script>
<script src="<?= BASE_URL ?>/assets/js/sidebar.js"></script>
<script src="<?= BASE_URL ?>/assets/js/app.js"></script>
<!-- Global Search -->
<script src="<?= BASE_URL ?>/assets/js/search.js"></script>
</body>
</html>
