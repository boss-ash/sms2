<?php
/**
 * SMS 2 - HTML Header
 * Expects: $pageTitle (string), optional $bodyClass (string)
 */
if (!defined('APP_NAME')) {
    require_once __DIR__ . '/../config/config.php';
}

$pageTitle = $pageTitle ?? APP_NAME;
$bodyClass = $bodyClass ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="description" content="<?= htmlspecialchars(APP_NAME) ?> - <?= htmlspecialchars(INSTITUTION) ?>">
    <title><?= htmlspecialchars($pageTitle) ?> | <?= htmlspecialchars(APP_SHORT_NAME) ?></title>

    <!-- Apply theme before paint to avoid flash -->
    <script>
    (function () {
        try {
            var t = localStorage.getItem('sms2-theme');
            if (t !== 'dark' && t !== 'light') t = 'light';
            document.documentElement.setAttribute('data-theme', t);
            document.documentElement.style.colorScheme = t;
        } catch (e) {
            document.documentElement.setAttribute('data-theme', 'light');
        }
    })();
    </script>

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome 6 -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Chart.js (pinned; animations disabled in app charts to avoid resize recursion) -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.8/dist/chart.umd.min.js"></script>
    <!-- SMS 2 Theme -->
    <link href="<?= BASE_URL ?>/assets/css/theme.css?v=<?= urlencode(APP_VERSION) ?>-charts2" rel="stylesheet">
    <link href="<?= BASE_URL ?>/assets/css/layout.css" rel="stylesheet">
    <link href="<?= BASE_URL ?>/assets/css/responsive.css" rel="stylesheet">
    <link href="<?= BASE_URL ?>/assets/css/dashboard-glass.css?v=<?= urlencode(APP_VERSION) ?>-charts2" rel="stylesheet">
    <link href="<?= BASE_URL ?>/assets/css/loader.css" rel="stylesheet">
</head>
<body class="<?= htmlspecialchars($bodyClass) ?>">
<div id="smsPageLoader" class="sms-page-loader" role="status" aria-live="polite" aria-busy="true" aria-label="Loading">
    <div class="sms-loader-backdrop" aria-hidden="true"></div>
    <div class="sms-loader-content">
        <div class="sms-loader-spinner" aria-hidden="true"></div>
        <span class="sms-loader-label">Loading</span>
    </div>
</div>
<script src="<?= BASE_URL ?>/assets/js/loader.js"></script>
