/**
 * SMS 2 – Theme Manager (light / dark)
 * Persists preference, updates icons, and refreshes Chart.js on theme change only.
 */
(function () {
    'use strict';

    var STORAGE_KEY = 'sms2-theme';
    var VALID = { light: true, dark: true };
    var refreshTimer = null;
    var refreshing = false;

    function normalize(theme) {
        return VALID[theme] ? theme : 'light';
    }

    function getStoredTheme() {
        try {
            return normalize(localStorage.getItem(STORAGE_KEY));
        } catch (e) {
            return 'light';
        }
    }

    function storeTheme(theme) {
        try {
            localStorage.setItem(STORAGE_KEY, theme);
        } catch (e) { /* private mode / blocked storage */ }
    }

    function applyTheme(theme, options) {
        theme = normalize(theme);
        var root = document.documentElement;
        root.setAttribute('data-theme', theme);
        root.style.colorScheme = theme;

        document.querySelectorAll('[data-theme-toggle]').forEach(function (btn) {
            var next = theme === 'dark' ? 'light' : 'dark';
            btn.setAttribute('aria-label', theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode');
            btn.setAttribute('title', theme === 'dark' ? 'Light mode' : 'Dark mode');
            btn.setAttribute('aria-pressed', theme === 'dark' ? 'true' : 'false');
            btn.dataset.nextTheme = next;
        });

        document.querySelectorAll('[data-theme-set]').forEach(function (btn) {
            var isActive = btn.getAttribute('data-theme-set') === theme;
            btn.classList.toggle('active', isActive);
            btn.setAttribute('aria-current', isActive ? 'true' : 'false');
        });

        // Only touch charts on real theme changes — never during silent boot
        if (!options || options.silent !== true) {
            scheduleRefreshCharts(50);
            try {
                window.dispatchEvent(new CustomEvent('sms2:themechange', { detail: { theme: theme } }));
            } catch (e) { /* older browsers */ }
        }

        return theme;
    }

    function cssVar(name, fallback) {
        var value = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
        return value || fallback;
    }

    function collectCharts() {
        var list = [];
        if (typeof Chart === 'undefined' || typeof Chart.getChart !== 'function') return list;

        document.querySelectorAll('canvas').forEach(function (canvas) {
            var chart = Chart.getChart(canvas);
            if (chart) list.push(chart);
        });
        return list;
    }

    function isChartReady(chart) {
        return !!(chart && chart.ctx && chart.canvas && chart.data && Array.isArray(chart.boxes));
    }

    function setTickColor(scaleOpts, color) {
        if (!scaleOpts || typeof scaleOpts !== 'object') return;
        if (!scaleOpts.ticks || typeof scaleOpts.ticks !== 'object') {
            scaleOpts.ticks = {};
        }
        // Mutate only color — never replace callback / scriptable tick fns
        scaleOpts.ticks.color = color;
    }

    function refreshCharts() {
        if (typeof Chart === 'undefined' || refreshing) return;
        refreshing = true;

        try {
            var textColor = cssVar('--sms-chart-text', '#64748b');
            var gridColor = cssVar('--sms-chart-grid', 'rgba(15,33,88,0.06)');
            var doughnutBorder = cssVar('--sms-chart-doughnut-border', '#ffffff');

            Chart.defaults.color = textColor;

            collectCharts().forEach(function (chart) {
                if (!isChartReady(chart)) return;

                var opts = chart.config && chart.config.options;
                if (!opts) return;

                try {
                    if (opts.scales) {
                        Object.keys(opts.scales).forEach(function (key) {
                            var scale = opts.scales[key];
                            if (!scale || typeof scale !== 'object') return;
                            setTickColor(scale, textColor);
                            if (scale.title && typeof scale.title === 'object') {
                                scale.title.color = textColor;
                            }
                            if (scale.grid && typeof scale.grid === 'object') {
                                scale.grid.color = gridColor;
                            }
                        });
                    }

                    if (chart.data && chart.data.datasets) {
                        var chartType = (chart.config && chart.config.type) || '';
                        if (chartType === 'doughnut' || chartType === 'pie') {
                            chart.data.datasets.forEach(function (ds) {
                                if (ds) ds.borderColor = doughnutBorder;
                            });
                        }
                    }

                    chart.update('none');
                } catch (err) {
                    /* ignore per-chart refresh errors */
                }
            });
        } finally {
            refreshing = false;
        }
    }

    function scheduleRefreshCharts(delay) {
        if (refreshTimer) window.clearTimeout(refreshTimer);
        refreshTimer = window.setTimeout(function () {
            refreshTimer = null;
            refreshCharts();
        }, typeof delay === 'number' ? delay : 50);
    }

    function toggleTheme() {
        var current = document.documentElement.getAttribute('data-theme') || getStoredTheme();
        var next = current === 'dark' ? 'light' : 'dark';
        storeTheme(next);
        applyTheme(next);
        return next;
    }

    function bindToggles() {
        document.querySelectorAll('[data-theme-toggle]').forEach(function (btn) {
            if (btn.dataset.themeBound === '1') return;
            btn.dataset.themeBound = '1';
            btn.addEventListener('click', function (e) {
                e.preventDefault();
                toggleTheme();
            });
        });

        document.querySelectorAll('[data-theme-set]').forEach(function (btn) {
            if (btn.dataset.themeBound === '1') return;
            btn.dataset.themeBound = '1';
            btn.addEventListener('click', function (e) {
                e.preventDefault();
                var theme = normalize(btn.getAttribute('data-theme-set'));
                storeTheme(theme);
                applyTheme(theme);
            });
        });
    }

    window.SMS2Theme = {
        get: function () {
            return document.documentElement.getAttribute('data-theme') || getStoredTheme();
        },
        set: function (theme) {
            theme = normalize(theme);
            storeTheme(theme);
            return applyTheme(theme);
        },
        toggle: toggleTheme,
        refreshCharts: function () {
            scheduleRefreshCharts(0);
        }
    };

    applyTheme(document.documentElement.getAttribute('data-theme') || getStoredTheme(), { silent: true });

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', bindToggles);
    } else {
        bindToggles();
    }
})();
