/**
 * SMS 2 – Glass dashboard charts
 * Solid colors only; animations off to avoid Chart.js resize/color recursion.
 */
(function () {
    'use strict';

    var board = document.getElementById('glassBoard');
    if (!board || typeof Chart === 'undefined') return;

    function themeVar(name, fallback) {
        return getComputedStyle(document.documentElement).getPropertyValue(name).trim() || fallback;
    }

    function mountChart(canvas, config) {
        if (!canvas) return null;
        var existing = typeof Chart.getChart === 'function' ? Chart.getChart(canvas) : null;
        if (existing) {
            try { existing.destroy(); } catch (e) { /* ignore */ }
        }
        return new Chart(canvas, config);
    }

    function baseOptions(extra) {
        var opts = {
            responsive: true,
            maintainAspectRatio: false,
            animation: false,
            animations: false,
            transitions: {
                active: { animation: { duration: 0 } },
                resize: { animation: { duration: 0 } },
                show: { animations: { colors: false, numbers: false } },
                hide: { animations: { colors: false, numbers: false } }
            },
            plugins: { legend: { display: false } }
        };
        if (extra) {
            Object.keys(extra).forEach(function (key) {
                if (key === 'plugins' && extra.plugins && opts.plugins) {
                    Object.keys(extra.plugins).forEach(function (pk) {
                        opts.plugins[pk] = extra.plugins[pk];
                    });
                } else {
                    opts[key] = extra[key];
                }
            });
        }
        return opts;
    }

    var text = themeVar('--sms-chart-text', '#94a3b8');
    var grid = themeVar('--sms-chart-grid', 'rgba(148,163,184,0.12)');
    var doughnutBorder = themeVar('--sms-chart-doughnut-border', '#121c34');
    var role = board.getAttribute('data-role') || 'admin';

    Chart.defaults.font.family = "'Inter', sans-serif";
    Chart.defaults.font.size = 11;
    Chart.defaults.color = text;
    Chart.defaults.animation = false;

    var months = ['May 1', 'May 5', 'May 9', 'May 13', 'May 17', 'May 21', 'May 25', 'May 29'];
    var blue = '#3b82f6';
    var green = '#22c55e';
    var orange = '#fb923c';
    var violet = '#8b5cf6';
    var cyan = '#06b6d4';
    var amber = '#f59e0b';

    var donutData = [612, 543, 487, 415, 836];
    var donutColors = [blue, violet, green, amber, cyan];
    var donutLabels = ['BSIT', 'BSBA', 'BSEd', 'BSN', 'Others'];

    if (role === 'finance') {
        donutData = [68, 12, 8, 7, 5];
    } else if (role === 'hr') {
        donutData = [18, 22, 20, 14, 28];
    } else if (role === 'it_office') {
        donutData = [82, 74, 68, 71, 65];
    }

    var trendData = [42, 55, 48, 70, 62, 78, 74, 90];
    if (role === 'hr') trendData = [3, 5, 8, 6, 4, 7, 5, 9];
    if (role === 'it_office') trendData = [820, 980, 1100, 1240, 1180, 1320, 1400, 1510];

    function buildCharts() {
        try {
            mountChart(document.getElementById('glassDonut'), {
                type: 'doughnut',
                data: {
                    labels: donutLabels.slice(),
                    datasets: [{
                        data: donutData.slice(),
                        backgroundColor: donutColors.slice(),
                        borderColor: doughnutBorder,
                        borderWidth: 3,
                        hoverOffset: 4
                    }]
                },
                options: baseOptions({
                    maintainAspectRatio: true,
                    aspectRatio: 1,
                    cutout: '72%',
                    plugins: {
                        legend: { display: false },
                        tooltip: { enabled: true }
                    }
                })
            });

            mountChart(document.getElementById('glassTrend'), {
                type: 'line',
                data: {
                    labels: months.slice(),
                    datasets: [{
                        label: 'Trend',
                        data: trendData.slice(),
                        borderColor: blue,
                        backgroundColor: 'rgba(59,130,246,0.18)',
                        fill: true,
                        borderWidth: 2.5,
                        tension: 0.45,
                        pointRadius: 0,
                        pointHoverRadius: 4,
                        pointBackgroundColor: '#ffffff',
                        pointBorderColor: blue,
                        pointBorderWidth: 2
                    }]
                },
                options: baseOptions({
                    interaction: { mode: 'index', intersect: false },
                    scales: {
                        x: {
                            grid: { display: false },
                            ticks: { color: text, maxRotation: 0, autoSkip: true, maxTicksLimit: 6 }
                        },
                        y: {
                            grid: { color: grid },
                            border: { display: false },
                            ticks: { color: text, maxTicksLimit: 5 }
                        }
                    }
                })
            });

            mountChart(document.getElementById('glassCash'), {
                type: 'line',
                data: {
                    labels: months.slice(),
                    datasets: [
                        {
                            label: 'Inflow',
                            data: [48, 52, 50, 64, 70, 78, 82, 90],
                            borderColor: green,
                            backgroundColor: 'rgba(0,0,0,0)',
                            borderWidth: 2.25,
                            tension: 0.4,
                            pointRadius: 0,
                            pointHoverRadius: 4
                        },
                        {
                            label: 'Outflow',
                            data: [30, 34, 38, 42, 40, 48, 52, 55],
                            borderColor: orange,
                            backgroundColor: 'rgba(0,0,0,0)',
                            borderWidth: 2.25,
                            tension: 0.4,
                            pointRadius: 0,
                            pointHoverRadius: 4
                        }
                    ]
                },
                options: baseOptions({
                    interaction: { mode: 'index', intersect: false },
                    scales: {
                        x: {
                            grid: { display: false },
                            ticks: { display: false, color: text }
                        },
                        y: {
                            grid: { color: grid },
                            border: { display: false },
                            ticks: { display: false, color: text }
                        }
                    }
                })
            });

            mountChart(document.getElementById('glassNet'), {
                type: 'doughnut',
                data: {
                    labels: ['Net', 'Remainder'],
                    datasets: [{
                        data: [64, 36],
                        backgroundColor: [green, 'rgba(148,163,184,0.18)'],
                        borderWidth: 0,
                        hoverOffset: 0
                    }]
                },
                options: baseOptions({
                    maintainAspectRatio: true,
                    aspectRatio: 1,
                    cutout: '78%',
                    plugins: {
                        legend: { display: false },
                        tooltip: { enabled: false }
                    }
                })
            });
        } catch (err) {
            console.error('SMS2 glass dashboard charts failed:', err);
        }
    }

    // Wait for layout (loader / fonts / grid) so ResizeObserver does not thrash
    window.requestAnimationFrame(function () {
        window.requestAnimationFrame(buildCharts);
    });
})();
