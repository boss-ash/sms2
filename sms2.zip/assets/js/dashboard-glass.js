/**
 * SMS 2 – Glass dashboard charts
 * Solid colors only (avoids Chart.js gradient animation bugs)
 */
(function () {
    'use strict';

    var board = document.getElementById('glassBoard');
    if (!board || typeof Chart === 'undefined') return;

    function themeVar(name, fallback) {
        return getComputedStyle(document.documentElement).getPropertyValue(name).trim() || fallback;
    }

    var text = themeVar('--sms-chart-text', '#94a3b8');
    var grid = themeVar('--sms-chart-grid', 'rgba(148,163,184,0.12)');
    var doughnutBorder = themeVar('--sms-chart-doughnut-border', '#121c34');
    var role = board.getAttribute('data-role') || 'admin';

    Chart.defaults.font.family = "'Inter', sans-serif";
    Chart.defaults.font.size = 11;
    Chart.defaults.color = text;
    if (Chart.defaults.animation && typeof Chart.defaults.animation === 'object') {
        Chart.defaults.animation.duration = 700;
        Chart.defaults.animation.easing = 'easeOutQuart';
    }

    var months = ['May 1', 'May 5', 'May 9', 'May 13', 'May 17', 'May 21', 'May 25', 'May 29'];
    var blue = '#3b82f6';
    var green = '#22c55e';
    var orange = '#fb923c';
    var violet = '#8b5cf6';
    var cyan = '#06b6d4';
    var amber = '#f59e0b';

    var donutData = [612, 543, 487, 415, 836];
    var donutColors = [blue, violet, green, amber, cyan];

    if (role === 'finance') {
        donutData = [68, 12, 8, 7, 5];
    } else if (role === 'hr') {
        donutData = [18, 22, 20, 14, 28];
    } else if (role === 'it_office') {
        donutData = [82, 74, 68, 71, 65];
    }

    var trendData = [42, 55, 48, 70, 62, 78, 74, 90];
    if (role === 'hr') trendData = [3, 5, 8, 6, 4, 7, 5, 9];
    if (role === 'it_office') trendData = [820, 980, 1100, 1240, 1180, 1320, 1400, 1510];

    try {
        var donutEl = document.getElementById('glassDonut');
        if (donutEl) {
            new Chart(donutEl, {
                type: 'doughnut',
                data: {
                    labels: ['A', 'B', 'C', 'D', 'E'],
                    datasets: [{
                        data: donutData,
                        backgroundColor: donutColors,
                        borderColor: doughnutBorder,
                        borderWidth: 3,
                        hoverOffset: 4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    cutout: '72%',
                    plugins: { legend: { display: false }, tooltip: { enabled: true } }
                }
            });
        }

        var trendEl = document.getElementById('glassTrend');
        if (trendEl) {
            new Chart(trendEl, {
                type: 'line',
                data: {
                    labels: months,
                    datasets: [{
                        label: 'Trend',
                        data: trendData,
                        borderColor: blue,
                        backgroundColor: 'rgba(59,130,246,0.18)',
                        fill: true,
                        borderWidth: 2.5,
                        tension: 0.45,
                        pointRadius: 0,
                        pointHoverRadius: 4,
                        pointBackgroundColor: '#fff',
                        pointBorderColor: blue,
                        pointBorderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    interaction: { mode: 'index', intersect: false },
                    plugins: { legend: { display: false } },
                    scales: {
                        x: {
                            grid: { display: false },
                            ticks: { maxRotation: 0, autoSkip: true, maxTicksLimit: 6 }
                        },
                        y: {
                            grid: { color: grid },
                            border: { display: false },
                            ticks: { maxTicksLimit: 5 }
                        }
                    }
                }
            });
        }

        var cashEl = document.getElementById('glassCash');
        if (cashEl) {
            new Chart(cashEl, {
                type: 'line',
                data: {
                    labels: months,
                    datasets: [
                        {
                            label: 'Inflow',
                            data: [48, 52, 50, 64, 70, 78, 82, 90],
                            borderColor: green,
                            backgroundColor: 'transparent',
                            borderWidth: 2.25,
                            tension: 0.4,
                            pointRadius: 0,
                            pointHoverRadius: 4
                        },
                        {
                            label: 'Outflow',
                            data: [30, 34, 38, 42, 40, 48, 52, 55],
                            borderColor: orange,
                            backgroundColor: 'transparent',
                            borderWidth: 2.25,
                            tension: 0.4,
                            pointRadius: 0,
                            pointHoverRadius: 4
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    interaction: { mode: 'index', intersect: false },
                    plugins: { legend: { display: false } },
                    scales: {
                        x: { grid: { display: false }, ticks: { display: false } },
                        y: { grid: { color: grid }, border: { display: false }, ticks: { display: false } }
                    }
                }
            });
        }

        var netEl = document.getElementById('glassNet');
        if (netEl) {
            new Chart(netEl, {
                type: 'doughnut',
                data: {
                    datasets: [{
                        data: [64, 36],
                        backgroundColor: [green, 'rgba(148,163,184,0.18)'],
                        borderWidth: 0,
                        hoverOffset: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    cutout: '78%',
                    plugins: { legend: { display: false }, tooltip: { enabled: false } }
                }
            });
        }
    } catch (err) {
        console.error('SMS2 glass dashboard charts failed:', err);
    }

    if (window.SMS2Theme && typeof window.SMS2Theme.refreshCharts === 'function') {
        window.setTimeout(function () {
            window.SMS2Theme.refreshCharts();
        }, 60);
    }
})();
