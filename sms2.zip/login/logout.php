<?php
/**
 * SMS 2 - Logout
 */
require_once __DIR__ . '/../config/config.php';
require_once ROOT_PATH . '/includes/authentication.php';

logout();

header('Location: ' . BASE_URL . '/welcome/index.php');
exit;
